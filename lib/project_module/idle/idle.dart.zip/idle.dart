import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz;
import 'package:zeus/navigator_tabs/idle/PopScreen.dart';
import 'dart:convert';
import '../../utility/app_url.dart';
import '../../widgets/Popup.dart';
import 'PopScreen.dart';
import 'PopScreen.dart';
import 'PopScreen.dart';
import 'data/DataClass.dart';
import 'data/project_detail_data/ProjectDetailData.dart';
import 'project_detail_model/project_detail_response.dart';
import 'project_idel_model/project_idel_response.dart';
import 'package:provider/provider.dart';

class Idle extends StatefulWidget {

  const Idle({Key? key}) : super(key: key);

  @override
  State<Idle> createState() => _IdleState();
}

class _IdleState extends State<Idle> {
  List _statusList = [];
  List _currencyName = [];
  List _accountableId = [];
  List _customerName = [];
  PopupScreen popupScreen= PopupScreen();
  int? id;
  bool amIHovering = false;
  Future? _getData;
  Future? _getProjectDetail;
  Offset exitFrom = const Offset(0,0);
  bool hovered = false;

  final ScrollController _scrollController = ScrollController();
  double? _scrollPosition = 0;
  double ?_opacity = 0;

  _scrollListener() {
    setState(() {
      _scrollPosition ;
    });
  }
  final ScrollController controller = ScrollController();
  final ScrollController controller2 = ScrollController();

  showMenus(BuildContext context) async {
    await showMenu(
      context: context,
      position: const RelativeRect.fromLTRB(100, 100, 100, 100),
      items: [
        const PopupMenuItem(
          child: Text("View"),),
        const PopupMenuItem(
          child: Text("Edit"),),
        const PopupMenuItem(
          child: Text("Delete"),),
      ],
    );
  }

  Future? getListData(){
   return Provider.of<DataIdelClass>(context, listen: false).getPeopleIdel();
  }

  Future? getProject(){
    return Provider.of<ProjectDetail>(context, listen: false).getProjectDetail();
  }

  @override
  void initState() {
    //getIdel();
    _getData=getListData();
    _getProjectDetail=getProject();
    getSelectStatus();
    getAccountable();
    getAccountable();
    getCustomer();
    getCurrency();
    //  var abv=Provider.of<ProjectDetail>(context, listen: false).productData();
     // print('checkDate '+abv.data.toString());
    //var a=_getProjectDetail as ProjectDetailResponse;
   // print(a.data!.title);
   // getData.getPeopleIdel();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final mediaQueryData = MediaQuery.of(context);
    return  MediaQuery(
      data: mediaQueryData.copyWith(textScaleFactor: 1.0),
      child: SafeArea(
        child: Scaffold(
          backgroundColor: const Color(0xff0F172A),
              body:  SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: Container(
                    width: MediaQuery.of(context).size.width * 0.90,
                    height: MediaQuery.of(context).size.height * 0.83,
                    margin: const EdgeInsets.only(
                        left: 40.0, right: 16.0, bottom: 10.0, top: 40.0),
                    decoration: BoxDecoration(
                      color: const Color(0xff1E293B),
                      border: Border.all(color: const Color(0xff1E293B)),
                      borderRadius: BorderRadius.circular(
                        12.0,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [


                        Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              /*ConstrainedBox(
                                                    constraints: BoxConstraints.tight(Size(200.0, 100.0)),
                                                    child: MouseRegion(
                                                     // cursor: SystemMouseCursors.text,
                                                      //onHover: showMenus(context),
                                                      onEnter: (_){
                                                        setState(() {
                                                          showMenus(context);
                                                          hovered = true;
                                                        });
                                                      },
                                                      onExit: (_) {
                                                        setState(() {
                                                          hovered = false;
                                                        // Navigator.of(context).pop();
                                                        });

                                                      },
                                                      child: Container(
                                                        color: Colors.lightBlueAccent,
                                                        margin: const EdgeInsets.only(
                                                            left: 16.0, top: 16.0),
                                                        child: const Text(
                                                          "AP",
                                                          style: TextStyle(
                                                              color: Color(0xff94A3B8),
                                                              fontSize: 14.0,
                                                              fontFamily: 'Inter',
                                                              fontWeight: FontWeight.w500),
                                                        ),
                                                      ),
                                                    ),
                                                  ),*/

                              InkWell(
                                onTap: (){
                                  print('i am call');
                                  // api();
                                },
                                child: Container(
                                  margin: const EdgeInsets.only(
                                      left: 16.0, top: 16.0),
                                  child: const Text("AP",
                                    style: TextStyle(
                                        color: Color(0xff94A3B8),
                                        fontSize: 14.0,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w500),
                                  ),
                                ),
                              ),


                              Container(
                                margin: const EdgeInsets.only(
                                    left: 25.0,top: 16.0),
                                child: const Text(
                                  "Project name",
                                  style: TextStyle(
                                      color: Color(0xff94A3B8),
                                      fontSize: 14.0,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500),
                                ),
                              ),

                              // Spacer(flex: 1,),

                              Container (

                                margin: const EdgeInsets.only(
                                    left: 55,top: 16.0),
                                child: const Text(
                                  "Current phase",
                                  style: TextStyle(
                                      color: Color(0xff94A3B8),
                                      fontSize: 14.0,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500),
                                ),
                              ),

                              Spacer(flex: 1,),
                              Container(

                                margin: const EdgeInsets.only(
                                    top: 16.0,left: 51.0),
                                child: const Text(
                                  "Status",
                                  style: TextStyle(
                                      color: Color(0xff94A3B8),
                                      fontSize: 14.0,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500),
                                ),
                              ),
                              Spacer(flex: 1,),
                              Container(
                                margin: const EdgeInsets.only(top: 16.0,left: 5.0),
                                child: const Text(
                                  "SPI",
                                  style: TextStyle(
                                      color: Color(0xff94A3B8),
                                      fontSize: 14.0,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500),
                                ),
                              ),
                              Spacer(flex: 1,),
                              Container(

                                margin: const EdgeInsets.only(
                                    top: 16.0, left: 0.0),
                                child: const Text(
                                  "Potential roadblocks",
                                  style: TextStyle(
                                      color: Color(0xff94A3B8),
                                      fontSize: 14.0,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500),
                                ),
                              ),
                              Spacer(flex: 1,),
                              Container(
                                margin: const EdgeInsets.only(
                                    top: 16.0, left: 30.0),
                                child: const Text(
                                  "Last\nupdate",
                                  style: TextStyle(
                                      color: Color(0xff94A3B8),
                                      fontSize: 14.0,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500),
                                ),
                              ),
                              Spacer(flex: 1,),
                              Container(
                                margin: const EdgeInsets.only(
                                    top: 16.0, left: 15.0),
                                child: const Text(
                                  "Next\nmilestone",
                                  style: TextStyle(
                                      color: Color(0xff94A3B8),
                                      fontSize: 14.0,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500),
                                ),
                              ),
                              Spacer(flex: 1,),
                              Container(
                                margin: const EdgeInsets.only(
                                    top: 16.0, left: 15.0),
                                child: const Text(
                                  "Delivery\ndate",
                                  style: TextStyle(
                                      color: Color(0xff94A3B8),
                                      fontSize: 14.0,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500),
                                ),
                              ),
                              Spacer(flex: 1,),
                              Container(
                                margin: const EdgeInsets.only(
                                    top: 16.0, left: 0.0),
                                child: const Text(
                                  "Deadline",
                                  style: TextStyle(
                                      color: Color(0xff94A3B8),
                                      fontSize: 14.0,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500),
                                ),
                              ),
                              Spacer(flex: 1,),
                              Container(
                                margin: const EdgeInsets.only(
                                    top: 16.0, left: 10.0,right: 16),
                                child: const Text(
                                  "Resources",
                                  style: TextStyle(
                                      color: Color(0xff94A3B8),
                                      fontSize: 14.0,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500),
                                ),
                              ),

                            ],
                          ),


                        const SizedBox(height: 8.0,),

                        Container(
                            margin: const EdgeInsets.only(
                                left: 16.0, right: 16.0),
                            child: const Divider(
                              color: Color(0xff94A3B8),
                              thickness: 0.1,
                            )),

                        Expanded(
                          flex: 1,
                          child: FutureBuilder(
                              future: _getData,
                              builder: (context, snapshot) {
                                if(snapshot.connectionState==ConnectionState.waiting) {
                                  return  const Center(child:CircularProgressIndicator());
                                } else {
                                  return Consumer<DataIdelClass?>(
                                      builder: (context,data,_){

                                        return  ListView.builder(
                                          physics: NeverScrollableScrollPhysics(),
                                          shrinkWrap: true,
                                          itemCount: data!.peopleIdelResponse!.data!.length,
                                          itemBuilder: (BuildContext context, int index) {
                                            Data upLoad =  data.peopleIdelResponse!.data![index];
                                            id=upLoad.id;
                                            var projectname=upLoad.title;
                                            var ee=upLoad.accountablePerson!.name;
                                            String name = ee!.substring(0,2);
                                            // var idd=upLoad.customer!.phoneNumber;
                                            var phone=upLoad.workFolderId;
                                            var status=upLoad.status;
                                            return InkWell(
                                              onTap: (){
                                                showDailog(context,Provider.of<ProjectDetail>(context, listen: false).productData(),_statusList,_currencyName,_accountableId,_customerName);
                                              },
                                              child: Column(
                                                children: [
                                                  Row(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        width: 32.0,
                                                        height: 32.0,
                                                        margin: const EdgeInsets.only(
                                                            left: 16.0, top: 16.0),
                                                        decoration: BoxDecoration(
                                                          color: const Color(0xff334155),
                                                          border: Border.all(
                                                              color: const Color(0xff334155)),
                                                          borderRadius: BorderRadius.circular(16.0,
                                                          ),
                                                        ),
                                                        child:  Align(
                                                          alignment: Alignment.center,
                                                          child: Text(name,
                                                            style: const TextStyle(
                                                                color: Color(0xffFFFFFF),
                                                                fontSize: 13.0,
                                                                fontFamily: 'Inter',
                                                                fontWeight:
                                                                FontWeight.w500),
                                                          ),
                                                        ),
                                                      ),

                                                      Container(
                                                        width: 140.0,
                                                        padding: const EdgeInsets.only(
                                                            left: 16.0, top: 16.0),
                                                        child:  Text(
                                                          projectname!,
                                                          style: const TextStyle(
                                                              color: Color(0xffFFFFFF),
                                                              fontSize: 14.0,
                                                              fontFamily: 'Inter',
                                                              fontWeight: FontWeight.w500),
                                                        ),
                                                      ),

                                                      // Spacer(flex: 1,),

                                                      Container(
                                                        width: 163.0,
                                                        padding: const EdgeInsets.fromLTRB(
                                                            0,16,0,0),
                                                        child: const Align(
                                                          alignment: Alignment.center,
                                                          child: Text(
                                                            "Backend:Phase 2/4",
                                                            style: TextStyle(
                                                                color: Color(0xffFFFFFF),
                                                                fontSize: 14.0,
                                                                fontFamily: 'Inter',
                                                                fontWeight: FontWeight.w500),
                                                          ),
                                                        ),
                                                      ),
                                                      Spacer(flex: 1,),

                                                      if(status=="Open")...[
                                                        Container(
                                                          height: 30.0,
                                                          //width: 55.0,
                                                          margin: const EdgeInsets.only(
                                                              left: 20.0,
                                                              right: 12.0,
                                                              top: 12.0),
                                                          decoration: BoxDecoration(
                                                            color: const Color(0xff16A34A),
                                                            //border: Border.all(color: const Color(0xff0E7490)),
                                                            borderRadius:
                                                            BorderRadius.circular(
                                                              8.0,
                                                            ),
                                                          ),
                                                          child: const Align(
                                                            alignment: Alignment.center,
                                                            child: Padding(
                                                              padding: EdgeInsets.all(5.0),
                                                              child:
                                                              Text(
                                                                "Risk",
                                                                style: TextStyle(
                                                                    color: Color(0xffFFFFFF),
                                                                    fontSize: 11.0,
                                                                    fontFamily: 'Inter',
                                                                    fontWeight:
                                                                    FontWeight.w500),
                                                              ),
                                                            ),
                                                          ),
                                                        ),

                                                      ] else if(status=='On track')...[

                                                        Container(
                                                          height: 30.0,
                                                          //width: 55.0,
                                                          margin: const EdgeInsets.only(
                                                              left: 20.0,
                                                              right: 12.0,
                                                              top: 12.0),
                                                          decoration: BoxDecoration(
                                                            color: const Color(0xff6D28D9),
                                                            //border: Border.all(color: const Color(0xff0E7490)),
                                                            borderRadius:
                                                            BorderRadius.circular(
                                                              8.0,
                                                            ),
                                                          ),
                                                          child: const Align(
                                                            alignment: Alignment.center,
                                                            child: Padding(
                                                              padding: EdgeInsets.all(5.0),
                                                              child:
                                                              Text(
                                                                "On track",
                                                                style: TextStyle(
                                                                    color: Color(0xffFFFFFF),
                                                                    fontSize: 11.0,
                                                                    fontFamily: 'Inter',
                                                                    fontWeight:
                                                                    FontWeight.w500),
                                                              ),
                                                            ),
                                                          ),
                                                        ),

                                                      ]else if(status=='Live')...[
                                                        Container(
                                                          height: 30.0,
                                                          // width: 55.0,
                                                          margin: const EdgeInsets.only(
                                                              left: 20.0,
                                                              right: 12.0,
                                                              top: 12.0),
                                                          decoration: BoxDecoration(
                                                            color: const Color(0xff16A34A),
                                                            //border: Border.all(color: const Color(0xff0E7490)),
                                                            borderRadius:
                                                            BorderRadius.circular(
                                                              8.0,
                                                            ),
                                                          ),
                                                          child: const Align(
                                                            alignment: Alignment.center,
                                                            child: Padding(
                                                              padding: EdgeInsets.all(5.0),
                                                              child:
                                                              Text(
                                                                "Live",
                                                                style: TextStyle(
                                                                    color: Color(0xffFFFFFF),
                                                                    fontSize: 11.0,
                                                                    fontFamily: 'Inter',
                                                                    fontWeight:
                                                                    FontWeight.w500),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        /* Container(
                                                                          height: 30.0,
                                                                          width: 55.0,
                                                                          margin: const EdgeInsets.only(
                                                                              left: 20.0,
                                                                              right: 12.0,
                                                                              top: 12.0),
                                                                          decoration: BoxDecoration(
                                                                            color: const Color(0xffB91C1C),
                                                                            //border: Border.all(color: const Color(0xff0E7490)),
                                                                            borderRadius:
                                                                            BorderRadius.circular(
                                                                              8.0,
                                                                            ),
                                                                          ),
                                                                          child: const Align(
                                                                            alignment: Alignment.center,
                                                                            child: Padding(
                                                                              padding: EdgeInsets.all(5.0),
                                                                              child:
                                                                              Text(
                                                                                "Risk",
                                                                                style: TextStyle(
                                                                                    color: Color(0xffFFFFFF),
                                                                                    fontSize: 11.0,
                                                                                    fontFamily: 'Inter',
                                                                                    fontWeight:
                                                                                    FontWeight.w500),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),*/
                                                      ] else if(status=="Design sent for approval")...[
                                                        Container(
                                                          height: 30.0,
                                                          //width: 55.0,
                                                          margin: const EdgeInsets.only(
                                                              left: 20.0,
                                                              right: 12.0,
                                                              top: 12.0),
                                                          decoration: BoxDecoration(
                                                            color: const Color(0xff115E59),
                                                            //border: Border.all(color: const Color(0xff0E7490)),
                                                            borderRadius:
                                                            BorderRadius.circular(
                                                              8.0,
                                                            ),
                                                          ),
                                                          child: const Align(
                                                            alignment: Alignment.center,
                                                            child: Padding(
                                                              padding: EdgeInsets.all(5.0),
                                                              child:
                                                              Text(
                                                                "Design sent for approval",
                                                                style: TextStyle(
                                                                    color: Color(0xffFFFFFF),
                                                                    fontSize: 11.0,
                                                                    fontFamily: 'Inter',
                                                                    fontWeight:
                                                                    FontWeight.w500),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ] else ...[
                                                        Container(
                                                          height: 30.0,
                                                          //width: 55.0,
                                                          margin: const EdgeInsets.only(
                                                              left: 20.0,
                                                              right: 12.0,
                                                              top: 12.0),
                                                          decoration: BoxDecoration(
                                                            color: const Color(0xffB91C1C),
                                                            //border: Border.all(color: const Color(0xff0E7490)),
                                                            borderRadius:
                                                            BorderRadius.circular(
                                                              8.0,
                                                            ),
                                                          ),
                                                          child: const Align(
                                                            alignment: Alignment.center,
                                                            child: Padding(
                                                              padding: EdgeInsets.all(5.0),
                                                              child:
                                                              Text(
                                                                "Risk",
                                                                style: TextStyle(
                                                                    color: Color(0xffFFFFFF),
                                                                    fontSize: 11.0,
                                                                    fontFamily: 'Inter',
                                                                    fontWeight:
                                                                    FontWeight.w500),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                      Spacer(flex: 1,),
                                                      Container(
                                                        margin: const EdgeInsets.only(
                                                            left: 12.0, top: 16.0),
                                                        child: const Text(
                                                          "1.2",
                                                          style: TextStyle(
                                                              color: Color(0xffFFFFFF),
                                                              fontSize: 14.0,
                                                              fontFamily: 'Inter',
                                                              fontWeight: FontWeight.w500),
                                                        ),
                                                      ),
                                                      Spacer(flex: 1,),
                                                      Container(
                                                        width: 184.0,
                                                        margin: const EdgeInsets.only(
                                                            left: 24.0, top: 16.0),
                                                        child: const Text(
                                                          "Ticket not updated for 3 days",
                                                          style: TextStyle(
                                                              color: Color(0xffFFFFFF),
                                                              fontSize: 14.0,
                                                              fontFamily: 'Inter',
                                                              fontWeight: FontWeight.w500),
                                                        ),
                                                      ),
                                                      Spacer(flex: 1,),
                                                      Container(
                                                        margin: const EdgeInsets.only(
                                                            left: 15.0, top: 16.0),
                                                        child: const Text(
                                                          "13 Jul",
                                                          style: TextStyle(
                                                              color: Color(0xffFFFFFF),
                                                              fontSize: 14.0,
                                                              fontFamily: 'Inter',
                                                              fontWeight: FontWeight.w500),
                                                        ),
                                                      ),
                                                      Spacer(flex: 1,),
                                                      Container(
                                                        //width: MediaQuery.of(context).size.width/2,
                                                        // height: MediaQuery.of(context).size.height/2,
                                                        margin: const EdgeInsets.only(
                                                            left: 46.0, top: 16.0),
                                                        child: const Text(
                                                          "28 Aug",
                                                          style: TextStyle(
                                                              color: Color(0xffFFFFFF),
                                                              fontSize: 14.0,
                                                              fontFamily: 'Inter',
                                                              fontWeight:
                                                              FontWeight.w500),
                                                        ),
                                                      ),
                                                      Spacer(flex: 1,),


                                                      Container(
                                                        margin: const EdgeInsets.only(
                                                            left: 52.0, top: 16.0),
                                                        child: const Text(
                                                          "29 Jul",
                                                          style: TextStyle(
                                                              color: Color(0xffFFFFFF),
                                                              fontSize: 14.0,
                                                              fontFamily: 'Inter',
                                                              fontWeight:
                                                              FontWeight.w500),
                                                        ),
                                                      ),
                                                      Spacer(flex: 1,),

                                                      Container(
                                                        margin: const EdgeInsets.only(
                                                            left: 50.0, top: 16.0),
                                                        child: const Text(
                                                          "13 Aug",
                                                          style: TextStyle(
                                                              color: Color(0xffFFFFFF),
                                                              fontSize: 14.0,
                                                              fontFamily: 'Inter',
                                                              fontWeight:
                                                              FontWeight.w500),
                                                        ),
                                                      ),
                                                      Spacer(flex: 1,),

                                                      Container(
                                                        margin: const EdgeInsets.only(
                                                            left: 45.0, top: 16.0),
                                                        width: 80,
                                                        height: 32,
                                                        child: Stack(
                                                          children: [
                                                            Positioned(
                                                              top: 0,
                                                              child: ClipRRect(
                                                                borderRadius: BorderRadius.circular(100),
                                                                child: Image.network(
                                                                  'https://images.unsplash.com/photo-1529665253569-6d01c0eaf7b6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cHJvZmlsZXxlbnwwfHwwfHw%3D&w=1000&q=80',
                                                                  width: 32,
                                                                  height: 32,
                                                                  fit: BoxFit.cover,
                                                                ),
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: 16,
                                                              child: ClipRRect(
                                                                borderRadius: BorderRadius.circular(100),
                                                                child: Image.network(
                                                                  'https://media.istockphoto.com/photos/side-view-of-one-young-woman-picture-id1134378235?k=20&m=1134378235&s=612x612&w=0&h=0yIqc847atslcQvC3sdYE6bRByfjNTfOkyJc5e34kgU=',
                                                                  width: 32,
                                                                  height: 32,
                                                                  fit: BoxFit.cover,
                                                                ),
                                                              ),
                                                            ),

                                                            Positioned(
                                                              left: 30,
                                                              child: ClipRRect(
                                                                borderRadius: BorderRadius.circular(100),
                                                                child: Container(
                                                                  width: 32,
                                                                  height: 32,
                                                                  color: Color(0xff334155),
                                                                  child: const Center(child: Text('+1',style: TextStyle(
                                                                      color: Color(0xffFFFFFF),
                                                                      fontSize: 12.0,
                                                                      fontFamily: 'Inter',
                                                                      fontWeight:
                                                                      FontWeight.w500),)),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),

                                                    ],
                                                  ),
                                                  const SizedBox(
                                                    height: 8.0,
                                                  ),
                                                  Container(
                                                      margin: const EdgeInsets.only(
                                                          left: 16.0, right: 16.0),
                                                      child: const Divider(
                                                        color: Color(0xff94A3B8),
                                                        thickness: 0.1,
                                                      )),
                                                ],
                                              ),
                                            );
                                          },
                                        );

                                      }

                                  );
                                }
                              }
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),



            ),
      ),
    );
  }

  Future<void> api() async {
    try{
      var response= await http.post(Uri.parse('https://staging-api.vanwijk.app/api/scan/deregister/cancel/complete'),
        body:jsonEncode ({
          "code": 20221090915620,
          "reason": 'test',
        }),
        headers: {
           "Content-Type": "application/json",
          "Authorization": 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczpcL1wvc3RhZ2luZy1hcGkudmFud2lqay5hcHBcL2FwaVwvbG9naW4iLCJpYXQiOjE2NjI5OTk3MzIsImV4cCI6MTY2MzAwMzMzMiwibmJmIjoxNjYyOTk5NzMyLCJqdGkiOiJ3T05yaDBLZHVvenFhbDBSIiwic3ViIjoxLCJwcnYiOiIyM2JkNWM4OTQ5ZjYwMGFkYjM5ZTcwMWM0MDA4NzJkYjdhNTk3NmY3In0.h20MqyqGtvq8mHw0X7IXJkjV_gH2wxgaANQY8IKGl3Q'
        },
      );
      print(response.body);
      // ignore: unrelated_type_equality_checks
      if(response.statusCode==200){
        var responseJson = jsonDecode(response.body.toString()) as Map<String,dynamic>;
        final stringRes = JsonEncoder.withIndent('').convert(responseJson);
        print(stringRes);
        print("yes Creaete");
        print(response.body);
      }else{
        print("failuree");
      }
    } catch(e) {
      // print('error caught: $e');
    }
  }

  Future<String?> getSelectStatus() async {
    String? value;
    if (value == null) {
      var response = await http.get(
        Uri.parse("http://zeusapitst.crebos.online/api/v1/status"),
        headers: {
          "Accept": "application/json",
          "Authorization": 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiNzliY2M1NzFjNWFlNzMzNzkxMGY2ZWU0ZjU1YzBhYzA0ZDljNjdkNzhjZmJhZTNmYTAyOWFkOWIyZDY4NGIwOGZiMTFlMzIzNTM2YjFiNDQiLCJpYXQiOjE2NjIzMTY1MzIuNzczOTQ3LCJuYmYiOjE2NjIzMTY1MzIuNzczOTUxLCJleHAiOjE2OTM4NTI1MzIuNjU0NTE0LCJzdWIiOiIxMSIsInNjb3BlcyI6W119.1U8cAr8-DcLT3ZoqknGd3qSyjJZJiu89wxIgb8vsafP6z8rOOGkg7C9ZF3oDbZX4dwEeRlH9pCy_CKsUIL0_zizJHhbbDbn_IUXdhvJXizmBV2GE-W4XAzsExF-81_k02AY7nZ9y2u0ITzRKw-WyJe1zjvmQz5XJ9LEoz767o00u274XFzByGf42Xpd4S_RyRujJ9vGgqC72aIcgjQWr1KW2cJP7FRKlSAyml4NXfZqdjr8OT8ldgHHbBqBfVkGKZN3jpunLCl90VczGiQ-VewFcvdC264DI0uelBYHEW99oJeLmxTiBK5pl2pUAx-lULDdB-A68OvB0jsCOPtbbk0fjBSib0dMw9ckaZ7d69ug7976gIlJ_PYoL0_VehpYHtNVagaImGI7LWgE0RbJIg85SUshNZOi7NIdD3-VU1FFTVsnQfL9Pby8YNac9OeIbAY8n9s8AUFT8iVJKM1QRhqSvZIRx_5Gwdu1GELkoOo33cvwZEt0cpIloQvg8twk0KSvLw1XfEGmqJue1dGPk8NE1v_wtNwspptsUgqPejlFvXK-trJU9HBYpeNKXaBXSpdwWPnSLxzGF2m_isGeZtREwoYBCtQ2VNaKzFsdQHwRUguzQ84Td04VJKpi3j3lgT4TYoV24T5O47Dt1sNXfdTDsLPPWRn0bvR33B084WJc'
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body.toString());
        List<dynamic> mdata = map["data"];
        setState(() {
          _statusList = mdata;
        });
        //var res = response.body;
        //  print('helloDepartment' + res);
        //  DepartmentResponce peopleList = DepartmentResponce.fromJson(json.decode(res));
        // return peopleList;

        // final stringRes = JsonEncoder.withIndent('').convert(res);
        //  print(stringRes);
      } else {
        print("failed to much");
      }
      return value;
    }

  }

  Future<String?> getCurrency() async {
    String? value;
    if (value == null) {
      var response = await http.get(
        Uri.parse("http://zeusapitst.crebos.online/api/v1/currencies"),
        headers: {
          "Accept": "application/json",
          "Authorization": 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiNzliY2M1NzFjNWFlNzMzNzkxMGY2ZWU0ZjU1YzBhYzA0ZDljNjdkNzhjZmJhZTNmYTAyOWFkOWIyZDY4NGIwOGZiMTFlMzIzNTM2YjFiNDQiLCJpYXQiOjE2NjIzMTY1MzIuNzczOTQ3LCJuYmYiOjE2NjIzMTY1MzIuNzczOTUxLCJleHAiOjE2OTM4NTI1MzIuNjU0NTE0LCJzdWIiOiIxMSIsInNjb3BlcyI6W119.1U8cAr8-DcLT3ZoqknGd3qSyjJZJiu89wxIgb8vsafP6z8rOOGkg7C9ZF3oDbZX4dwEeRlH9pCy_CKsUIL0_zizJHhbbDbn_IUXdhvJXizmBV2GE-W4XAzsExF-81_k02AY7nZ9y2u0ITzRKw-WyJe1zjvmQz5XJ9LEoz767o00u274XFzByGf42Xpd4S_RyRujJ9vGgqC72aIcgjQWr1KW2cJP7FRKlSAyml4NXfZqdjr8OT8ldgHHbBqBfVkGKZN3jpunLCl90VczGiQ-VewFcvdC264DI0uelBYHEW99oJeLmxTiBK5pl2pUAx-lULDdB-A68OvB0jsCOPtbbk0fjBSib0dMw9ckaZ7d69ug7976gIlJ_PYoL0_VehpYHtNVagaImGI7LWgE0RbJIg85SUshNZOi7NIdD3-VU1FFTVsnQfL9Pby8YNac9OeIbAY8n9s8AUFT8iVJKM1QRhqSvZIRx_5Gwdu1GELkoOo33cvwZEt0cpIloQvg8twk0KSvLw1XfEGmqJue1dGPk8NE1v_wtNwspptsUgqPejlFvXK-trJU9HBYpeNKXaBXSpdwWPnSLxzGF2m_isGeZtREwoYBCtQ2VNaKzFsdQHwRUguzQ84Td04VJKpi3j3lgT4TYoV24T5O47Dt1sNXfdTDsLPPWRn0bvR33B084WJc'
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body.toString());
        List<dynamic> mdata = map["data"];
        setState(() {
          _currencyName = mdata;
        });
      } else {
        print("failed to much");
      }
      return value;
    }

  }
  Future<String?> getAccountable() async {
    String? value;
    if (value == null) {
      var response = await http.get(
        Uri.parse(AppUrl.accountable_person),
        headers: {
          "Accept": "application/json",
          "Authorization": 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiNzliY2M1NzFjNWFlNzMzNzkxMGY2ZWU0ZjU1YzBhYzA0ZDljNjdkNzhjZmJhZTNmYTAyOWFkOWIyZDY4NGIwOGZiMTFlMzIzNTM2YjFiNDQiLCJpYXQiOjE2NjIzMTY1MzIuNzczOTQ3LCJuYmYiOjE2NjIzMTY1MzIuNzczOTUxLCJleHAiOjE2OTM4NTI1MzIuNjU0NTE0LCJzdWIiOiIxMSIsInNjb3BlcyI6W119.1U8cAr8-DcLT3ZoqknGd3qSyjJZJiu89wxIgb8vsafP6z8rOOGkg7C9ZF3oDbZX4dwEeRlH9pCy_CKsUIL0_zizJHhbbDbn_IUXdhvJXizmBV2GE-W4XAzsExF-81_k02AY7nZ9y2u0ITzRKw-WyJe1zjvmQz5XJ9LEoz767o00u274XFzByGf42Xpd4S_RyRujJ9vGgqC72aIcgjQWr1KW2cJP7FRKlSAyml4NXfZqdjr8OT8ldgHHbBqBfVkGKZN3jpunLCl90VczGiQ-VewFcvdC264DI0uelBYHEW99oJeLmxTiBK5pl2pUAx-lULDdB-A68OvB0jsCOPtbbk0fjBSib0dMw9ckaZ7d69ug7976gIlJ_PYoL0_VehpYHtNVagaImGI7LWgE0RbJIg85SUshNZOi7NIdD3-VU1FFTVsnQfL9Pby8YNac9OeIbAY8n9s8AUFT8iVJKM1QRhqSvZIRx_5Gwdu1GELkoOo33cvwZEt0cpIloQvg8twk0KSvLw1XfEGmqJue1dGPk8NE1v_wtNwspptsUgqPejlFvXK-trJU9HBYpeNKXaBXSpdwWPnSLxzGF2m_isGeZtREwoYBCtQ2VNaKzFsdQHwRUguzQ84Td04VJKpi3j3lgT4TYoV24T5O47Dt1sNXfdTDsLPPWRn0bvR33B084WJc'
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body.toString());
        List<dynamic> mdata = map["data"];
        setState(() {
          _accountableId = mdata;
        });
      } else {
        print("failed to much");
      }
      return value;
    }

  }

  Future<String?> getCustomer() async {
    String? value;
    if (value == null) {
      var response = await http.get(
        Uri.parse("http://zeusapitst.crebos.online/api/v1/customer"),
        headers: {
          "Accept": "application/json",
          "Authorization": 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiNzliY2M1NzFjNWFlNzMzNzkxMGY2ZWU0ZjU1YzBhYzA0ZDljNjdkNzhjZmJhZTNmYTAyOWFkOWIyZDY4NGIwOGZiMTFlMzIzNTM2YjFiNDQiLCJpYXQiOjE2NjIzMTY1MzIuNzczOTQ3LCJuYmYiOjE2NjIzMTY1MzIuNzczOTUxLCJleHAiOjE2OTM4NTI1MzIuNjU0NTE0LCJzdWIiOiIxMSIsInNjb3BlcyI6W119.1U8cAr8-DcLT3ZoqknGd3qSyjJZJiu89wxIgb8vsafP6z8rOOGkg7C9ZF3oDbZX4dwEeRlH9pCy_CKsUIL0_zizJHhbbDbn_IUXdhvJXizmBV2GE-W4XAzsExF-81_k02AY7nZ9y2u0ITzRKw-WyJe1zjvmQz5XJ9LEoz767o00u274XFzByGf42Xpd4S_RyRujJ9vGgqC72aIcgjQWr1KW2cJP7FRKlSAyml4NXfZqdjr8OT8ldgHHbBqBfVkGKZN3jpunLCl90VczGiQ-VewFcvdC264DI0uelBYHEW99oJeLmxTiBK5pl2pUAx-lULDdB-A68OvB0jsCOPtbbk0fjBSib0dMw9ckaZ7d69ug7976gIlJ_PYoL0_VehpYHtNVagaImGI7LWgE0RbJIg85SUshNZOi7NIdD3-VU1FFTVsnQfL9Pby8YNac9OeIbAY8n9s8AUFT8iVJKM1QRhqSvZIRx_5Gwdu1GELkoOo33cvwZEt0cpIloQvg8twk0KSvLw1XfEGmqJue1dGPk8NE1v_wtNwspptsUgqPejlFvXK-trJU9HBYpeNKXaBXSpdwWPnSLxzGF2m_isGeZtREwoYBCtQ2VNaKzFsdQHwRUguzQ84Td04VJKpi3j3lgT4TYoV24T5O47Dt1sNXfdTDsLPPWRn0bvR33B084WJc'
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body.toString());
        List<dynamic> mdata = map["data"];
        setState(() {
          _customerName = mdata;
        });
      } else {
        print("failed to much");
      }
      return value;
    }

  }
}



