import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'dart:typed_data';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:zeus/navigation/tag_model/tag_user.dart';
import 'package:zeus/navigation/tag_model/tagresponse.dart';
import 'package:zeus/routers/routers_class.dart';
import 'package:zeus/utility/dropdrowndata.dart';
import '../DemoContainer.dart';
import '../navigator_tabs/idle/data/project_detail_data/ProjectDetailData.dart';
import '../navigator_tabs/idle/idle.dart';
import 'package:provider/provider.dart';
import 'dart:convert';
import '../utility/app_url.dart';
import '../utility/colors.dart';
import 'package:image_picker_web/image_picker_web.dart';
import 'package:flutter/material.dart';
import 'dart:html' as html;
import 'package:autocomplete_textfield/autocomplete_textfield.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http_parser/http_parser.dart';

import '../utility/constant.dart';
import '../utility/upertextformate.dart';

class MyHomePage extends StatefulWidget {
  final ValueChanged<String> onSubmit;
  final ValueChanged<String> adOnSubmit;
  const MyHomePage({Key? key, required this.onSubmit,required this.adOnSubmit}) : super(key: key);

  @override
  State<MyHomePage> createState() => _NavigationRailState();
}

class _NavigationRailState extends State<MyHomePage>
    with SingleTickerProviderStateMixin {

  AutoCompleteTextField? searchTextField;
  final fieldText = TextEditingController();
  GlobalKey<AutoCompleteTextFieldState<Datum>> key = new GlobalKey();
  static List<Datum> users = <Datum>[];
  bool loading = true;
  List<int>? _selectedFile;
  Uint8List? _bytesData;
  GlobalKey<FormState> _formKey = new GlobalKey<FormState>();
  GlobalKey<FormState> _addFormKey = new GlobalKey<FormState>();
  List<String>abc=[];
  var prefs;
  void change()async{
 prefs = await SharedPreferences.getInstance();
    prefs.setString('val', 'q');
  }
  Future? getList;
  Future getListData(){
    return Provider.of<ProjectDetail>(context, listen: true).changeProfile();
  }
  @override
  void didChangeDependencies() {

    getList=getListData();
    super.didChangeDependencies();
  }

  Image? image;
  Uint8List ? webImage;

  Future? _getTag;
  List addSkills = [];
  String name_ = '';
  String name1 = '';
  bool _autoValidate = false;

  void _submit() {
    setState(() => _submitted = true);
    if (_formKey.currentState!.validate()) {
      widget.onSubmit(name_);
      createProject();
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => MyHomePage(onSubmit: (String value) {  }, adOnSubmit: (String value) {  },)));
    }
  }

  void _editSubmit() {
    setState(() {
      _addSubmitted = true;

    });
    if (_addFormKey.currentState!.validate()) {
      widget.adOnSubmit(name1);
      getAddPeople();
      Navigator.pushNamed(
          context, "/home");
    }
  }

  String capitalize(String value) {
    var result = value[0].toUpperCase();
    bool cap = true;
    for (int i = 1; i < value.length; i++) {
      if (value[i - 1] == " " && cap == true) {
        result = result + value[i].toUpperCase();
      } else {
        result = result + value[i];
        cap = false;
      }
    }
    return result;
  }

  List _addtag=[];

  void getUsers() async {
    var token='Bearer '+storage.read("token");
    var response =
    await http.get(Uri.parse(AppUrl.tags_search),
      headers: {
        "Content-Type": "application/json",
        "Authorization":token,
      },
    );
    if (response.statusCode == 200) {
      print("skills sucess");
      var user=userFromJson(response.body);
      users = user.data!;
      // print('Users: ${users.length}');
      setState(() {

        loading = false;
      });
    } else {
      print("Error getting users.");
      // print(response.body);
    }
  }


  //Add people Api
  Future<void> getAddPeople() async {
    var token='Bearer '+storage.read("token");

    var request = http.MultipartRequest(
        'POST', Uri.parse('http://zeusapitst.crebos.online/api/v1/resource'));
    request.headers.addAll({"Content-Type": "application/json",
      "Authorization":token,
    });
    request.fields['name'] = _name.text.toString();
    request.fields['nickname'] = _nickName.text.toString();
    request.fields['email'] =_emailAddress.text.toString();
    request.fields['phone_number'] =_phoneNumber.text.toString();
    request.fields['password'] ='Nirmaljeet@123';
    request.fields['bio'] =_bio.text.toString();
    request.fields['designation'] =_designation.text.toString();
    request.fields['department_id'] =_depat!;
    request.fields['associate'] ="backend";
    request.fields['salary'] ="2000";
    request.fields['salary_currency'] ="USD";
    request.fields['availibilty_day'] =_availableDay.text.toString();
    request.fields['availibilty_time'] =_availableTime.text.toString();
    request.fields['country'] ="india";
    request.fields['city'] ="mohali";
    request.fields['time_zone'] = _time!;
    // request.fields['skills'] =abc;

    for(int i = 0; i < abc.length; i++){
      request.fields['skills[$i]'] = '${abc[i]}';
    }
    _selectedFile = webImage;
    request.files.add(await http.MultipartFile.fromBytes('image', _selectedFile!,
        contentType: new MediaType('application', 'octet-stream'),
        filename: "file_up"));

    var response = await request.send();
    var responseString = await response.stream.bytesToString();
    if (response.statusCode == 200) {
      final decodedMap = json.decode(responseString);

      print(decodedMap);

      final stringRes = JsonEncoder.withIndent('').convert(decodedMap);
      print(stringRes);
      print("add people created");
    } else {
      print(responseString);
      print("failed people");
    }
  }


  //Update project Api
  Future<void> updateProject() async {
    try {
      var token='Bearer '+storage.read("token");
      var response = await http.post(
        Uri.parse('http://zeusapitst.crebos.online/api/v1/resource'),
        body: jsonEncode({
          "name": _name.text.toString(),
          "nickname": _nickName.text.toString(),
          "email": _emailAddress.text.toString(),
          "phone_number": _phoneNumber.text.toString(),
          "password": 'Nirmaljeet@123',
          "bio": _bio.text.toString(),
          "designation": 'Sr. developer',
          "department_id": _depat,
          "associate": _association.text.toString(),
          "salary": '1900',
          "salary_currency": 'USD',
          "availibilty_day": 'asd',
          "availibilty_time": '10-7',
          "country": _country.text.toString(),
          "city": _enterCity.text.toString(),
          "time_zone": _time,
          //"image":webImage,
          "skills": _tag1,
        }),
        headers: {
          "Content-Type": "application/json",
          "Authorization":token,
        },
      );
      // ignore: unrelated_type_equality_checks
      if (response.statusCode == 200) {
        var responseJson =
            jsonDecode(response.body.toString()) as Map<String, dynamic>;
        final stringRes = JsonEncoder.withIndent('').convert(responseJson);
        print(stringRes);
        print("yes add people");
        print(response.body);
      } else {
        print("failuree");
        print(response.body);
      }
    } catch (e) {
      print('error caught: $e');
    }
  }


  //Create project Api
  Future<void> createProject() async {
    var token='Bearer '+storage.read("token");
    try {
      var response = await http.post(
        Uri.parse(AppUrl.create_project),
        body: jsonEncode({
          "title": _projecttitle.text.toString(),
          "accountable_person_id": _account,
          "customer_id": _custome,
          "crm_task_id": _crmtask.text.toString(),
          "work_folder_id": _warkfolderId.text.toString(),
          "budget": _budget.toString(),
          "currency": "&",
          "estimation_hours":'80',// _estimatehours.toString(),
          "status": _status,
        }),
        headers: {
          "Content-Type": "application/json",
          "Authorization":token,
        },
      );
      // ignore: unrelated_type_equality_checks
      if (response.statusCode == 200) {
        var responseJson =
            jsonDecode(response.body.toString()) as Map<String, dynamic>;
        final stringRes = JsonEncoder.withIndent('').convert(responseJson);
        print(stringRes);
        print("yes Creaete");
        print(response.body);
      } else {
        print("failuree");
      }
    } catch (e) {
      // print('error caught: $e');
    }
  }

 /* Future? getProject() {
    return Provider.of<TagDetail>(context, listen: false).getTagData();
  }*/

  MyDropdownData myDropdownData = MyDropdownData();
  int _selectedIndex = 1;
  DateTime selectedDate = DateTime.now();
  String dropdownvalue = 'Item 1';
  ImagePicker picker = ImagePicker();
  String? _depat, _account, _custome, _curren, _status, _time, _tag;
  bool _submitted = false;
  bool _addSubmitted = false;
  String name = '';
 // var _formKey = GlobalKey<FormState>();

  List _department = [];
  int? position = 0;
  List _accountableId = [];
  List _customerName = [];
  List _currencyName = [];
  List _statusList = [];
  List _timeline = [];
  List addTag = [];
  List<String> _tag1 = [];
  GlobalKey<ScaffoldState>? _key;
  bool? _isSelected;
  List<String>? _filters1 = [
    'User interface',
    'User interface',
    'User interface',
    'User interface',
    'User interface'
  ];
  List<String>? addTag1 = ['Laravel'];
  List<int> add1 = [1];
  bool imageavail = false;
 // XFile? webImage;
  var isIndex = 0;
  var isLoading = false;



  @override
  void initState() {
    //_getTag = getProject();
    getUsers();
    change();
    // webImage=_pickedImage as Uint8List?;
    _isSelected = false;
    //_getProjectDetail=getProject();
    getAddpeople();
    getTagpeople();
    getDepartment();
    getAccountable();
    getCustomer();
    getCurrency();
    getSelectStatus();
    getTimeline();
    super.initState();
  }

  final TextEditingController _name = TextEditingController();
  final TextEditingController _nickName = TextEditingController();
  final TextEditingController _password = TextEditingController();
  final TextEditingController _bio = TextEditingController();
  final TextEditingController _designation = TextEditingController();
  final TextEditingController _association = TextEditingController();
  final TextEditingController _salary = TextEditingController();
  final TextEditingController _salaryCurrency = TextEditingController();
  final TextEditingController _availableDay = TextEditingController();
  final TextEditingController _availableTime = TextEditingController();
  final TextEditingController _search = TextEditingController();
  final TextEditingController _country = TextEditingController();
  final TextEditingController _enterCity = TextEditingController();
  final TextEditingController _phoneNumber = TextEditingController();
  final TextEditingController _emailAddress = TextEditingController();

  //creatrptoject
  TextEditingController _projecttitle = TextEditingController();
  final TextEditingController _crmtask = TextEditingController();
  final TextEditingController _warkfolderId = TextEditingController();
  final TextEditingController _budget = TextEditingController();
  final TextEditingController _estimatehours = TextEditingController();

  Future<void> _selectDate(setState) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        builder: (BuildContext context, Widget? child) {
          return Theme(
            data: ThemeData.light().copyWith(
              primaryColor: const Color(0xff0F172A),
              accentColor: const Color(0xff0F172A),
              colorScheme: ColorScheme.light(primary: const Color(0xff0F172A)),
              buttonTheme: ButtonThemeData(textTheme: ButtonTextTheme.primary),
            ),
            child: child!,
          );
        },
        initialDate: selectedDate,
        firstDate: new DateTime.now().subtract(new Duration(days: 0)),
        initialEntryMode: DatePickerEntryMode.calendarOnly,
        lastDate: DateTime(2101));

    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  var items = [
    'Item 1',
    'Item 2',
    'Item 3',
    'Item 4',
    'Item 5',
  ];

  final List<Widget> _mainContents = [
    Container(
      color: const Color(0xff0F172A),
      alignment: Alignment.center,
      child: const Text(
        'Home',
        style: TextStyle(fontSize: 40),
      ),
    ),
    Idle(),
    Container(
      child: const Navigator(
        onGenerateRoute: generateRoute,
        initialRoute: '/peopleList',
      ),
    ),
    Container(
      color: const Color(0xff0F172A),
      alignment: Alignment.center,
      child: const Text(
        'Coming Soon',
        style: TextStyle(fontSize: 40,color: Colors.white),
      ),
    ),
    Container(
      color: const Color(0xff0F172A),
      alignment: Alignment.center,
      child: const Text(
        'Coming Soon',
        style: TextStyle(fontSize: 40,color: Colors.white),
      ),
    ),
    Container(
      color: const Color(0xff0F172A),
      alignment: Alignment.center,
      child: const Text(
        'Coming Soon',
        style: TextStyle(fontSize: 40,color: Colors.white),
      ),
    ),
    Container(
      color: const Color(0xff0F172A),
      alignment: Alignment.center,
      child: const Text(
        'Coming Soon',
        style: TextStyle(fontSize: 40,color: Colors.white),
      ),
    ),
  ];


  //Create project popup
  void showAlertDialog(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return StatefulBuilder(
            builder: (context, setState) => AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              backgroundColor: const Color(0xff1E293B),
              content: Form(
                key: _formKey,
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.40,
                  height: 620.0, //MediaQuery.of(context).size.height * 0.85,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                              margin: const EdgeInsets.only(top: 0.0, left: 10.0),
                              child: const Text(
                                'Create Project',
                                style: TextStyle(
                                    color: Color(0xffFFFFFF),
                                    fontSize: 18.0,
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w700),
                              )),
                          GestureDetector(
                            onTap: () {
                              //createProject();
                              Navigator.of(context).pop();
                            },
                            child: Container(
                              margin: const EdgeInsets.only(top: 0.0, right: 10.0),
                              width: 30,
                              height: 30,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: const Color(0xff1E293B),
                                border: Border.all(
                                    color: Color(0xff334155), width: 0.6),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: SvgPicture.asset(
                                  'images/cross.svg',
                                ),
                              ),
                            ),
                          )
                        ],
                      ),

                      Stack(
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width * 0.99,
                            margin: const EdgeInsets.only(
                                top: 15.0, left: 10.0, right: 10.0),
                            height: 56.0,
                            decoration: BoxDecoration(
                              color: const Color(0xff334155),
                              //border: Border.all(color:  const Color(0xff1E293B)),
                              borderRadius: BorderRadius.circular(
                                8.0,
                              ),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0xff475569),
                                  offset: Offset(
                                    0.0,
                                    2.0,
                                  ),
                                  blurRadius: 0.0,
                                  spreadRadius: 0.0,
                                ), //BoxShadow
                              ],
                            ),

                          ),

                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                  margin:
                                  const EdgeInsets.only(top: 24.0, left: 26.0),
                                  child: const Text(
                                    "Project title",
                                    style: TextStyle(
                                        fontSize: 13.0,
                                        color: Color(0xff64748B),
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w500),
                                  )),

                            ],
                          ),

                          TextFormField(

                            controller:_projecttitle,
                            inputFormatters: [
                              UpperCaseTextFormatter()
                            ],
                            textCapitalization: TextCapitalization.characters,
                         //   autovalidateMode: AutovalidateMode.onUserInteraction,
                            cursorColor: const Color(0xffFFFFFF),
                            style: const TextStyle(color: Color(0xffFFFFFF)),
                            textAlignVertical: TextAlignVertical.bottom,
                            keyboardType: TextInputType.text,
                            decoration: const InputDecoration(
                                contentPadding: EdgeInsets.only(
                                  bottom: 16.0,
                                  top: 54.0,
                                  right: 10,
                                  left: 26.0,
                                ),
                                errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                border: InputBorder.none,
                                // hintText: 'Project title',
                                hintStyle: TextStyle(
                                    fontSize: 14.0,
                                    color: Color(0xffFFFFFF),
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w500)),
                            //  autovalidate: _autoValidate ,
                            autovalidateMode: _submitted
                                ? AutovalidateMode.onUserInteraction
                                : AutovalidateMode.disabled,

                            validator: (value) {
                              //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                              if(value!.isEmpty){
                                return 'Please enter';
                              }
                              return null;
                            },
                            onChanged: (text) => setState(() => name_ = text),
                          ),
                        ],
                      ),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                           Container(
                               width:MediaQuery.of(context).size.width * 0.19,
                                margin:
                                    const EdgeInsets.only(top: 15.0, left: 10.0),
                                height: 56.0,
                                decoration: BoxDecoration(
                                  color: const Color(0xff334155),
                                  //border: Border.all(color:  const Color(0xff1E293B)),
                                  borderRadius: BorderRadius.circular(
                                    8.0,
                                  ),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color(0xff475569),
                                      offset: Offset(
                                        0.0,
                                        2.0,
                                      ),
                                      blurRadius: 0.0,
                                      spreadRadius: 0.0,
                                    ), //BoxShadow
                                  ],
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                        margin: const EdgeInsets.only(
                                            top: 6.0, left: 16.0),
                                        child: const Text(
                                          "AP",
                                          style: TextStyle(
                                              fontSize: 13.0,
                                              color: Color(0xff64748B),
                                              fontFamily: 'Inter',
                                              fontWeight: FontWeight.w500),
                                        )),
                                    Container(
                                      margin: const EdgeInsets.only(
                                          top: 5.0, left: 0.0),
                                      height: 20.0,
                                      child: Container(
                                          margin: const EdgeInsets.only(
                                              left: 15.0, right: 20.0),
                                          child: StatefulBuilder(
                                            builder: (BuildContext context,
                                                StateSettersetState) {
                                              return DropdownButtonHideUnderline(
                                                child: DropdownButton(
                                                  dropdownColor:
                                                      ColorSelect.class_color,
                                                  value: _account,
                                                  underline: Container(),
                                                  hint: const Text(
                                                    "Select Accountable Persons",
                                                    style: TextStyle(
                                                        fontSize: 14.0,
                                                        color: Color(0xffFFFFFF),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                            FontWeight.w500),
                                                  ),
                                                  isExpanded: true,
                                                  icon: Icon(                // Add this
                                                    Icons.arrow_drop_down,  // Add this
                                                    color: Color(0xff64748B),

                                                   // Add this
                                                  ),
                                                 /* icon: Image.asset(
                                                    "images/dropdown.jpg",
                                                  //  color: const Color(0xff64748B),
                                                    width: 8.0,
                                                    height: 8.0,
                                                  ),*/
                                                  items: _accountableId.map((items) {
                                                    return DropdownMenuItem(
                                                      value:
                                                          items['id'].toString(),
                                                      child: Text(
                                                        items['name'],
                                                        style: const TextStyle(
                                                            fontSize: 14.0,
                                                            color:
                                                                Color(0xffFFFFFF),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight.w500),
                                                      ),
                                                    );
                                                  }).toList(),
                                                  onChanged: (newValue) {
                                                    setState(() {
                                                    /*  validator: (value) => value == null ? 'field required' : null,
                                                      onSaved: (value) => name = value,*/
                                                      _account = newValue;
                                                      print("account:$_account");
                                                    });
                                                  },
                                                ),
                                              );
                                            },
                                          )),
                                    ),
                                  ],
                                )),

                          const SizedBox(
                            width: 16.0,
                          ),

                          Container(
                              width:MediaQuery.of(context).size.width * 0.18,
                                margin:
                                    const EdgeInsets.only(top: 15.0, right: 10.0),
                                height: 56.0,
                                decoration: BoxDecoration(
                                  color: const Color(0xff334155),
                                  //border: Border.all(color:  const Color(0xff1E293B)),
                                  borderRadius: BorderRadius.circular(
                                    8.0,
                                  ),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color(0xff475569),
                                      offset: Offset(
                                        0.0,
                                        2.0,
                                      ),
                                      blurRadius: 0.0,
                                      spreadRadius: 0.0,
                                    ), //BoxShadow
                                  ],
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                        margin: const EdgeInsets.only(
                                            top: 6.0, left: 16.0),
                                        child: const Text(
                                          "Customer",
                                          style: TextStyle(
                                              fontSize: 13.0,
                                              color: Color(0xff64748B),
                                              fontFamily: 'Inter',
                                              fontWeight: FontWeight.w500),
                                        )),
                                    Container(
                                        margin: const EdgeInsets.only(
                                            top: 5.0, right: 18.0, left: 15.0),
                                        height: 20.0,
                                        child: StatefulBuilder(
                                          builder: (BuildContext context,
                                              StateSettersetState) {
                                            return DropdownButtonHideUnderline(
                                              child: DropdownButton(
                                                dropdownColor:
                                                    ColorSelect.class_color,
                                                value: _custome,
                                                underline: Container(),
                                                hint: const Text(
                                                  "Select Customer",
                                                  style: TextStyle(
                                                      fontSize: 14.0,
                                                      color: Color(0xffFFFFFF),
                                                      fontFamily: 'Inter',
                                                      fontWeight:
                                                          FontWeight.w500),
                                                ),
                                                isExpanded: true,
                                                icon: Icon(                // Add this
                                                  Icons.arrow_drop_down,  // Add this
                                                  color: Color(0xff64748B),

                                                  // Add this
                                                ),
                                                items: _customerName.map((items) {
                                                  return DropdownMenuItem(
                                                    value: items['id'].toString(),
                                                    child: Text(
                                                      items['name'],
                                                      style: const TextStyle(
                                                          fontSize: 14.0,
                                                          color:
                                                              Color(0xffFFFFFF),
                                                          fontFamily: 'Inter',
                                                          fontWeight:
                                                              FontWeight.w500),
                                                    ),
                                                  );
                                                }).toList(),
                                                onChanged: (newValue) {
                                                  setState(() {
                                                    _custome = newValue;
                                                    print("account:$_custome");
                                                  });
                                                },
                                              ),
                                            );
                                          },
                                        )),
                                  ],
                                )),

                        ],
                      ),

                      Stack(
                        children: [
                          Container(
                              width: MediaQuery.of(context).size.width * 0.99,
                              margin: const EdgeInsets.only(
                                  top: 24.0, left: 10.0, right: 10.0),
                              height: 56.0,
                              decoration: BoxDecoration(
                                color: const Color(0xff334155),
                                //border: Border.all(color:  const Color(0xff1E293B)),
                                borderRadius: BorderRadius.circular(
                                  8.0,
                                ),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Color(0xff475569),
                                    offset: Offset(
                                      0.0,
                                      2.0,
                                    ),
                                    blurRadius: 0.0,
                                    spreadRadius: 0.0,
                                  ), //BoxShadow
                                ],
                              ),
                          ),

                         Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                          margin:
                          const EdgeInsets.only(top: 33.0, left: 26.0),
                          child: const Text(
                            "CRM task ID",
                            style: TextStyle(
                                fontSize: 13.0,
                                color: Color(0xff64748B),
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w500),
                          )),

                    ],
                  ),

                          TextFormField(
                            controller: _crmtask,
                            cursorColor: const Color(0xffFFFFFF),
                            style:
                            const TextStyle(color: Color(0xffFFFFFF)),
                            textAlignVertical: TextAlignVertical.bottom,
                            keyboardType: TextInputType.text,
                            decoration: const InputDecoration(
                                errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                contentPadding: EdgeInsets.only(
                                  bottom: 16.0,
                                  top: 63.0,
                                  right: 0,
                                  left: 26.0,
                                ),
                                border: InputBorder.none,
                                // hintText: 'Project title',
                                hintStyle: TextStyle(
                                    fontSize: 14.0,
                                    color: Color(0xffFFFFFF),
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w500)),
                            autovalidateMode: _submitted
                                ? AutovalidateMode.onUserInteraction
                                : AutovalidateMode.disabled,
                            validator: (value) {
                              //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                              if(value!.isEmpty){
                                return 'Please enter';
                              }
                              return null;
                            },
                            onChanged: (text) => setState(() => name_ = text),
                          ),
                      ],
                      ),

                      Stack(
                        children: [
                          Container(
                              width: MediaQuery.of(context).size.width * 0.99,
                              margin: const EdgeInsets.only(
                                  top: 15.0, left: 10.0, right: 10.0),
                              height: 56.0,
                              decoration: BoxDecoration(
                                color: const Color(0xff334155),
                                //border: Border.all(color:  const Color(0xff1E293B)),
                                borderRadius: BorderRadius.circular(
                                  8.0,
                                ),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Color(0xff475569),
                                    offset: Offset(
                                      0.0,
                                      2.0,
                                    ),
                                    blurRadius: 0.0,
                                    spreadRadius: 0.0,
                                  ), //BoxShadow
                                ],
                              ),
                          ),

                          Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                          margin:
                          const EdgeInsets.only(top: 26.0, left: 26.0),
                          child: const Text(
                            "Work Folder ID:",
                            style: TextStyle(
                                fontSize: 13.0,
                                color: Color(0xff64748B),
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w500),
                          )),

                    ],
                  ),

                          TextFormField(
                            controller: _warkfolderId,
                            cursorColor: const Color(0xffFFFFFF),
                            style:
                            const TextStyle(color: Color(0xffFFFFFF)),
                            textAlignVertical: TextAlignVertical.bottom,
                            keyboardType: TextInputType.text,
                            decoration: const InputDecoration(
                                errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                contentPadding: EdgeInsets.only(
                                  bottom: 16.0,
                                  top: 55.0,
                                  right: 0,
                                  left: 26.0,
                                ),
                                border: InputBorder.none,
                                //  hintText: 'Project title',
                                hintStyle: TextStyle(
                                    fontSize: 14.0,
                                    color: Color(0xffFFFFFF),
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w500)),
                            autovalidateMode: _submitted
                                ? AutovalidateMode.onUserInteraction
                                : AutovalidateMode.disabled,
                            validator: (value) {
                              //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                              if(value!.isEmpty){
                                return 'Please enter';
                              }
                              return null;
                            },
                            onChanged: (text) => setState(() => name_ = text),
                          ),

                        ],
                      ),


                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [

                          Expanded(
                            flex: 4,
                            child: Stack(
                              children: [
                                Container(
                                  width: MediaQuery.of(context).size.width * 0.10,
                                  margin:
                                  const EdgeInsets.only(top: 15.0, left: 10.0),
                                  height: 56.0,
                                  decoration: BoxDecoration(
                                    color: const Color(0xff334155),
                                    //border: Border.all(color:  const Color(0xff1E293B)),
                                    borderRadius: BorderRadius.circular(
                                      8.0,
                                    ),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Color(0xff475569),
                                        offset: Offset(
                                          0.0,
                                          2.0,
                                        ),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                  ),
                                ),

                                Column(

                                  children: [
                                    Container(
                                        margin: const EdgeInsets.only(
                                            top: 26.0, left: 26.0),
                                        child: const Text(
                                          "Budget",
                                          style: TextStyle(
                                              fontSize: 13.0,
                                              color: Color(0xff64748B),
                                              fontFamily: 'Inter',
                                              fontWeight: FontWeight.w500),
                                        )),



                                  ],
                                ),

                                TextFormField(
                                  controller: _budget,
                                  cursorColor: const Color(0xffFFFFFF),
                                  style: const TextStyle(
                                      color: Color(0xffFFFFFF)),
                                  textAlignVertical: TextAlignVertical.bottom,
                                  keyboardType: TextInputType.text,
                                  decoration: const InputDecoration(
                                      errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                      contentPadding: EdgeInsets.only(
                                        bottom: 18.0,
                                        top: 55.0,
                                        right: 0,
                                        left: 26.0,
                                      ),
                                      border: InputBorder.none,
                                      //hintText: 'Project title',
                                      hintStyle: TextStyle(
                                          fontSize: 14.0,
                                          color: Color(0xffFFFFFF),
                                          fontFamily: 'Inter',
                                          fontWeight: FontWeight.w500)),
                                  autovalidateMode: _submitted
                                      ? AutovalidateMode.onUserInteraction
                                      : AutovalidateMode.disabled,
                                  validator: (value) {
                                    //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                    if(value!.isEmpty){
                                      return 'Please enter';
                                    }
                                    return null;
                                  },
                                  onChanged: (text) => setState(() => name_ = text),
                                ),

                              ],
                            ),
                          ),

                          const SizedBox(
                            width: 16.0,
                          ),

                          Expanded(
                            flex: 2,
                            child: Container(
                              width: MediaQuery.of(context).size.width * 0.07,
                              margin: const EdgeInsets.only(top: 3.0),
                              height: 56.0,
                              decoration: BoxDecoration(
                                color: const Color(0xff334155),
                                //border: Border.all(color:  const Color(0xff1E293B)),
                                borderRadius: BorderRadius.circular(
                                  8.0,
                                ),
                              ),
                              child: Container(
                                  margin: const EdgeInsets.only(
                                      left: 13.0, right: 18.0),
                                  // padding: const EdgeInsets.all(2.0),
                                  child: StatefulBuilder(
                                    builder: (BuildContext context,
                                        StateSettersetState) {
                                      return DropdownButtonHideUnderline(
                                        child: DropdownButton(
                                          dropdownColor: ColorSelect.class_color,
                                          value: _curren,
                                          underline: Container(),
                                          hint: const Text(
                                            "€",
                                            style: TextStyle(
                                                fontSize: 14.0,
                                                color: Color(0xffFFFFFF),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          ),
                                          isExpanded: true,
                                          icon: const Icon(                // Add this
                                            Icons.arrow_drop_down,  // Add this
                                            color: Color(0xff64748B),

                                            // Add this
                                          ),
                                          items: _currencyName.map((items) {
                                            return DropdownMenuItem(
                                              value: items['id'].toString(),
                                              child: Text(
                                                items['currency']['symbol'],
                                                style: const TextStyle(
                                                    fontSize: 14.0,
                                                    color: Color(0xffFFFFFF),
                                                    fontFamily: 'Inter',
                                                    fontWeight: FontWeight.w400),
                                              ),
                                            );
                                          }).toList(),
                                          onChanged: (newValue) {
                                            setState(() {
                                              _curren = newValue;
                                            });
                                          },
                                        ),
                                      );
                                    },
                                  )),
                            ),
                          ),

                          const SizedBox(
                            width: 18.0,
                          ),

                          Expanded(
                            flex: 7,
                            child: Stack(
                                  children: [
                                    Container(
                                        width:MediaQuery.of(context).size.width * 0.19,
                                        margin:
                                        const EdgeInsets.only(top: 15.0, right: 10.0),
                                        height: 56.0,
                                        decoration: BoxDecoration(
                                          color: const Color(0xff334155),
                                          //border: Border.all(color:  const Color(0xff1E293B)),
                                          borderRadius: BorderRadius.circular(
                                            8.0,
                                          ),
                                          boxShadow: const [
                                            BoxShadow(
                                              color: Color(0xff475569),
                                              offset: Offset(
                                                0.0,
                                                2.0,
                                              ),
                                              blurRadius: 0.0,
                                              spreadRadius: 0.0,
                                            ), //BoxShadow
                                          ],
                                        ),
                                    ),

                                     Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                                margin: const EdgeInsets.only(
                                         top: 26.0, left: 16.0),
                                child: const Text(
                                  "Estimated hours",
                                  style: TextStyle(
                                      fontSize: 13.0,
                                      color: Color(0xff64748B),
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500),
                                )),

                    ],
                  ),

                                    TextFormField(
                                      controller: _estimatehours,
                                      cursorColor: const Color(0xffFFFFFF),
                                      style: const TextStyle(
                                          color: Color(0xffFFFFFF)),
                                      textAlignVertical:
                                      TextAlignVertical.bottom,
                                      keyboardType: TextInputType.text,
                                      decoration: const InputDecoration(
                                          errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                          contentPadding: EdgeInsets.only(
                                            bottom: 18.0,
                                            top: 55.0,
                                            right: 0,
                                            left: 17.0,
                                          ),
                                          border: InputBorder.none,
                                          //   hintText: 'Project title',
                                          hintStyle: TextStyle(
                                              fontSize: 14.0,
                                              color: Color(0xffFFFFFF),
                                              fontFamily: 'Inter',
                                              fontWeight: FontWeight.w500)),
                                      autovalidateMode: _submitted
                                          ? AutovalidateMode.onUserInteraction
                                          : AutovalidateMode.disabled,
                                      validator: (value) {
                                        //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                        if(value!.isEmpty){
                                          return 'Please enter';
                                        }
                                        return null;
                                      },
                                      onChanged: (text) => setState(() => name_ = text),
                                    ),
                                  ],
                                ),
                          ),

                        ],
                      ),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                         Container(
                              width:MediaQuery.of(context).size.width * 0.18,
                              margin:
                                  const EdgeInsets.only(top: 15.0, left: 10.0),
                              height: 56.0,
                              decoration: BoxDecoration(
                                color: const Color(0xff334155),
                                //border: Border.all(color:  const Color(0xff1E293B)),
                                borderRadius: BorderRadius.circular(
                                  8.0,
                                ),
                              ),
                              child: Container(
                                  margin: const EdgeInsets.only(
                                      left: 16.0, right: 20.0),
                                  // padding: const EdgeInsets.all(2.0),
                                  child: StatefulBuilder(
                                    builder: (BuildContext context,
                                        StateSettersetState) {
                                      return DropdownButtonHideUnderline(
                                        child: DropdownButton(
                                          dropdownColor: ColorSelect.class_color,
                                          value: _status,
                                          underline: Container(),
                                          hint: const Text(
                                            "Select Status",
                                            style: TextStyle(
                                                fontSize: 14.0,
                                                color: Color(0xffFFFFFF),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          ),
                                          isExpanded: true,
                                          icon: Icon(                // Add this
                                            Icons.arrow_drop_down,  // Add this
                                            color: Color(0xff64748B),

                                            // Add this
                                          ),
                                          items: _statusList.map((items) {
                                            return DropdownMenuItem(
                                              value: items['id'].toString(),
                                              child: Text(
                                                items['title'],
                                                style: const TextStyle(
                                                    fontSize: 14.0,
                                                    color: Color(0xffFFFFFF),
                                                    fontFamily: 'Inter',
                                                    fontWeight: FontWeight.w500),
                                              ),
                                            );
                                          }).toList(),
                                          onChanged: (newValue) {
                                            setState(() {
                                              _status = newValue;
                                              print('value of status' + _status!);
                                            });
                                          },
                                        ),
                                      );
                                    },
                                  )),
                            ),

                          const SizedBox(
                            width: 16.0,
                          ),

                          Container(
                                width: MediaQuery.of(context).size.width * 0.19,
                                margin:
                                    const EdgeInsets.only(top: 15.0, right: 10.0),
                                height: 56.0,
                                decoration: BoxDecoration(
                                  color: const Color(0xff334155),
                                  //border: Border.all(color:  const Color(0xff1E293B)),
                                  borderRadius: BorderRadius.circular(
                                    8.0,
                                  ),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color(0xff475569),
                                      offset: Offset(
                                        0.0,
                                        2.0,
                                      ),
                                      blurRadius: 0.0,
                                      spreadRadius: 0.0,
                                    ), //BoxShadow
                                  ],
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  // crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    GestureDetector(
                                      onTap: () {
                                        _selectDate(setState);
                                      },
                                      child: Container(
                                        margin: const EdgeInsets.only(left: 13.0),
                                        height: 22.0,
                                        width: 20.0,
                                        child: Image.asset('images/date.png'),
                                      ),
                                    ),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                            margin: const EdgeInsets.only(
                                                top: 10.0, left: 20.0),
                                            child: const Text(
                                              "Delivery Date",
                                              style: TextStyle(
                                                  fontSize: 13.0,
                                                  color: Color(0xff64748B),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w500),
                                            )),
                                        GestureDetector(
                                          onTap: () async {
                                            _selectDate(setState);
                                          },
                                          child: Container(
                                              margin: const EdgeInsets.only(
                                                  top: 3.0, left: 20.0),
                                              child: Text(
                                                '${selectedDate.day} / ${selectedDate.month} / ${selectedDate.year}',
                                                style: const TextStyle(
                                                    fontSize: 14.0,
                                                    color: Color(0xffFFFFFF),
                                                    fontFamily: 'Inter',
                                                    fontWeight: FontWeight.w500),
                                              )),
                                        ),
                                      ],
                                    ),
                                    const Spacer(),
                                    Container(
                                      margin: const EdgeInsets.only(
                                          top: 5.0, right: 10.0),
                                      height: 20.0,
                                      child: Padding(
                                          padding: const EdgeInsets.all(4.0),
                                          child: SvgPicture.asset(
                                              'images/cross.svg')),
                                    ),
                                  ],
                                )),

                        ],
                      ),

                      Expanded(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [

                            GestureDetector(
                              onTap: () {
                                Navigator.of(context).pop();
                              },
                              child: Container(
                                width:
                                97, //MediaQuery.of(context).size.width * 0.22,
                                margin:
                                const EdgeInsets.only(top: 16.0, ),
                                height: 40.0,
                                decoration: BoxDecoration(
                                  color: const Color(0xff334155),
                                  //border: Border.all(color:  const Color(0xff1E293B)),
                                  borderRadius: BorderRadius.circular(
                                    40.0,
                                  ),
                                ),

                                child: const Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    "Cancel",
                                    style: TextStyle(
                                        fontSize: 14.0,
                                        color: ColorSelect.white_color,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w700),
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(
                              width: 16,
                            ),

                            GestureDetector(
                              onTap: () {
                                _submit();
                              },
                              child: Container(
                                width:
                                97.0, //MediaQuery.of(context).size.width * 0.22,
                                margin: const EdgeInsets.only(
                                  top: 16.0,
                                  //bottom: 10.0,
                                  right: 10.0,
                                ),
                                height: 40.0,
                                decoration: BoxDecoration(
                                  color: const Color(0xff7DD3FC),
                                  //border: Border.all(color:  const Color(0xff1E293B)),
                                  borderRadius: BorderRadius.circular(
                                    40.0,
                                  ),
                                ),
                                child: const Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    "Create",
                                    style: TextStyle(
                                        fontSize: 14.0,
                                        color: ColorSelect.black_color,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w700),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                    ],
                  ),
                ),
              ),
            ),
          );
        });
  }


  //Add people popup
  void showAddPeople(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return StatefulBuilder(
            builder: (context, setState) => AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              contentPadding: EdgeInsets.zero,
              backgroundColor: const Color(0xff1E293B),
              content: Form(
                key: _addFormKey,
                child: SizedBox(
                  width: MediaQuery.of(context).size.width * 0.99,
                  height: MediaQuery.of(context).size.height * 0.99,
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                                  height:
                                      MediaQuery.of(context).size.height * 0.11,
                                  width: MediaQuery.of(context).size.width * 0.99,
                                  decoration: const BoxDecoration(
                                    color: Color(0xff283345),
                                    //border: Border.all(color: const Color(0xff0E7490)),
                                    borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(16.0),
                                      topLeft: Radius.circular(16.0),
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x26000000),
                                        offset: Offset(
                                          0.0,
                                          1.0,
                                        ),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                  ),
                                  child: Row(
                                   // mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Container(
                                        margin: const EdgeInsets.only(
                                            left: 30.0, top: 10.0, bottom: 10.0),
                                        child: const Text(
                                          "Add people",
                                          style: TextStyle(
                                              color: Color(0xffFFFFFF),
                                              fontSize: 18.0,
                                              fontFamily: 'Inter',
                                              fontWeight: FontWeight.w700),
                                        ),
                                      ),
                                      Spacer(),

                                      Container(
                                              width:
                                                  97.0, //MediaQuery.of(context).size.width * 0.22,
                                              margin: const EdgeInsets.only(
                                                  top: 10.0, bottom: 10.0),
                                              height: 40.0,
                                              decoration: BoxDecoration(
                                                color: const Color(0xff334155),
                                                //border: Border.all(color:  const Color(0xff1E293B)),
                                                borderRadius:
                                                    BorderRadius.circular(
                                                  40.0,
                                                ),
                                              ),
                                              child: GestureDetector(
                                                onTap: (){
                                                  Navigator.of(context).pop();
                                                },
                                                child: const Align(
                                                  alignment: Alignment.center,
                                                  child: Text(
                                                    "Cancel",
                                                    style: TextStyle(
                                                        fontSize: 14.0,
                                                        color: Color(0xffFFFFFF),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                        FontWeight.w700),
                                                  ),
                                                ),
                                              ),
                                            ),
                                      const SizedBox(
                                              width: 16,
                                            ),
                                      InkWell(
                                              onTap: () {
                                                _editSubmit();
                                               // getAddPeople();
                                               /* Navigator.pushNamed(
                                                    context, "/home");*/

                                                /* Navigator.push(
                                                     context,
                                                     MaterialPageRoute(builder: (context) =>
                                                         PeopleIdle()));*/
                                              },
                                              child: Container(
                                                width:
                                                    97, //MediaQuery.of(context).size.width * 0.22,
                                                margin: const EdgeInsets.only(
                                                    top: 10.0,
                                                    right: 20.0,
                                                    bottom: 10.0),
                                                height: 40.0,
                                                decoration: BoxDecoration(
                                                  color: const Color(0xff7DD3FC),
                                                  //border: Border.all(color:  const Color(0xff1E293B)),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                    40.0,
                                                  ),
                                                ),

                                                child: const Align(
                                                  alignment: Alignment.center,
                                                  child: Text(
                                                    "Save",
                                                    style: TextStyle(
                                                        fontSize: 14.0,
                                                        color: Color(0xff000000),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                            FontWeight.w700),
                                                  ),
                                                ),
                                              ),
                                            ),

                                    ],
                                  )),

                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Expanded(
                              flex: 1,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                          width: 134.0,
                                          height: 134.0,
                                          margin: const EdgeInsets.only(
                                              left: 27.0, top: 28.0),
                                          decoration: BoxDecoration(
                                            color: const Color(0xff334155),
                                            borderRadius: BorderRadius.circular(
                                              110.0,
                                            ),
                                          ),
                                          child: ClipRRect(
                                            borderRadius:
                                            BorderRadius.circular(110.0),
                                            child: imageavail
                                                ? Image.memory(webImage!,fit: BoxFit.fill,)
                                                : Padding(
                                                padding: const EdgeInsets.all(
                                                    46.0),
                                                child: SvgPicture.asset(
                                                    'images/photo.svg',height: 36.0,width: 36.0,)),
                                          )),
                                      InkWell(
                                        onTap: () async {
                                          final image= await ImagePickerWeb.getImageAsBytes();
                                          setState(() {
                                            webImage=image!;
                                            imageavail=true;
                                          });

                                        },
                                        child: Container(
                                          height: 35.0,
                                          width:
                                          MediaQuery.of(context).size.width *
                                              0.11,
                                          margin: const EdgeInsets.only(
                                              left: 48.0, top: 20.0),
                                          decoration: BoxDecoration(
                                            color: const Color(0xff334155),
                                            //border: Border.all(color: const Color(0xff0E7490)),
                                            borderRadius: BorderRadius.circular(
                                              40.0,
                                            ),
                                          ),
                                          child: Row(
                                            children: [
                                              Container(
                                                margin: const EdgeInsets.only(
                                                    left: 16.0),
                                                child: SvgPicture.asset(
                                                    'images/camera_pic.svg'),
                                              ),
                                              Container(
                                                margin: const EdgeInsets.only(
                                                    left: 11.0),
                                                child: const Text(
                                                  "Upload new",
                                                  style: TextStyle(
                                                      color: Color(0xffFFFFFF),
                                                      fontSize: 14.0,
                                                      fontFamily: 'Inter',
                                                      fontWeight:
                                                      FontWeight.w700),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),

                                  Container(
                                    margin: const EdgeInsets.only(
                                        left: 30.0, top: 20.0),
                                    child: const Text(
                                      "About you",
                                      style: TextStyle(
                                          color: Color(0xffFFFFFF),
                                          fontSize: 14.0,
                                          fontFamily: 'Inter',
                                          fontWeight: FontWeight.w700),
                                    ),
                                  ),

                                  const SizedBox(
                                    height: 8.0,
                                  ),

                                  Stack(
                                    children: [
                                      Container(
                                        width:
                                        MediaQuery.of(context).size.width * 0.99,
                                        margin: const EdgeInsets.only(
                                            left: 30.0, right: 25.0),
                                        height: 56.0,
                                        decoration: BoxDecoration(
                                          color: const Color(0xff334155),
                                          //border: Border.all(color:  const Color(0xff1E293B)),
                                          borderRadius: BorderRadius.circular(
                                            8.0,
                                          ),
                                          boxShadow: const [
                                            BoxShadow(
                                              color: Color(0xff475569),
                                              offset: Offset(
                                                0.0,
                                                2.0,
                                              ),
                                              blurRadius: 0.0,
                                              spreadRadius: 0.0,
                                            ), //BoxShadow
                                          ],
                                        ),

                                      ),

                                      Container(
                                          margin: const EdgeInsets.only(
                                              top: 6.0, left: 45.0),
                                          child: const Text(
                                            "Name",
                                            style: TextStyle(
                                                fontSize: 11.0,
                                                color: Color(0xff64748B),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          ),),



                                      TextFormField(
                                        controller: _name,
                                        inputFormatters: [
                                          UpperCaseTextFormatter()
                                        ],
                                        //   autovalidateMode: AutovalidateMode.onUserInteraction,
                                        cursorColor: const Color(0xffFFFFFF),
                                        style: const TextStyle(color: Color(0xffFFFFFF)),
                                        textAlignVertical: TextAlignVertical.bottom,
                                        keyboardType: TextInputType.text,
                                        minLines: 1,
                                        // maxLines: 20,
                                        maxLength: 30,

                                        decoration: const InputDecoration(
                                            counterText: "",

                                            contentPadding: EdgeInsets.only(
                                              bottom: 16.0,
                                              top: 35.0,
                                              right: 10,
                                              left: 45.0,
                                            ),
                                            errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                            border: InputBorder.none,
                                             hintText: 'Enter name',
                                            hintStyle: TextStyle(
                                                fontSize: 14.0,
                                                color: Color(0xffFFFFFF),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500)),
                                        //  autovalidate: _autoValidate ,
                                        autovalidateMode: _addSubmitted
                                            ? AutovalidateMode.onUserInteraction
                                            : AutovalidateMode.disabled,

                                        validator: (value) {
                                          //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                          if(value!.isEmpty){
                                            return 'Please enter';
                                          }
                                          return null;
                                        },
                                        onChanged: (text) => setState(() => name1 = text),
                                      ),
                                    ],
                                  ),

                                  Stack(
                                   children: [
                                     Container(
                                       width:
                                       MediaQuery.of(context).size.width * 0.99,
                                       margin: const EdgeInsets.only(
                                           left: 30.0, top: 16.0, right: 25.0),
                                       height: 56.0,
                                       decoration: BoxDecoration(
                                         color: const Color(0xff334155),
                                         //border: Border.all(color:  const Color(0xff1E293B)),
                                         borderRadius: BorderRadius.circular(
                                           8.0,
                                         ),
                                         boxShadow: const [
                                           BoxShadow(
                                             color: Color(0xff475569),
                                             offset: Offset(
                                               0.0,
                                               2.0,
                                             ),
                                             blurRadius: 0.0,
                                             spreadRadius: 0.0,
                                           ), //BoxShadow
                                         ],
                                       ),

                                     ),

                                     Container(
                                         margin: const EdgeInsets.only(
                                             top: 22.0, left: 45.0),
                                         child: const Text(
                                           "Nickname",
                                           style: TextStyle(
                                               fontSize: 11.0,
                                               color: Color(0xff64748B),
                                               fontFamily: 'Inter',
                                               fontWeight: FontWeight.w500),
                                         )),

                                     TextFormField(
                                       controller: _nickName,
                                       //   autovalidateMode: AutovalidateMode.onUserInteraction,
                                       cursorColor: const Color(0xffFFFFFF),
                                       style: const TextStyle(color: Color(0xffFFFFFF)),
                                       textAlignVertical: TextAlignVertical.bottom,
                                       keyboardType: TextInputType.text,
                                       maxLength: 30,
                                       decoration: const InputDecoration(
                                           counterText: "",
                                           contentPadding: EdgeInsets.only(
                                             bottom: 16.0,
                                             top: 52.0,
                                             right: 10,
                                             left: 45.0,
                                           ),
                                           errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                           border: InputBorder.none,
                                            hintText: 'Enter nickname',
                                           hintStyle: TextStyle(
                                               fontSize: 14.0,
                                               color: Color(0xffFFFFFF),
                                               fontFamily: 'Inter',
                                               fontWeight: FontWeight.w500)),
                                       //  autovalidate: _autoValidate ,
                                       autovalidateMode: _addSubmitted
                                           ? AutovalidateMode.onUserInteraction
                                           : AutovalidateMode.disabled,

                                       validator: (value) {
                                         //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                         if(value!.isEmpty){
                                           return 'Please enter';
                                         }
                                         return null;
                                       },
                                       onChanged: (text) => setState(() => name1 = text),
                                     ),

                                   ],
                                 ),

                                  Stack(
                                    children: [
                                      Container(
                                        width:
                                        MediaQuery.of(context).size.width * 0.99,
                                        margin: const EdgeInsets.only(
                                            left: 30.0, top: 16.0, right: 25.0),
                                        height: 110.0,
                                        decoration: const BoxDecoration(
                                          color: Color(0xff334155),
                                          //border: Border.all(color:  const Color(0xff1E293B)),
                                          borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(8.0),
                                            topLeft: Radius.circular(8.0),
                                          ),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Color(0xff475569),
                                              offset: Offset(
                                                0.0,
                                                2.0,
                                              ),
                                              blurRadius: 0.0,
                                              spreadRadius: 0.0,
                                            ), //BoxShadow
                                          ],
                                        ),

                                      ),

                                      Container(
                                          margin: const EdgeInsets.only(
                                              top: 22.0, left: 45.0),
                                          child: const Text(
                                            "Your bio",
                                            style: TextStyle(
                                                fontSize: 11.0,
                                                color: Color(0xff64748B),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          )),

                                      TextFormField(
                                        maxLines: 5,
                                        maxLength: 152,
                                        controller: _bio,
                                        cursorColor: const Color(0xffFFFFFF),
                                        style: const TextStyle(
                                            color: Color(0xffFFFFFF)),
                                        textAlignVertical:
                                        TextAlignVertical.bottom,
                                        keyboardType: TextInputType.text,
                                        decoration: const InputDecoration(
                                            counterText: "",
                                            errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                            contentPadding: EdgeInsets.only(
                                             // bottom: 10.0,
                                              top: 47.0,
                                              right: 40,
                                              left: 45.0,
                                            ),
                                            border: InputBorder.none,
                                            hintText: 'Enter your bio',
                                            hintStyle: TextStyle(
                                                fontSize: 14.0,
                                                color: Color(0xffFFFFFF),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500)),
                                        autovalidateMode: _addSubmitted
                                            ? AutovalidateMode.onUserInteraction
                                            : AutovalidateMode.disabled,
                                        validator: (value) {
                                          //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                          if(value!.isEmpty){
                                            return 'Please enter';
                                          }
                                          return null;
                                        },
                                        onChanged: (text) => setState(() => name1 = text),
                                      ),
                                    ],
                                  ),

                                  Row(
                                    children: [

                                      Expanded(
                                        flex: 1,
                                        child: Stack(
                                          children: [
                                            Container(
                                              width: MediaQuery.of(context).size.width *
                                                  0.12,
                                              margin: const EdgeInsets.only(
                                                  left: 30.0, top: 16.0,right: 16.0),
                                              height: 56.0,
                                              decoration: BoxDecoration(
                                                color: const Color(0xff334155),
                                                //border: Border.all(color:  const Color(0xff1E293B)),
                                                borderRadius: BorderRadius.circular(
                                                  8.0,
                                                ),
                                                boxShadow: const [
                                                  BoxShadow(
                                                    color: Color(0xff475569),
                                                    offset: Offset(
                                                      0.0,
                                                      2.0,
                                                    ),
                                                    blurRadius: 0.0,
                                                    spreadRadius: 0.0,
                                                  ), //BoxShadow
                                                ],
                                              ),

                                            ),

                                            Container(
                                                margin: const EdgeInsets.only(
                                                    top: 23.0, left: 45.0),
                                                child: const Text(
                                                  "Designation",
                                                  style: TextStyle(
                                                      fontSize: 11.0,
                                                      color: Color(0xff64748B),
                                                      fontFamily: 'Inter',
                                                      fontWeight:
                                                      FontWeight.w500),
                                                )),

                                            TextFormField(
                                              controller: _designation,
                                              inputFormatters: [
                                                UpperCaseTextFormatter()
                                              ],
                                              maxLength: 18,
                                              cursorColor:
                                              const Color(0xffFFFFFF),
                                              style: const TextStyle(
                                                  color: Color(0xffFFFFFF)),
                                              textAlignVertical:
                                              TextAlignVertical.bottom,
                                              keyboardType: TextInputType.text,
                                              decoration: const InputDecoration(
                                                      counterText: "",
                                                  errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                                  contentPadding:
                                                  EdgeInsets.only(
                                                    bottom: 16.0,
                                                    top: 53.0,
                                                    right: 10,
                                                    left: 45.0,
                                                  ),
                                                  border: InputBorder.none,
                                                  hintText: 'Enter',
                                                  hintStyle: TextStyle(
                                                      fontSize: 14.0,
                                                      color: Color(0xffFFFFFF),
                                                      fontFamily: 'Inter',
                                                      fontWeight:
                                                      FontWeight.w500)),
                                              autovalidateMode: _addSubmitted
                                                  ? AutovalidateMode.onUserInteraction
                                                  : AutovalidateMode.disabled,
                                              validator: (value) {
                                                //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                                if(value!.isEmpty){
                                                  return 'Please enter';
                                                }
                                                return null;
                                              },
                                              onChanged: (text) => setState(() => name1 = text),
                                            ),
                                          ],
                                        ),
                                      ),

                                     /* const SizedBox(
                                        width: 8.0,
                                      ),*/
                                      Expanded(
                                        flex: 1,
                                        child: Container(
                                          width: MediaQuery.of(context).size.width *
                                              0.13,
                                          margin: const EdgeInsets.only(top: 10.0,right: 30),
                                          height: 56.0,
                                          decoration: BoxDecoration(
                                            color: const Color(0xff334155),
                                            //border: Border.all(color:  const Color(0xff1E293B)),
                                            borderRadius: BorderRadius.circular(
                                              8.0,
                                            ),
                                          ),
                                          child:
                                              Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                      margin:
                                                      const EdgeInsets
                                                          .only(
                                                          top: 6.0,
                                                          left: 16.0),
                                                      child: const Text(
                                                        "Department",
                                                        style: TextStyle(
                                                            fontSize:
                                                            13.0,
                                                            color: Color(
                                                                0xff64748B),
                                                            fontFamily:
                                                            'Inter',
                                                            fontWeight:
                                                            FontWeight
                                                                .w500),
                                                      )),

                                                  Container(
                                                    margin: const EdgeInsets.only(
                                                        left: 16.0,right: 16.0 ),
                                                    height: 20.0,
                                                    child:  Container(

                                                        // padding: const EdgeInsets.all(2.0),
                                                        child: StatefulBuilder(
                                                          builder: (BuildContext context,
                                                              StateSettersetState) {
                                                            return DropdownButtonHideUnderline(
                                                              child: DropdownButton(
                                                                dropdownColor:
                                                                ColorSelect.class_color,
                                                                value: _depat,
                                                                underline: Container(),
                                                                hint: const Text(
                                                                  "Select",
                                                                  style: TextStyle(
                                                                      fontSize: 14.0,
                                                                      color:
                                                                      Color(0xffFFFFFF),
                                                                      fontFamily: 'Inter',
                                                                      fontWeight:
                                                                      FontWeight.w500),
                                                                ),
                                                                isExpanded: true,
                                                                icon: const Icon(                // Add this
                                                                  Icons.arrow_drop_down,  // Add this
                                                                  color: Color(0xff64748B),

                                                                  // Add this
                                                                ),
                                                                items:
                                                                _department.map((items) {
                                                                  return DropdownMenuItem(
                                                                    value: items['id']
                                                                        .toString(),
                                                                    child: Text(
                                                                      items['name'],
                                                                      style: const TextStyle(
                                                                          fontSize: 14.0,
                                                                          color: Color(
                                                                              0xffFFFFFF),
                                                                          fontFamily: 'Inter',
                                                                          fontWeight:
                                                                          FontWeight
                                                                              .w400),
                                                                    ),
                                                                  );
                                                                }).toList(),
                                                                onChanged: (newValue) {
                                                                  setState(() {
                                                                    _depat = newValue;
                                                                  });
                                                                },

                                                                /* selectedItemBuilder:
                                                                                (BuildContext
                                                                            context) {
                                                                              return _department.map(
                                                                                      (
                                                                                      value) {
                                                                                    return Container(
                                                                                      margin: const EdgeInsets
                                                                                          .only(
                                                                                          top:
                                                                                          15.0),
                                                                                      child: Text(
                                                                                          _depat!,
                                                                                          style: const TextStyle(
                                                                                              color: Color(
                                                                                                  0xffFFFFFF),
                                                                                              fontFamily:
                                                                                              'Inter',
                                                                                              fontWeight: FontWeight
                                                                                                  .w400,
                                                                                              fontSize:
                                                                                              14.0)),
                                                                                    );
                                                                                  }).toList();
                                                                            },*/
                                                              ),
                                                            );
                                                          },
                                                        )),
                                                  )

                                                ],
                                              ),

                                        ),
                                      ),
                                    ],
                                  ),

                                  Stack(
                                      children: [
                                        Container(
                                          width:
                                          MediaQuery.of(context).size.width * 0.99,
                                          margin: const EdgeInsets.only(
                                              left: 30.0, top: 16.0, right: 26.0),
                                          height: 56.0,
                                          decoration: BoxDecoration(
                                            color: const Color(0xff334155),
                                            //border: Border.all(color:  const Color(0xff1E293B)),
                                            borderRadius: BorderRadius.circular(
                                              8.0,
                                            ),
                                            boxShadow: const [
                                              BoxShadow(
                                                color: Color(0xff475569),
                                                offset: Offset(
                                                  0.0,
                                                  2.0,
                                                ),
                                                blurRadius: 0.0,
                                                spreadRadius: 0.0,
                                              ), //BoxShadow
                                            ],
                                          ),

                                        ),

                                        Container(
                                            margin: const EdgeInsets.only(
                                                top: 22.0, left: 45.0),
                                            child: const Text(
                                              "Associated with",
                                              style: TextStyle(
                                                  fontSize: 11.0,
                                                  color: Color(0xff64748B),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w500),
                                            )),

                                        TextFormField(
                                          controller: _association,
                                          //   autovalidateMode: AutovalidateMode.onUserInteraction,
                                          cursorColor: const Color(0xffFFFFFF),
                                          style: const TextStyle(color: Color(0xffFFFFFF)),
                                          textAlignVertical: TextAlignVertical.bottom,
                                          keyboardType: TextInputType.text,
                                          maxLength: 30,
                                          decoration: const InputDecoration(
                                              counterText: "",
                                              contentPadding: EdgeInsets.only(
                                                bottom: 16.0,
                                                top: 52.0,
                                                right: 10,
                                                left: 45.0,
                                              ),
                                              errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                              border: InputBorder.none,
                                               hintText: 'Enter team name',
                                              hintStyle: TextStyle(
                                                  fontSize: 14.0,
                                                  color: Color(0xffFFFFFF),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w500)),
                                          //  autovalidate: _autoValidate ,
                                          autovalidateMode: _addSubmitted
                                              ? AutovalidateMode.onUserInteraction
                                              : AutovalidateMode.disabled,

                                          validator: (value) {
                                            //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                            if(value!.isEmpty){
                                              return 'Please enter';
                                            }
                                            return null;
                                          },
                                          onChanged: (text) => setState(() => name1 = text),
                                        ),
                                      ],
                                  ),

                                  Container(
                                    margin: const EdgeInsets.only(
                                        left: 30.0, top: 16.0),
                                    child: const Text(
                                      "Salary",
                                      style: TextStyle(
                                          color: Color(0xffFFFFFF),
                                          fontSize: 18.0,
                                          fontFamily: 'Inter',
                                          fontWeight: FontWeight.w700),
                                    ),
                                  ),

                                  Row(
                                    children: [
                                      Container(
                                        width: MediaQuery.of(context).size.width *
                                            0.07,
                                        margin: const EdgeInsets.only(
                                            left: 30.0, top: 16.0, bottom: 16.0),
                                        height: 56.0,
                                        decoration: BoxDecoration(
                                          color: const Color(0xff334155),
                                          //border: Border.all(color:  const Color(0xff1E293B)),
                                          borderRadius: BorderRadius.circular(
                                            8.0,
                                          ),
                                        ),
                                        child: Container(
                                            margin: const EdgeInsets.only(
                                                left: 13.0, right: 18.0),
                                            // padding: const EdgeInsets.all(2.0),
                                            child: StatefulBuilder(
                                              builder: (BuildContext context,
                                                  StateSettersetState) {
                                                return DropdownButtonHideUnderline(
                                                  child: DropdownButton(
                                                    dropdownColor:
                                                    ColorSelect.class_color,
                                                    value: _curren,
                                                    underline: Container(),
                                                    hint: const Text(
                                                      "€",
                                                      style: TextStyle(
                                                          fontSize: 14.0,
                                                          color:
                                                          Color(0xffFFFFFF),
                                                          fontFamily: 'Inter',
                                                          fontWeight:
                                                          FontWeight.w500),
                                                    ),
                                                    isExpanded: true,
                                                    icon: Icon(                // Add this
                                                      Icons.arrow_drop_down,  // Add this
                                                      color: Color(0xff64748B),

                                                      // Add this
                                                    ),
                                                    items: _currencyName
                                                        .map((items) {
                                                      return DropdownMenuItem(
                                                        value: items['id']
                                                            .toString(),
                                                        child: Text(
                                                          items['currency']
                                                          ['symbol'],
                                                          style: const TextStyle(
                                                              fontSize: 14.0,
                                                              color: Color(
                                                                  0xffFFFFFF),
                                                              fontFamily: 'Inter',
                                                              fontWeight:
                                                              FontWeight
                                                                  .w400),
                                                        ),
                                                      );
                                                    }).toList(),
                                                    onChanged: (newValue) {
                                                      setState(() {
                                                        _curren = newValue;
                                                      });
                                                    },
                                                  ),
                                                );
                                              },
                                            )),
                                      ),
                                      const SizedBox(
                                        width: 8.0,
                                      ),

                                      Expanded(
                                        child: Stack(
                                          children: [
                                            Container(
                                              width: MediaQuery.of(context).size.width *
                                                  0.10,
                                              margin: const EdgeInsets.only(
                                                  top: 16.0, bottom: 16.0),
                                              height: 56.0,
                                              decoration: BoxDecoration(
                                                color: const Color(0xff334155),
                                                //border: Border.all(color:  const Color(0xff1E293B)),
                                                borderRadius: BorderRadius.circular(
                                                  8.0,
                                                ),
                                                boxShadow: const [
                                                  BoxShadow(
                                                    color: Color(0xff475569),
                                                    offset: Offset(
                                                      0.0,
                                                      2.0,
                                                    ),
                                                    blurRadius: 0.0,
                                                    spreadRadius: 0.0,
                                                  ), //BoxShadow
                                                ],
                                              ),

                                            ),
                                            Container(
                                                margin: const EdgeInsets.only(
                                                    top: 23.0, left: 15.0),
                                                child: const Text(
                                                  "Monthly Salary",
                                                  style: TextStyle(
                                                      fontSize: 11.0,
                                                      color: Color(0xff64748B),
                                                      fontFamily: 'Inter',
                                                      fontWeight:
                                                      FontWeight.w500),
                                                )),
                                            TextFormField(
                                              controller: _salary,

                                              cursorColor:
                                              const Color(0xffFFFFFF),
                                              style: const TextStyle(
                                                  color: Color(0xffFFFFFF)),
                                              textAlignVertical:
                                              TextAlignVertical.bottom,
                                              keyboardType: TextInputType.text,
                                              decoration: const InputDecoration(
                                                  errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                                  contentPadding:
                                                  EdgeInsets.only(
                                                    bottom: 16.0,
                                                    top: 52.0,
                                                    right: 10,
                                                    left: 15.0,
                                                  ),
                                                  border: InputBorder.none,
                                                  hintText: '0.00',
                                                  hintStyle: TextStyle(
                                                      fontSize: 14.0,
                                                      color: Color(0xffFFFFFF),
                                                      fontFamily: 'Inter',
                                                      fontWeight:
                                                      FontWeight.w500)),
                                              autovalidateMode: _addSubmitted
                                                  ? AutovalidateMode.onUserInteraction
                                                  : AutovalidateMode.disabled,
                                              validator: (value) {
                                                //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                                if(value!.isEmpty){
                                                  return 'Please enter';
                                                }
                                                return null;
                                              },
                                              onChanged: (text) => setState(() => name1 = text),
                                            ),
                                          ],
                                        ),
                                      ),

                                    ],
                                  ),
                                ],
                              ),
                            ),

                            Container(
                                height: MediaQuery.of(context).size.height * 0.99,
                                child: const VerticalDivider(
                                  color: Color(0xff94A3B8),
                                  thickness: 0.2,
                                )),

                            Expanded(
                              flex: 1,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: const EdgeInsets.only(
                                        left: 30.0, top: 27.0),
                                    child: const Text(
                                      "Availabilty",
                                      style: TextStyle(
                                          color: Color(0xffFFFFFF),
                                          fontSize: 18.0,
                                          fontFamily: 'Inter',
                                          fontWeight: FontWeight.w700),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 8.0,
                                  ),

                                  Stack(
                                    children: [
                                      Container(
                                        width:
                                        MediaQuery.of(context).size.width * 0.26,
                                        margin: const EdgeInsets.only(left: 30.0),
                                        height: 56.0,
                                        decoration: BoxDecoration(
                                          color: const Color(0xff334155),
                                          //border: Border.all(color:  const Color(0xff1E293B)),
                                          borderRadius: BorderRadius.circular(
                                            8.0,
                                          ),
                                          boxShadow: const [
                                            BoxShadow(
                                              color: Color(0xff475569),
                                              offset: Offset(
                                                0.0,
                                                2.0,
                                              ),
                                              blurRadius: 0.0,
                                              spreadRadius: 0.0,
                                            ), //BoxShadow
                                          ],
                                        ),

                                      ),

                                      Container(
                                          margin: const EdgeInsets.only(
                                              top: 6.0, left: 45.0),
                                          child: const Text(
                                            "Select days",
                                            style: TextStyle(
                                                fontSize: 11.0,
                                                color: Color(0xff64748B),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          )),

                                      TextFormField(
                                        controller: _availableDay,
                                        cursorColor: const Color(0xffFFFFFF),
                                        style: const TextStyle(
                                            color: Color(0xffFFFFFF)),
                                        textAlignVertical:
                                        TextAlignVertical.bottom,
                                        keyboardType: TextInputType.text,
                                        decoration: const InputDecoration(
                                            errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                            contentPadding: EdgeInsets.only(
                                              bottom: 16.0,
                                              top: 34.0,
                                              right: 10,
                                              left: 45.0,
                                            ),
                                            border: InputBorder.none,
                                            hintText: 'Select',
                                            hintStyle: TextStyle(
                                                fontSize: 14.0,
                                                color: Color(0xffFFFFFF),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500)),
                                        autovalidateMode: _addSubmitted
                                            ? AutovalidateMode.onUserInteraction
                                            : AutovalidateMode.disabled,

                                        validator: (value) {
                                          //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                          if(value!.isEmpty){
                                            return 'Please enter';
                                          }
                                          return null;
                                        },
                                        onChanged: (text) => setState(() => name1 = text),
                                      ),

                                    ],
                                  ),


                                  Stack(
                                      children: [
                                        Container(
                                          width:
                                          MediaQuery.of(context).size.width * 0.26,
                                          margin: const EdgeInsets.only(
                                              left: 30.0, top: 16.0),
                                          height: 56.0,
                                          decoration: BoxDecoration(
                                            color: const Color(0xff334155),
                                            //border: Border.all(color:  const Color(0xff1E293B)),
                                            borderRadius: BorderRadius.circular(
                                              8.0,
                                            ),
                                            boxShadow: const [
                                              BoxShadow(
                                                color: Color(0xff475569),
                                                offset: Offset(
                                                  0.0,
                                                  2.0,
                                                ),
                                                blurRadius: 0.0,
                                                spreadRadius: 0.0,
                                              ), //BoxShadow
                                            ],
                                          ),

                                        ),

                                        Container(
                                            margin: const EdgeInsets.only(
                                                top: 22.0, left: 45.0),
                                            child: const Text(
                                              "Select time",
                                              style: TextStyle(
                                                  fontSize: 11.0,
                                                  color: Color(0xff64748B),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w500),
                                            )),

                                        TextFormField(
                                          controller: _availableTime,
                                          cursorColor: const Color(0xffFFFFFF),
                                          style: const TextStyle(
                                              color: Color(0xffFFFFFF)),
                                          textAlignVertical:
                                          TextAlignVertical.bottom,
                                          keyboardType: TextInputType.text,
                                          decoration: const InputDecoration(
                                              errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                              contentPadding: EdgeInsets.only(
                                                bottom: 16.0,
                                                top: 50.0,
                                                right: 10,
                                                left: 45.0,
                                              ),
                                              border: InputBorder.none,
                                              hintText: 'Select',
                                              hintStyle: TextStyle(
                                                  fontSize: 14.0,
                                                  color: Color(0xffFFFFFF),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w500)),
                                          autovalidateMode: _addSubmitted
                                              ? AutovalidateMode.onUserInteraction
                                              : AutovalidateMode.disabled,
                                          validator: (value) {
                                            //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                            if(value!.isEmpty){
                                              return 'Please enter';
                                            }
                                            return null;
                                          },
                                          onChanged: (text) => setState(() => name1 = text),
                                        ),
                                      ],
                                  ),


                                  const SizedBox(
                                    height: 25.0,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                    children: [
                                      Container(
                                        margin: const EdgeInsets.only(
                                            left: 30.0, top: 27.0),
                                        child: const Text(
                                          "Skills",
                                          style: TextStyle(
                                              color: Color(0xffFFFFFF),
                                              fontSize: 18.0,
                                              fontFamily: 'Inter',
                                              fontWeight: FontWeight.w700),
                                        ),
                                      ),
                                      Container(
                                          width: 40.0,
                                          height: 40.0,
                                          margin: const EdgeInsets.only(
                                              right: 20.0, top: 25.0),
                                          decoration: const BoxDecoration(
                                            color: Color(0xff334155),
                                            shape: BoxShape.circle,
                                          ),
                                          child: Container(
                                            child: Padding(
                                                padding:
                                                const EdgeInsets.all(10.0),
                                                child: SvgPicture.asset(
                                                    'images/tag_new.svg')),
                                          )
                                        //SvgPicture.asset('images/list.svg'),
                                      ),
                                    ],
                                  ),

                                  Container(
                                    padding: EdgeInsets.only(left: 5,right: 5),
                                    width: MediaQuery.of(context).size.width * 0.26,
                                    margin: const EdgeInsets.only(
                                        left: 30.0, top: 16.0),
                                    height: 50.0,
                                    decoration: BoxDecoration(
                                      color: const Color(0xff334155),
                                      //border: Border.all(color:  const Color(0xff1E293B)),
                                      borderRadius: BorderRadius.circular(
                                        8.0,
                                      ),

                                    ),
                                    child:Column(
                                      children: [
                                        loading
                                            ? CircularProgressIndicator()
                                            : searchTextField =AutoCompleteTextField<Datum>(
                                          // controller: input_controller,
                                          //   suggestions: input_list,
                                          clearOnSubmit: false,
                                          key: key,
                                          cursorColor: Colors.white,
                                          decoration: const InputDecoration(

                                            contentPadding: EdgeInsets.only(top: 15.0),
                                            prefixIcon: Padding(
                                                padding: EdgeInsets.only(top: 4.0),
                                                child: Icon(Icons.search,color: Color(0xff64748B),)),
                                            hintText: 'Search', hintStyle: TextStyle(fontSize: 14.0,  color: Color(0xff64748B),fontFamily: 'Inter', fontWeight: FontWeight.w400),
                                            border: InputBorder.none,

                                          ),

                                          suggestions: users,
                                          keyboardType: TextInputType.text,

                                          style: TextStyle(color: Colors.white, fontSize: 14.0),

                                          itemFilter: (item, query) {
                                            return item.title
                                            !.toLowerCase()
                                                .startsWith(query.toLowerCase());
                                          },
                                          itemSorter: (a, b) {
                                            return a.title!.compareTo(b.title!);
                                          },
                                          itemSubmitted: (item) {
                                            setState(() {
                                              //print(item.title);
                                              searchTextField!.textField!.controller!.text = '';
                                              abc.add(item.title!);
                                            });
                                          },
                                          itemBuilder: (context, item) {
                                            // ui for the autocompelete row
                                            return row(item);
                                          },

                                        )
                                      ],
                                    ),


                                  ),

                                  /*  SizedBox(
                                    height: 100,
                                    child: ListView.builder(
                                        itemBuilder: (context,index){
                                          return Text(_addtag[index]['title']);},
                                        padding: const EdgeInsets.all(12.0),
                                        itemCount: _addtag.length
                                      ),
                                  ),
*/


                                  SizedBox(
                                    height: 55,
                                    child: Padding(
                                      padding: EdgeInsets.only(left: 26),
                                      child: ListView.builder(
                                        scrollDirection:
                                        Axis.horizontal,
                                        itemCount:abc.length,
                                        //.tagResponse!.data!.length,
                                        itemBuilder: (context, index) {

                                          return Container(
                                            margin:
                                            const EdgeInsets.only(
                                                left: 12.0),
                                            child: InputChip(
                                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
                                              deleteIcon: Icon(Icons.close,color: Colors.white,size: 20,),
                                              backgroundColor:
                                              Color(0xff334155),
                                              visualDensity:
                                              VisualDensity.compact,
                                              materialTapTargetSize:
                                              MaterialTapTargetSize
                                                  .shrinkWrap,
                                              label: Text(
                                                abc[index],
                                                style: TextStyle(color: Colors.white),
                                              ),
                                              selected: _isSelected!,
                                              //  selectedColor: Color(0xff334155),
                                              onSelected:
                                                  (bool selected) {
                                                setState(() {
                                                  _isSelected =
                                                      selected;
                                                });
                                              },
                                              onDeleted: () {
                                                setState(() {
                                                  abc!.removeAt(index);
                                                });
                                              },
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            Container(
                                height: MediaQuery.of(context).size.height * 0.99,
                                child: const VerticalDivider(
                                  color: Color(0xff94A3B8),
                                  thickness: 0.2,
                                )),

                            Expanded(
                              flex: 1,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: const EdgeInsets.only(
                                        left: 30.0, top: 27.0),
                                    child: const Text(
                                      "Contact info",
                                      style: TextStyle(
                                          color: Color(0xffFFFFFF),
                                          fontSize: 18.0,
                                          fontFamily: 'Inter',
                                          fontWeight: FontWeight.w700),
                                    ),
                                  ),

                                  const SizedBox(
                                    height: 8.0,
                                  ),

                                  Stack(
                                      children: [
                                        Container(
                                          width: MediaQuery.of(context).size.width * 0.26,
                                          margin: const EdgeInsets.only(left: 30.0),
                                          height: 56.0,
                                          decoration: BoxDecoration(
                                            color: const Color(0xff334155),
                                            //border: Border.all(color:  const Color(0xff1E293B)),
                                            borderRadius: BorderRadius.circular(
                                              8.0,
                                            ),
                                            boxShadow: const [
                                              BoxShadow(
                                                color: Color(0xff475569),
                                                offset: Offset(
                                                  0.0,
                                                  2.0,
                                                ),
                                                blurRadius: 0.0,
                                                spreadRadius: 0.0,
                                              ), //BoxShadow
                                            ],
                                          ),

                                        ),

                                        Container(
                                            margin: const EdgeInsets.only(
                                                top: 6.0, left: 45.0),
                                            child: const Text(
                                              "Country",
                                              style: TextStyle(
                                                  fontSize: 11.0,
                                                  color: Color(0xff64748B),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w500),
                                            )),

                                        TextFormField(
                                          controller: _country,
                                          cursorColor: const Color(0xffFFFFFF),
                                          style: const TextStyle(
                                              color: Color(0xffFFFFFF)),
                                          textAlignVertical:
                                          TextAlignVertical.bottom,
                                          keyboardType: TextInputType.text,
                                          decoration: const InputDecoration(
                                              errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                              contentPadding: EdgeInsets.only(
                                                bottom: 16.0,
                                                top: 35.0,
                                                right: 10,
                                                left: 45.0,
                                              ),
                                              border: InputBorder.none,
                                              hintText: 'Enter country',
                                              hintStyle: TextStyle(
                                                  fontSize: 14.0,
                                                  color: Color(0xffFFFFFF),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w500)),
                                          autovalidateMode: _addSubmitted
                                              ? AutovalidateMode.onUserInteraction
                                              : AutovalidateMode.disabled,
                                          validator: (value) {
                                            //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                            if(value!.isEmpty){
                                              return 'Please enter';
                                            }
                                            return null;
                                          },
                                          onChanged: (text) => setState(() => name1 = text),
                                        ),
                                      ],
                                  ),

                                  Stack(
                                      children: [
                                        Container(
                                          width:
                                          MediaQuery.of(context).size.width * 0.26,
                                          margin: const EdgeInsets.only(
                                              left: 30.0, top: 16.0),
                                          height: 56.0,
                                          decoration: BoxDecoration(
                                            color: const Color(0xff334155),
                                            //border: Border.all(color:  const Color(0xff1E293B)),
                                            borderRadius: BorderRadius.circular(
                                              8.0,
                                            ),
                                            boxShadow: const [
                                              BoxShadow(
                                                color: Color(0xff475569),
                                                offset: Offset(
                                                  0.0,
                                                  2.0,
                                                ),
                                                blurRadius: 0.0,
                                                spreadRadius: 0.0,
                                              ), //BoxShadow
                                            ],
                                          ),

                                        ),
                                        Container(
                                            margin: const EdgeInsets.only(
                                                top: 22.0, left: 45.0),
                                            child: const Text(
                                              "City",
                                              style: TextStyle(
                                                  fontSize: 11.0,
                                                  color: Color(0xff64748B),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w500),
                                            )),
                                        TextFormField(
                                          controller: _enterCity,
                                          cursorColor: const Color(0xffFFFFFF),
                                          style: const TextStyle(
                                              color: Color(0xffFFFFFF)),
                                          textAlignVertical:
                                          TextAlignVertical.bottom,
                                          keyboardType: TextInputType.text,
                                          decoration: const InputDecoration(
                                              errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                              contentPadding: EdgeInsets.only(
                                                bottom: 16.0,
                                                top: 50.0,
                                                right: 10,
                                                left: 45.0,
                                              ),
                                              border: InputBorder.none,
                                              hintText: 'Enter city',
                                              hintStyle: TextStyle(
                                                  fontSize: 14.0,
                                                  color: Color(0xffFFFFFF),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w500)),
                                          autovalidateMode: _addSubmitted
                                              ? AutovalidateMode.onUserInteraction
                                              : AutovalidateMode.disabled,
                                          validator: (value) {
                                            //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                            if(value!.isEmpty){
                                              return 'Please enter';
                                            }
                                            return null;
                                          },
                                          onChanged: (text) => setState(() => name1 = text),
                                        ),
                                      ],
                                  ),

                                  Stack(
                                    children: [
                                      Container(
                                        width:
                                        MediaQuery.of(context).size.width * 0.26,
                                        margin: const EdgeInsets.only(
                                            left: 30.0, top: 16.0),
                                        height: 56.0,
                                        decoration: BoxDecoration(
                                          color: const Color(0xff334155),
                                          //border: Border.all(color:  const Color(0xff1E293B)),
                                          borderRadius: BorderRadius.circular(
                                            8.0,
                                          ),
                                          boxShadow: const [
                                            BoxShadow(
                                              color: Color(0xff475569),
                                              offset: Offset(
                                                0.0,
                                                2.0,
                                              ),
                                              blurRadius: 0.0,
                                              spreadRadius: 0.0,
                                            ), //BoxShadow
                                          ],
                                        ),

                                      ),

                                      Container(
                                          margin: const EdgeInsets.only(
                                              top: 22.0, left: 45.0),
                                          child: const Text(
                                            "Phone number",
                                            style: TextStyle(
                                                fontSize: 11.0,
                                                color: Color(0xff64748B),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          )),

                                      TextFormField(
                                        controller: _phoneNumber,
                                        cursorColor: const Color(0xffFFFFFF),
                                        style: const TextStyle(
                                            color: Color(0xffFFFFFF)),
                                        textAlignVertical:
                                        TextAlignVertical.bottom,
                                        keyboardType: TextInputType.text,
                                        decoration: const InputDecoration(
                                            errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                            contentPadding: EdgeInsets.only(
                                              bottom: 16.0,
                                              top: 50.0,
                                              right: 10,
                                              left: 45.0,
                                            ),
                                            border: InputBorder.none,
                                            hintText: 'Enter number',
                                            hintStyle: TextStyle(
                                                fontSize: 14.0,
                                                color: Color(0xffFFFFFF),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500)),
                                        autovalidateMode: _addSubmitted
                                            ? AutovalidateMode.onUserInteraction
                                            : AutovalidateMode.disabled,
                                        validator: (value) {
                                          //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                          if(value!.isEmpty){
                                            return 'Please enter';
                                          }
                                          return null;
                                        },
                                        onChanged: (text) => setState(() => name1 = text),
                                      ),
                                    ],
                                  ),


                                  Stack(
                                    children: [
                                      Container(
                                        width:
                                        MediaQuery.of(context).size.width * 0.26,
                                        margin: const EdgeInsets.only(
                                            left: 30.0, top: 16.0),
                                        height: 56.0,
                                        decoration: BoxDecoration(
                                          color: const Color(0xff334155),
                                          //border: Border.all(color:  const Color(0xff1E293B)),
                                          borderRadius: BorderRadius.circular(
                                            8.0,
                                          ),
                                          boxShadow: const [
                                            BoxShadow(
                                              color: Color(0xff475569),
                                              offset: Offset(
                                                0.0,
                                                2.0,
                                              ),
                                              blurRadius: 0.0,
                                              spreadRadius: 0.0,
                                            ), //BoxShadow
                                          ],
                                        ),

                                      ),

                                      Container(
                                          margin: const EdgeInsets.only(
                                              top: 22.0, left: 45.0),
                                          child: const Text(
                                            "Email address",
                                            style: TextStyle(
                                                fontSize: 11.0,
                                                color: Color(0xff64748B),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          )),

                                      TextFormField(
                                        controller: _emailAddress,
                                        cursorColor: const Color(0xffFFFFFF),
                                        style: const TextStyle(
                                            color: Color(0xffFFFFFF)),
                                        textAlignVertical:
                                        TextAlignVertical.bottom,
                                        keyboardType: TextInputType.text,
                                        decoration: const InputDecoration(
                                            errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                            contentPadding: EdgeInsets.only(
                                              bottom: 16.0,
                                              top: 50.0,
                                              right: 10,
                                              left: 45.0,
                                            ),
                                            border: InputBorder.none,
                                            hintText: 'Enter email address',
                                            hintStyle: TextStyle(
                                                fontSize: 14.0,
                                                color: Color(0xffFFFFFF),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500)),
                                        autovalidateMode: _addSubmitted
                                            ? AutovalidateMode.onUserInteraction
                                            : AutovalidateMode.disabled,
                                        validator: (value) {
                                          //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                          if(value!.isEmpty){
                                            return 'Please enter';
                                          }
                                          return null;
                                        },
                                        onChanged: (text) => setState(() => name1 = text),
                                      ),
                                    ],
                                  ),


                                  Container(
                                    width:
                                    MediaQuery.of(context).size.width * 0.26,
                                    margin: const EdgeInsets.only(
                                        top: 20.0, left: 30.0),
                                    height: 56.0,
                                    decoration: BoxDecoration(
                                      color: const Color(0xff334155),
                                      //border: Border.all(color:  const Color(0xff1E293B)),
                                      borderRadius: BorderRadius.circular(
                                        8.0,
                                      ),
                                    ),
                                    child: Container(
                                        margin: const EdgeInsets.only(
                                            left: 16.0, right: 20.0),
                                        // padding: const EdgeInsets.all(2.0),
                                        child: StatefulBuilder(
                                          builder: (BuildContext context,
                                              StateSettersetState) {
                                            return DropdownButtonHideUnderline(
                                              child: DropdownButton(
                                                dropdownColor:
                                                ColorSelect.class_color,
                                                value: _time,
                                                underline: Container(),
                                                hint: const Text(
                                                  "Select TimeZone",
                                                  style: TextStyle(
                                                      fontSize: 14.0,
                                                      color: Color(0xffFFFFFF),
                                                      fontFamily: 'Inter',
                                                      fontWeight:
                                                      FontWeight.w500),
                                                ),
                                                isExpanded: true,
                                                icon: Icon(                // Add this
                                                  Icons.arrow_drop_down,  // Add this
                                                  color: Color(0xff64748B),

                                                  // Add this
                                                ),
                                                items: _timeline.map((items) {
                                                  return DropdownMenuItem(
                                                    value: items['id'].toString(),
                                                    child: Text(
                                                      items['name']  + ', ' +  items['diff_from_gtm'],
                                                      style: const TextStyle(
                                                          fontSize: 14.0,
                                                          color:
                                                          Color(0xffFFFFFF),
                                                          fontFamily: 'Inter',
                                                          fontWeight:
                                                          FontWeight.w400),
                                                    ),
                                                  );
                                                }).toList(),
                                                onChanged: (newValue) {
                                                  setState(() {
                                                    _time = newValue;
                                                    print("account:$_time");
                                                  });
                                                },
                                              ),
                                            );
                                          },
                                        )),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        });
  }


  @override
  Widget build(BuildContext context) {
    final mediaQueryData = MediaQuery.of(context);
    return MediaQuery(
      data: mediaQueryData.copyWith(textScaleFactor: 1.0),
      child: Scaffold(

        appBar: AppBar(
          automaticallyImplyLeading: false,
          toolbarHeight: 64.0,
          backgroundColor: const Color(0xff0F172A),
          elevation: 0,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () {
                  // showAddPeople(context);
                },
                child: Container(
                  margin: const EdgeInsets.only(top: 26.0, left: 20.0),
                  child: SvgPicture.asset(
                    'images/hamburger.svg',
                    width: 18.0,
                    height: 12.0,
                  ),
                ),
              ),

              Container(
                margin: const EdgeInsets.only(top: 26.0, left: 0.0),
                child: SvgPicture.asset(
                  'images/logo.svg',
                ),
              ),

              FutureBuilder(
                  future: getList,
                  builder: (context, snapshot) {
                    return Visibility(
                      visible:snapshot.data as bool ,
                      child: Container(
                          margin: const EdgeInsets.only(top: 35.0, left: 6.0),
                          child:Column(
                            children: [
                            /*  Text(prefs.getString('val')=='q'?'List':prefs.getString('val')=='r'?'Profile':'List', style: const TextStyle(
                                  color: Color(0xffFFFFFF),
                                  fontSize: 22.0,
                                  fontFamily: 'Inter',
                                  fontWeight: FontWeight.w700)),*/

                            if(prefs.getString('val')=='q')...[
                              const Text("List", style: TextStyle(
                                  color: Color(0xff93C5FD),
                                  fontSize: 14.0,
                                  fontFamily: 'Inter',
                                  fontWeight: FontWeight.w500)),
                              ] else if(prefs.getString('val')=='r')...[
                              const Text("Profile", style: TextStyle(
                                  color: Color(0xffFFFFFF),
                                  fontSize: 22.0,
                                  fontFamily: 'Inter',
                                  fontWeight: FontWeight.w700))
                                ],
                              const SizedBox(height:10),

                             // prefs.getString('val')=='q'?'List':prefs.getString('val')=='r'?'Profile':'List'
                              if(prefs.getString('val')=='q')...[
                                Container(
                                  width: 25,
                                  height: 3,
                                  decoration: const BoxDecoration(
                                      color: Color(0xff93C5FD),
                                      borderRadius: BorderRadius.only(topLeft: Radius.circular(3),topRight: Radius.circular(3))
                                  ),
                                )
                              ]else if(prefs.getString('val')=='r')...[
                               SizedBox(),
                              ]
                            ],
                          )
                      ),);
                  }
              ),

              const Spacer(),

              /* Container(
                width: MediaQuery.of(context).size.width * 0.22,
                margin: const EdgeInsets.only(left: 15.0, top: 26.0),
                height: 35.0,
                decoration: BoxDecoration(
                  color: const Color(0xff1E293B),
                  border: Border.all(color: const Color(0xff1E293B)),
                  borderRadius: BorderRadius.circular(
                    48.0,
                  ),
                ),
                child: TextFormField(
                  cursorColor: const Color(0xffFFFFFF),
                  style: const TextStyle(color: Color(0xffFFFFFF)),
                  textAlignVertical: TextAlignVertical.bottom,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                      contentPadding: const EdgeInsets.only(
                        bottom: 13.0,
                        top: 14.0,
                        right: 10,
                        left: 14.0,
                      ),
                      prefixIcon: Padding(
                        padding: const EdgeInsets.all(8),
                        child: InkWell(
                          onTap: () {},
                          child: SvgPicture.asset(
                            "images/search.svg",
                            color: const Color(0xff64748B),
                            width: 17.05,
                            height: 17.06,
                          ),
                        ),
                      ),
                      border: InputBorder.none,
                      hintText: 'Search project',
                      hintStyle: const TextStyle(
                          fontSize: 14.0,
                          color: Color(0xff64748B),
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w400)),
                  onChanged: (value) {
                    //filterSearchResults(value);
                  },
                ),
              ),*/

              Container(
                  width: 40.0,
                  height: 40.0,
                  margin: const EdgeInsets.only(
                    top: 26.0,
                    right: 12.0,
                    left: 10.0,
                  ),
                  child:
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20.0),
                    child: Image.asset(
                      'images/placeholder.png',fit: BoxFit.fill,
                     // height: 150.0,
                      //width: 100.0,
                    ),
                  )
                /*  const CircleAvatar(
                    radius: 20,
                    backgroundImage: AssetImage('images/images.jpeg'),
                   //   AssetImage(images/image.png),
                  )*/),

              Container(
                width: 24.0,
                height: 24.0,
                decoration: BoxDecoration(
                  color: const Color(0xff334155),
                  border: Border.all(color: const Color(0xff334155)),
                  borderRadius: BorderRadius.circular(
                    10.0,
                  ),
                ),
                margin: const EdgeInsets.only(
                  top: 26.0,
                  left: 8.0,
                  right: 20.0,
                ),
                child: Padding(
                  padding: const EdgeInsets.all(6.0),
                  child: SvgPicture.asset(
                    "images/drop_arrow.svg",
                  ),
                ),
              ),

              const SizedBox(
                height: 16,
              ),
            ],
          ),
        ),
        
        body: Row(
            children: <Widget>[
              LayoutBuilder(builder: (context, constraint) {
                return Theme(
                  data: ThemeData(
                    highlightColor: Colors.transparent,
                    colorScheme: ColorScheme.light(primary: Color(0xff0F172A)),
                  ),
                 child: SingleChildScrollView(
                   child: ConstrainedBox(
                     constraints: BoxConstraints(minHeight: constraint.maxHeight),
                      child: IntrinsicHeight(
                        child: NavigationRail(
                          selectedIndex: _selectedIndex,
                          onDestinationSelected: (int index) {
                            isIndex = index;
                            position = index;
                            print(index);
                            if (index == 0) {
                              if (add1.length == 1) {
                                showAlertDialog(context);
                              } else if (add1[add1.length - 1] == 1) {
                                showAlertDialog(context);
                              } else if (add1[add1.length - 1] == 2) {
                                print('sizeeee'+_addtag.length.toString());
                                showAddPeople(context);
                              }
                            } else {
                              //
                              setState(() {
                                _selectedIndex = index;
                                add1.add(index);
                              });
                            }
                          },
                          // groupAlignment: 0.1,
                          // elevation: 0.0,

                          labelType: NavigationRailLabelType.selected,
                          //type: BottomNavigationBarType.fixed,
                          backgroundColor: const Color(0xff0F172A),
                          destinations: <NavigationRailDestination>[
                            // navigation destinations

                            NavigationRailDestination(
                              icon: Container(
                                width: 46.0,
                                height: 46.0,
                                decoration: BoxDecoration(
                                  color: const Color(0xff93C5FD),
                                  border: Border.all(color: const Color(0xff93C5FD)),
                                  borderRadius: BorderRadius.circular(
                                    16.0,
                                  ),
                                ),
                                margin: const EdgeInsets.only(
                                  top: 40.0,
                                  left: 20.0,
                                  right: 0.0,
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: SvgPicture.asset(
                                    "images/plus.svg",
                                  ),
                                ),
                              ),
                              // selectedIcon: Icon(Icons.favorite),
                              label: const Text(''),
                            ),

                            NavigationRailDestination(
                              icon: Container(
                                margin: const EdgeInsets.only(
                                  top: 40.0,
                                  left: 20.0,
                                  right: 0.0,
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(9.0),
                                  child: SvgPicture.asset(
                                    "images/notification_icon.svg",
                                  ),
                                ),
                              ),
                              selectedIcon: Container(
                                width: 46.0,
                                height: 32.0,
                                margin: const EdgeInsets.only(
                                  top: 40.0,
                                  left: 20.0,
                                  right: 0.0,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(0xff334155),
                                  border: Border.all(color: const Color(0xff334155)),
                                  borderRadius: BorderRadius.circular(
                                    16.0,
                                  ),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(6.0),
                                  child: SvgPicture.asset(
                                    "images/notification_icon.svg",
                                  ),
                                ),
                              ),
                              label: const Text(''),
                            ),

                            NavigationRailDestination(
                              icon: Container(
                                width: 20.0,
                                height: 18.0,
                                margin: const EdgeInsets.only(
                                  top: 0.0,
                                  left: 20.0,
                                  right: 0.0,
                                ),
                                child: SvgPicture.asset(
                                  "images/camera.svg",
                                ),
                              ),
                              selectedIcon: Container(
                                width: 46.0,
                                height: 32.0,
                                margin: const EdgeInsets.only(
                                  top: 0.0,
                                  left: 20.0,
                                  right: 0.0,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(0xff334155),
                                  border: Border.all(color: const Color(0xff334155)),
                                  borderRadius: BorderRadius.circular(
                                    16.0,
                                  ),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(6.0),
                                  child: SvgPicture.asset(
                                    "images/camera.svg",
                                  ),
                                ),
                              ),
                              label: const Text(''),
                            ),

                            NavigationRailDestination(
                              icon: Container(
                                margin: const EdgeInsets.only(
                                  top: 0.0,
                                  left: 20.0,
                                  bottom: 0.0,
                                ),
                                child: SvgPicture.asset(
                                  "images/people.svg",
                                ),
                              ),
                              selectedIcon: Container(
                                width: 46.0,
                                height: 32.0,
                                margin: const EdgeInsets.only(
                                  top: 0.0,
                                  left: 20.0,
                                  right: 0.0,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(0xff334155),
                                  border: Border.all(color: const Color(0xff334155)),
                                  borderRadius: BorderRadius.circular(
                                    16.0,
                                  ),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(6.0),
                                  child: SvgPicture.asset(
                                    "images/people.svg",
                                  ),
                                ),
                              ),
                              label: const Text(''),
                            ),

                            NavigationRailDestination(
                              icon: Container(
                                width: 20.0,
                                height: 18.0,
                                margin: const EdgeInsets.only(
                                  top: 0.0,
                                  left: 20.0,
                                  right: 0.0,
                                ),
                                child: SvgPicture.asset(
                                  "images/button.svg",
                                ),
                              ),
                              selectedIcon: Container(
                                width: 46.0,
                                height: 32.0,
                                margin: const EdgeInsets.only(
                                  top: 0.0,
                                  left: 20.0,
                                  right: 0.0,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(0xff334155),
                                  border: Border.all(color: const Color(0xff334155)),
                                  borderRadius: BorderRadius.circular(
                                    16.0,
                                  ),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(6.0),
                                  child: SvgPicture.asset(
                                    "images/button.svg",
                                  ),
                                ),
                              ),
                              label: const Text(''),
                            ),

                            NavigationRailDestination(
                              icon: Container(
                                width: 20.0,
                                height: 18.0,
                                margin: const EdgeInsets.only(
                                  top: 0.0,
                                  left: 20.0,
                                  right: 0.0,
                                ),
                                child: SvgPicture.asset(
                                  "images/bell.svg",
                                ),
                              ),
                              selectedIcon: Container(
                                width: 46.0,
                                height: 32.0,
                                margin: const EdgeInsets.only(
                                  top: 0.0,
                                  left: 20.0,
                                  right: 0.0,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(0xff334155),
                                  border: Border.all(color: const Color(0xff334155)),
                                  borderRadius: BorderRadius.circular(
                                    16.0,
                                  ),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(6.0),
                                  child: SvgPicture.asset(
                                    "images/bell.svg",
                                  ),
                                ),
                              ),
                              label: const Text(''),
                            ),

                            NavigationRailDestination(
                              icon: Container(
                                width: 20.0,
                                height: 18.0,
                                margin: const EdgeInsets.only(
                                  top: 0.0,
                                  left: 20.0,
                                  right: 0.0,
                                ),
                                child: SvgPicture.asset(
                                  "images/setting.svg",
                                ),
                              ),
                              selectedIcon: Container(
                                width: 46.0,
                                height: 32.0,
                                margin: const EdgeInsets.only(
                                  top: 0.0,
                                  left: 20.0,
                                  right: 0.0,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(0xff334155),
                                  border: Border.all(color: const Color(0xff334155)),
                                  borderRadius: BorderRadius.circular(
                                    16.0,
                                  ),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(6.0),
                                  child: SvgPicture.asset(
                                    "images/setting.svg",
                                  ),
                                ),
                              ),
                              label: const Text(''),
                            ),

                          ],
                          selectedIconTheme: const IconThemeData(color: Colors.white),
                          unselectedIconTheme:
                          const IconThemeData(color: Colors.black),
                          selectedLabelTextStyle:
                          const TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                 ),

                );
              }),
              const VerticalDivider(thickness: 0, width: 0),
              Expanded(child: _mainContents[_selectedIndex]),
            ],
          ),

      ),
    );
  }


  //dropdown apis

  Future<String?> getDepartment() async {
    String? value;
    if (value == null) {
      var token='Bearer '+storage.read("token");
      var response = await http.get(
        Uri.parse("http://zeusapitst.crebos.online/api/v1/departments"),
        headers: {
          "Accept": "application/json",
          "Authorization":token,
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body.toString());
        List<dynamic> mdata = map["data"];
        setState(() {
          _department = mdata;
        });
      } else {
        print("failed to much");
      }
      return value;
    }
  }

  Future<String?> getAccountable() async {
    String? value;
    if (value == null) {
      var token='Bearer '+storage.read("token");
      var response = await http.get(
        Uri.parse(AppUrl.accountable_person),
        headers: {
          "Accept": "application/json",
          "Authorization":token,
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body.toString());
        List<dynamic> mdata = map["data"];
        setState(() {
          _accountableId = mdata;
        });
      } else {
        print("failed to much");
      }
      return value;
    }
  }

  Future<String?> getCustomer() async {
    String? value;
    if (value == null) {
      var token='Bearer '+storage.read("token");
      var response = await http.get(
        Uri.parse("http://zeusapitst.crebos.online/api/v1/customer"),
        headers: {
          "Accept": "application/json",
          "Authorization":token,
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body.toString());
        List<dynamic> mdata = map["data"];
        setState(() {
          _customerName = mdata;
        });
      } else {
        print("failed to much");
      }
      return value;
    }
  }

  Future<String?> getCurrency() async {
    String? value;
    if (value == null) {
      var token='Bearer '+storage.read("token");
      var response = await http.get(
        Uri.parse("http://zeusapitst.crebos.online/api/v1/currencies"),
        headers: {
          "Accept": "application/json",
          "Authorization":token,
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body.toString());
        List<dynamic> mdata = map["data"];
        setState(() {
          _currencyName = mdata;
        });
      } else {
        print("failed to much");
      }
      return value;
    }
  }

  Future<String?> getSelectStatus() async {
    String? value;
    if (value == null) {
      var token='Bearer '+storage.read("token");
      var response = await http.get(
        Uri.parse("http://zeusapitst.crebos.online/api/v1/status"),
        headers: {
          "Accept": "application/json",
          "Authorization":token,
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body.toString());
        List<dynamic> mdata = map["data"];
        setState(() {
          _statusList = mdata;
        });
      } else {
        print("failed to much");
      }
      return value;
    }
  }

  Future<String?> getTimeline() async {
    String? value;
    if (value == null) {
      var token='Bearer '+storage.read("token");
      var response = await http.get(
        Uri.parse("http://zeusapitst.crebos.online/api/v1/time-zone/list"),
        headers: {
          "Accept": "application/json",
          "Authorization":token,
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body.toString());
        List<dynamic> mdata = map["data"];
        setState(() {
          _timeline = mdata;
        });
        //var res = response.body;
        //  print('helloDepartment' + res);
        //  DepartmentResponce peopleList = DepartmentResponce.fromJson(json.decode(res));
        // return peopleList;

        // final stringRes = JsonEncoder.withIndent('').convert(res);
        //  print(stringRes);
      } else {
        print("failed to much");
      }
      return value;
    }
  }

  Future<String?> getAddpeople() async {
    String? value;
    if (value == null) {
      var token='Bearer '+storage.read("token");
      var response = await http.get(
        Uri.parse("http://zeusapitst.crebos.online/api/v1/tags"),
        headers: {
          "Accept": "application/json",
          "Authorization":token,
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body.toString());
        List<dynamic> mdata = map["data"];
        setState(() {
          addTag = mdata;
        });
        //var res = response.body;
        //  print('helloDepartment' + res);
        //  DepartmentResponce peopleList = DepartmentResponce.fromJson(json.decode(res));
        // return peopleList;

        // final stringRes = JsonEncoder.withIndent('').convert(res);
        //  print(stringRes);
      } else {
        print("failed to much");
      }
      return value;
    }
  }

  Future<String?> getTagpeople() async {
    String? value;
    if (value == null) {
      var token='Bearer '+storage.read("token");
      var response = await http.get(
        Uri.parse("http://zeusapitst.crebos.online/api/v1/skills?search=lara"),
        headers: {
          "Accept": "application/json",
          "Authorization":token,
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body.toString());
        List<dynamic> mdata = map["data"];
        setState(() {
          addSkills = mdata;
          _addtag = addSkills;
          print('ghjhjhjh'+_addtag.length.toString());
        });
        print("yes to much");
      } else {
        print("failed to much");
      }
      return value;
    }
  }

  onItemChanged(String value) {
    setState(() {
      _addtag = addSkills.where(
              (x) => x['title'].toLowerCase().contains(value.toLowerCase())
      ).toList();
    });
  }
}
