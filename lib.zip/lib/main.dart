import 'package:flutter/material.dart';
import 'package:zeus/DemoClass.dart';
import 'package:zeus/navigator_tabs/idle/data/DataClass.dart';
import 'package:zeus/navigator_tabs/people_idle/data/getdata_provider.dart';
import 'package:zeus/provider/LoginDetail.dart';
import 'package:zeus/provider/auth_provider.dart';
import 'package:zeus/routers/routers_class.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zeus/url/user.dart';
import 'package:zeus/utility/constant.dart';
import 'package:zeus/utility/shared_preference.dart';
import 'DemoContainer.dart';
import 'book.dart';
import 'customscroll_behavior.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz;
import 'dashboard.dart';
import 'login_screen/login.dart';
import 'package:get_storage/get_storage.dart';
import 'package:url_strategy/url_strategy.dart';
import 'navigation/navigation.dart';
import 'package:provider/provider.dart';

import 'navigation/tag_model/tag_user.dart';
import 'navigator_tabs/idle/data/project_detail_data/ProjectDetailData.dart';

void main() async {
  await GetStorage.init();
  setPathUrlStrategy();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // bool?  isLogin;

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => DataIdelClass()),
        ChangeNotifierProvider(create: (_) => PeopleIdelClass()),
        ChangeNotifierProvider(create: (_) => ProjectDetail()),
        ChangeNotifierProvider(create: (_) => TagDetail()),
      ],
      child: MaterialApp(
        scrollBehavior: MyCustomScrollBehavior(),
        home: storage.read(isLogin) == null
            ? LoginScreen(
                onSubmit: (String value) {},
              )
            : MyHomePage(
                onSubmit: (String value) {},
                adOnSubmit: (String value) {},
              ),
        onGenerateRoute: generateRoute,
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}
