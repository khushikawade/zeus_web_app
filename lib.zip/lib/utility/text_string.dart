
class ClassesInfo {
  static const String desc_class1 = "About me";
}