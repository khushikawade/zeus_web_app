import 'package:get_storage/get_storage.dart';

var storage = GetStorage();

const String isLogin = "isLogin";
// ignore: constant_identifier_names
const String Uid = "userId";
// ignore: constant_identifier_names
const String u_Name = "name";
// ignore: constant_identifier_names
const String u_lname = "lname";
// ignore: constant_identifier_names
const String u_email = "email";
const String frndList = "friendList";
const String usersList = "usersList";
const String fcmToken = "fcmToken";
const String meetingType = "meetingType";
const String remoteUser = "remoteUser";
const String values = "values";
const String audioMeetingType = "audio";
const String videoMeetingType = "video";
