/*
import 'package:flutter/cupertino.dart';
import 'package:zeus/url/user.dart';


class UserDetailsProvider extends ChangeNotifier {
  User _user = User();

  User get user => _user;

  void setUser (User user){
    _user = user;
    notifyListeners();
  }
}*/
