import 'dart:collection';
import 'dart:developer';
import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../../url/service_class.dart';
import '../model/model_class.dart';

class PeopleIdelClass with ChangeNotifier {

  Service service=Service();
  PeopleList? peopleList;
  bool loading = false;


  Future<void> getPeople() async {

    loading = true;
    peopleList = (await service.getpeopleList())!;
    print("java");
    // print(peopleIdelResponse);
    loading = false;
    notifyListeners();
  }
}