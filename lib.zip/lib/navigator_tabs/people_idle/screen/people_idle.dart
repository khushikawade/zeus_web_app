import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:zeus/utility/app_url.dart';
import '../../../utility/colors.dart';
import '../../../people_profile/screen/people_detail_view.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';
import '../../../utility/constant.dart';
import '../../idle/data/project_detail_data/ProjectDetailData.dart';
import '../data/getdata_provider.dart';
import '../model/model_class.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PeopleIdle extends StatefulWidget {
  const PeopleIdle({Key? key}) : super(key: key);

  @override
  State<PeopleIdle> createState() => _PeopleIdleState();
}

class _PeopleIdleState extends State<PeopleIdle> {

  List _timeline = [];
  String? _depat, _account, _custome, _curren, _status, _time, _tag;
  String token = "";
  var dataPeople = 'people_data';
  Future? _getList;
  var postion;
  SharedPreferences? sharedPreferences;
  final ScrollController _horizontal_scrollcontroller = ScrollController();
  final ScrollController _vertical_scrollcontroller=ScrollController();
  var name;

  Future getPeopleData(){
    return Provider.of<PeopleIdelClass>(context, listen: false).getPeople();
  }

  Future? getList;
  Future getListData1(){
    return Provider.of<ProjectDetail>(context, listen: false).changeProfile();
  }

  @override
  void didChangeDependencies() {
    print('hello people idele');
    getList=getListData1();
    super.didChangeDependencies();
  }

  void change()async{
    var prefs = await SharedPreferences.getInstance();
    prefs.setString('val', 'y');
  }

  @override
  void initState() {
    _getList=getPeopleData();
    change();
    getToken();
   // getpeople();
    super.initState();
  }

  void getToken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        token = sharedPreferences.getString('login')!;
     //   name = sharedPreferences.getString('user')!;
        print(token);
      });
      return;
    }
  }

  @override
  Widget build(BuildContext context) {
    double deviceHeight(BuildContext context) => MediaQuery.of(context).size.height;

    double deviceWidth(BuildContext context) => MediaQuery.of(context).size.width;
    final mediaQueryData = MediaQuery.of(context);
    return MediaQuery(
      data: mediaQueryData.copyWith(textScaleFactor: 1.0),
      child: Scaffold(
            backgroundColor: ColorSelect.class_color,
            body:
                SingleChildScrollView(
                  child:  Container(
                    width: MediaQuery.of(context).size.width * 0.90,
                    height: MediaQuery.of(context).size.height * 0.83,
                    margin: const EdgeInsets.only(
                        left: 40.0, right: 30.0, bottom: 10.0, top: 40.0),
                    decoration: BoxDecoration(
                      color: const Color(0xff1E293B),
                      border: Border.all(color: const Color(0xff1E293B)),
                      borderRadius: BorderRadius.circular(
                        12.0,
                      ),
                    ),


                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Container(
                                width: 168.0,
                                margin: const EdgeInsets.only(
                                    left: 16.0, top: 16.0),
                                child:  const Text(
                                  "Name",
                                  style: TextStyle(
                                      color: ColorSelect.text_color,
                                      fontSize: 14.0,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500),
                                ),
                              ),

                              InkWell(
                                onTap: (){

                                },
                                child: Container(
                                  margin:  const EdgeInsets.only(
                                      left: 120.0, top: 16.0),
                                  child:  const Text(
                                    "Nickname",
                                    style: TextStyle(
                                        color: ColorSelect.text_color,
                                        fontSize: 14.0,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w500),
                                  ),
                                ),
                              ),



                              Container(
                                margin: const EdgeInsets.only(
                                    left: 82.0, top: 16.0),
                                child:  const Text(
                                  "Capacity",
                                  style: TextStyle(
                                      color: ColorSelect.text_color,
                                      fontSize: 14.0,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500),
                                ),
                              ),

                            //  Spacer(flex: 1,),


                              Container(
                                margin: const EdgeInsets.only(
                                    top: 16.0, left: 45.0),
                                child:  const Text(
                                  "Occupied till",
                                  style: TextStyle(
                                      color: ColorSelect.text_color,
                                      fontSize: 14.0,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500),
                                ),
                              ),

                             // Spacer(flex: 1,),


                              Container(
                                width: 150.0,
                                margin: const EdgeInsets.only(top: 16.0,left: 45.0),
                                child:  const Text(
                                  "Scheduled on",
                                  style: TextStyle(
                                      color: ColorSelect.text_color,
                                      fontSize: 14.0,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500),
                                ),
                              ),

                             // Spacer(flex: 1,),


                              InkWell(
                                onTap: (){

                                },
                                child: Container(
                                  margin: const EdgeInsets.only(
                                      top: 16.0, left: 0.0),
                                  child:  const Text(
                                    "Skills",
                                    style: TextStyle(
                                        color: ColorSelect.text_color,
                                        fontSize: 14.0,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w500),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 8.0,
                          ),
                          Container(
                              margin: const EdgeInsets.only(left: 16.0, right: 16.0),
                              child: const Divider(
                                color: ColorSelect.text_color,
                                thickness: 0.1,
                              )),

                          Expanded(
                           flex: 1,
                            child: FutureBuilder(
                                future: _getList,
                              builder: (context, snapshot) {
                              if(snapshot.connectionState==ConnectionState.waiting) {
                              return const Center(
                                    child:CircularProgressIndicator());
                               } else {
                                return
                                Consumer<PeopleIdelClass>(
                                builder: (context,data,_){
                                  return data.peopleList!.data!=null ? const Center(child: Text("No Records Found !",style: TextStyle(
                                      color: Color(0xffFFFFFF),
                                      fontSize: 22.0,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500),)) : ListView.builder(
                                      shrinkWrap: true,
                                      scrollDirection: Axis.vertical,
                                      itemCount:data.peopleList!.data!.length,
                                      itemBuilder: (BuildContext context, int index) {
                                        PeopleData _peopleList =  data.peopleList!.data![index];
                                        print(data);
                                        postion=[index];

                                        var name=_peopleList.name;
                                        var designation=_peopleList.resource!.designation;
                                        var associate=_peopleList.resource!.associate;
                                        var nickname=_peopleList.resource!.nickname;
                                        var image=_peopleList.image;

                                        return InkWell(
                                          onTap: (){
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) => ProfileDetail(
                                                        list : _peopleList)));


                                             // Navigator.pushNamed(context, "/ProfileScreen",arguments:{ "datalist" : _peopleList});

                                          },
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                height: 52.0,
                                                child:  Row(
                                                  // crossAxisAlignment: CrossAxisAlignment.stretch,
                                                  //  mainAxisAlignment:MainAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                        width: 32.0,
                                                        height: 32.0,
                                                        margin: const EdgeInsets.only(
                                                            left: 20.0, top: 10.0),
                                                        decoration: BoxDecoration(
                                                          color: const Color(0xff334155),
                                                          borderRadius:
                                                          BorderRadius.circular(
                                                            40.0,
                                                          ),
                                                        ),
                                                        child:  CircleAvatar(
                                                          radius: 20,
                                                          backgroundImage:
                                                          NetworkImage(
                                                              image!),
                                                        )
                                                    ),



                                                    Column(
                                                      children: [
                                                        Container(
                                                          width: 200.0,

                                                          margin: const EdgeInsets.only(
                                                              left: 16.0, top: 7.5),
                                                          child:  Text(
                                                            "$name",
                                                            style: const TextStyle(
                                                                color: ColorSelect.white_color,
                                                                fontSize: 14.0,
                                                                fontFamily: 'Inter',
                                                                fontWeight: FontWeight.w500),
                                                          ),
                                                        ),

                                                        Container(
                                                          width: 200.0,
                                                          margin: const EdgeInsets.only(
                                                              left: 16.0,top: 5.5 ),
                                                          child:  Text(
                                                            "$designation,$associate",
                                                            style: const TextStyle(
                                                                color: ColorSelect.designation_color,
                                                                fontSize: 14.0,
                                                                fontFamily: 'Inter',
                                                                fontWeight: FontWeight.w500),
                                                          ),
                                                        ),
                                                      ],
                                                    ),


                                                    Container(
                                                      width: 100.0,
                                                      margin: const EdgeInsets.only(
                                                          left: 37.0, top: 5.0),
                                                      child:  Text(
                                                        "@$nickname",
                                                        style: const TextStyle(
                                                            color: ColorSelect.white_color,
                                                            fontSize: 14.0,
                                                            fontFamily: 'Inter',
                                                            fontWeight: FontWeight.w500),
                                                      ),
                                                    ),

                                                    Container(
                                                      width: 100.0,
                                                      margin: const EdgeInsets.only(
                                                          left: 48.0, top: 5.0),
                                                      child:  const Text(
                                                        "40h/week",
                                                        style: TextStyle(
                                                            color: ColorSelect.white_color,
                                                            fontSize: 14.0,
                                                            fontFamily: 'Inter',
                                                            fontWeight: FontWeight.w500),
                                                      ),
                                                    ),

                                                    Container(
                                                      width: 100.0,
                                                      margin: const EdgeInsets.only(
                                                          left: 8.0, top: 5.0),
                                                      child:  const Text(
                                                        "24 Oct",
                                                        style: TextStyle(
                                                            color: ColorSelect.white_color,
                                                            fontSize: 14.0,
                                                            fontFamily: 'Inter',
                                                            fontWeight: FontWeight.w500),
                                                      ),
                                                    ),

                                                    Container(
                                                      width: 136.0,
                                                      margin: const EdgeInsets.only(
                                                          left: 27.0, top: 5.0),
                                                      child:  const Text(
                                                        "Screaming",
                                                        style: TextStyle(
                                                            color: ColorSelect.white_color,
                                                            fontSize: 14.0,
                                                            fontFamily: 'Inter',
                                                            fontWeight: FontWeight.w500),
                                                      ),
                                                    ),

                                                    SizedBox(
                                                      height: 35,
                                                      child: Padding(
                                                        padding:const EdgeInsets.only(left: 0.0),
                                                        child: FutureBuilder(
                                                            future: _getList,
                                                            builder: (context, snapshot) {
                                                              if(snapshot.connectionState==ConnectionState.waiting) {
                                                                return const Center(child:CircularProgressIndicator());
                                                              } else {
                                                                return Consumer<PeopleIdelClass>(
                                                                    builder: (context,data,_){
                                                                      return ListView.builder(
                                                                        shrinkWrap: true,
                                                                        scrollDirection: Axis.horizontal,

                                                                        itemCount: data.peopleList!.data![0].resource!.skills!.length,
                                                                        itemBuilder: (BuildContext context, int index) {
                                                                          //PeopleData _peopleListSkills = data.peopleList!.data![index];
                                                                          Skills _skills=data.peopleList!.data![0].resource!.skills![index];
                                                                          var skill=_skills.title;
                                                                          postion=index;
                                                                          return Container(
                                                                            height: 35.0,
                                                                            margin: const EdgeInsets.only(left: 12.0, top: 5.0),
                                                                            decoration: BoxDecoration(
                                                                              color: const Color(0xff334155),
                                                                              borderRadius: BorderRadius.circular(
                                                                                8.0,
                                                                              ),
                                                                            ),
                                                                            child:  Align(
                                                                              alignment: Alignment.center,
                                                                              child: Padding(
                                                                                padding: EdgeInsets.only(top: 6.0,bottom: 6.0,right: 12.0,left: 12.0),
                                                                                child: Text(
                                                                                  '$skill',
                                                                                  style: const TextStyle(
                                                                                      color: ColorSelect.white_color,
                                                                                      fontSize: 14.0,
                                                                                      fontFamily: 'Inter',
                                                                                      fontWeight:
                                                                                      FontWeight.w400),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          );
                                                                        },
                                                                      );
                                                                    }
                                                                );

                                                              }
                                                            }

                                                        ),
                                                      ),
                                                    ),

                                                    Spacer(),


                                                    InkWell(
                                                      onTap: (){
                                                        PopupMenuButton<Text>(
                                                            itemBuilder: (context) => <PopupMenuEntry<Text>>[
                                                              const PopupMenuItem<Text>(
                                                                child: Text('Working a lot harder'),
                                                              ),
                                                            ]);
                                                      },
                                                      child: Container(
                                                        margin: const EdgeInsets.only(right: 16.0,top: 5.0),
                                                        height: 30.0,
                                                        width: 30.0,
                                                        decoration: BoxDecoration(
                                                            border: Border.all(
                                                              color: Color(0xff334155),
                                                            ),
                                                            borderRadius: BorderRadius.all(Radius.circular(40))
                                                        ),
                                                        child: Padding(
                                                          padding: EdgeInsets.all(8.0),
                                                          child: SvgPicture.asset(
                                                            "images/edit.svg",
                                                          ),
                                                        ),
                                                      ),
                                                    )

                                                  ],
                                                ),
                                              ),

                                             /* const SizedBox(
                                                height: 8.0,
                                              ),*/
                                              Container(
                                                  margin: const EdgeInsets.only(
                                                      left: 16.0, right: 16.0),
                                                  child:  Divider(
                                                    color: ColorSelect.text_color,
                                                    thickness: 0.1,
                                                  )),
                                            ],
                                          ),
                                        );
                                      },
                                    );
                                }

                                );
                                  }
                               }

                              ),
                          ),

                        ],
                      ),
                    ),

                ),

          ),
    );



  }

  Future<String?> getTimeline() async {
    String? value;
    if (value == null) {
      var token='Bearer '+storage.read("token");
      var response = await http.get(
        Uri.parse("http://zeusapitst.crebos.online/api/v1/time-zone/list"),
        headers: {
          "Accept": "application/json",
          "Authorization":token,
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body.toString());
        List<dynamic> mdata = map["data"];
        setState(() {
          _timeline = mdata;
        });
        //var res = response.body;
        //  print('helloDepartment' + res);
        //  DepartmentResponce peopleList = DepartmentResponce.fromJson(json.decode(res));
        // return peopleList;

        // final stringRes = JsonEncoder.withIndent('').convert(res);
        //  print(stringRes);
      } else {
        print("failed to much");
      }
      return value;
    }
  }



}
