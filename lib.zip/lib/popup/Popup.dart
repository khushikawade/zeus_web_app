import 'package:provider/provider.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:async';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:zeus/navigator_tabs/idle/data/project_detail_data/ProjectDetailData.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import '../navigation/navigation.dart';
import '../navigator_tabs/idle/project_detail_model/project_detail_response.dart';
import '../utility/app_url.dart';
import '../utility/colors.dart';
import '../utility/constant.dart';

   showDailog(BuildContext context,ProjectDetailResponse response, List statusList, List currencyName, List accountableId, List customerName, String? id){
     //print('listdata'+statusList.length.toString());
      //print('datacomefast'+response.data!.phase!.length.toString());
      DateTime selectedDate = DateTime.now();
      String? _account,_custome,_curren,_status;
      var titile=response.data!.title;
     final ValueChanged<String> onSubmit;
      var _id=id;
     var _formKey = GlobalKey<FormState>();
     var isLoading = false;
     var status=response.data!.status;
      bool _submitted = false;

     //var phase =response.data!.phase![0].milestone!.length;

     /*void _submit() {
       final isValid = _formKey.currentState!.validate();
       if (!isValid) {
         editProject();
         Navigator.push(
             context,
             MaterialPageRoute(builder: (context) =>
                 MyHomePage(onSubmit: (String value) {  },)));
        // widget.onSubmit(_name);
         return;
       }
       _formKey.currentState!.save();
     }*/

     final TextEditingController _projecttitle=TextEditingController();
     final TextEditingController _crmtask=TextEditingController();
     final TextEditingController _warkfolderId=TextEditingController();
     final TextEditingController _budget=TextEditingController();
     final TextEditingController _estimatehours=TextEditingController();
     final TextEditingController _description=TextEditingController();
     var myFormat = DateFormat('d MMM yyyy');

     //Edit project api
     Future<void> editProject() async {
       var token='Bearer '+storage.read("token");
        try{
           var response= await http.put(Uri.parse('http://zeusapitst.crebos.online/api/v1/project/$_id'),
              body:jsonEncode ({
                 "title": _projecttitle.text.toString(),
                 "accountable_person_id": _account,
                 "customer_id": _custome,
                 "crm_task_id": _crmtask.text.toString(),
                 "work_folder_id": _warkfolderId.text.toString(),
                 "budget": _budget.toString(),
                 "currency":"&",
                 "estimation_hours": _estimatehours.toString(),
                 "status":_status,
              }),
              headers: {
                 "Content-Type": "application/json",
                "Authorization":token,
              },
           );
           // ignore: unrelated_type_equality_checks
           if(response.statusCode==200){
              var responseJson = jsonDecode(response.body.toString()) as Map<String,dynamic>;
              final stringRes = JsonEncoder.withIndent('').convert(responseJson);
              print(stringRes);
              print("yes Creaete");
              print(response.body);
           }else{
              print("failuree");
           }
        } catch(e) {

           // print('error caught: $e');
        }
     }

     //Add description and time api
     Future<void> addDescriptionProject() async {
       var token='Bearer '+storage.read("token");
       try{
         var response= await http.put(Uri.parse('http://zeusapitst.crebos.online/api/v1/project/project-dates/$_id'),
           body:jsonEncode ({
             "description": _description.text.toString(),
             //"cost": dropdownvalue,
             "working_days":'12',//dropdownvalue ,
             "deadline_date": myFormat.format(selectedDate),
             "reminder_date": myFormat.format(selectedDate),
             "delivery_date":myFormat.format(selectedDate) ,
           }),
           headers: {
             "Content-Type": "application/json",
             "Authorization":token,
           },
         );
         // ignore: unrelated_type_equality_checks
         if(response.statusCode==200){
           var responseJson = jsonDecode(response.body.toString()) as Map<String,dynamic>;
           final stringRes = JsonEncoder.withIndent('').convert(responseJson);
           print(stringRes);
           print("yes description");
           print(response.body);
         }else{
           print("failuree");
         }
       } catch(e) {

         // print('error caught: $e');
       }
     }

     Future<void> _selectDate(setState) async {
       final DateTime? picked = await showDatePicker(
           context: context,
           builder: (BuildContext context, Widget? child){
             return Theme(
               data: ThemeData.light().copyWith(
                   primaryColor: const  Color(0xff0F172A),
                   accentColor: const  Color(0xff0F172A),
                   colorScheme: ColorScheme.light(primary: const  Color(0xff0F172A)),
                   buttonTheme: ButtonThemeData(textTheme: ButtonTextTheme.primary)
               ), child: child!,
             );
           },
           initialDate: selectedDate,
           firstDate: new DateTime.now().subtract(new Duration(days: 0)),
           lastDate: DateTime(2101));

       if (picked != null && picked != selectedDate) {
         setState(() {
           selectedDate = picked;
         });
       }
     }

     // print('getProjectDetail'+response!.data!.deliveryDate.toString());
      var start_date=response.data!.createdAt.toString();
      var reminder_date=response.data!.reminderDate.toString();
      var delivery_date=response.data!.deliveryDate.toString();
      var deadline_date=response.data!.deadlineDate.toString();
      var warking_date=response.data!.workingDays.toString();
      //var dataList=response!.data!.phase!.length;
     // var start_date=response.data!..toString();
      var date_start;
      var reminderDate;
      var deleverydate;
      var deadlineDate;

      /*if(start_date!=null){
        var inputDate = DateTime.parse(start_date);
        var outputFormat = DateFormat('d MMM 2022');
         date_start = outputFormat.format(inputDate);
      } else if(reminder_date!=null){
          var _reminderdate = DateTime.parse(reminder_date);
          var _remind = DateFormat('d MMM YYYY');
           reminderDate = _remind.format(_reminderdate);
        } else if(delivery_date!=null){
          var _delieverdate = DateTime.parse(delivery_date);
          var _dl = DateFormat('d MMM YYYY');
           deleverydate = _dl.format(_delieverdate);
        } else if(deadline_date!=null){
          var _deadlinete = DateTime.parse(deadline_date);
          var _dead = DateFormat('d MMM 2022');
           deadlineDate = _dead.format(_deadlinete);
        }*/

     /* var inputDate = DateTime.parse(start_date);
      var outputFormat = DateFormat('d MMM 2022');
      date_start = outputFormat.format(inputDate);

      var _reminderdate = DateTime.parse(reminder_date);
      var _remind = DateFormat('d MMM 2022');
      reminderDate = _remind.format(_reminderdate);

      var _delieverdate = DateTime.parse(delivery_date);
      var _dl = DateFormat('d MMM 2022');
      deleverydate = _dl.format(_delieverdate);

      var _deadlinete = DateTime.parse(deadline_date);
      var _dead = DateFormat('d MMM 2022');
      deadlineDate = _dead.format(_deadlinete);*/


     String dropdownvalue = warking_date;
     var items = [
       ' 1',
       ' 2'
     ];
     for(var i=1;i<=365;i++) {
       items.add("$i");
     }

      //   print(projectDetail.projectDetailResponse!.data!.title);
      showDialog(
          context: context,
          builder: (context) {
             return StatefulBuilder(
                builder: (context, setState) => AlertDialog(
                   shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                   ),
                   contentPadding: EdgeInsets.zero,
                   backgroundColor: const Color(0xff1E293B),
                   content: SizedBox(
                      width: MediaQuery.of(context).size.width * 0.99,
                      height: MediaQuery.of(context).size.height * 0.99,
                      child: Form(

                        child: Column(
                           crossAxisAlignment: CrossAxisAlignment.start,
                           children: [
                              SizedBox(
                                 height: 450,
                                 child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [

                                       Expanded(
                                          flex:1,
                                          child: Column(
                                             mainAxisAlignment: MainAxisAlignment.start,
                                             crossAxisAlignment: CrossAxisAlignment.start,
                                             children: [
                                                Row(
                                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                   children: [
                                                      Column(
                                                         crossAxisAlignment: CrossAxisAlignment.start,
                                                         children: [
                                                            Container(
                                                               margin: const EdgeInsets.only(left: 30.0, top: 30.0),
                                                               child:  const Text(
                                                                  "Simple Ceremonies",
                                                                  style: TextStyle(color: Color(0xffFFFFFF), fontSize: 22.0,
                                                                      fontFamily: 'Inter', fontWeight: FontWeight.w700),
                                                               ),
                                                            ),

                                                           Row(
                                                               children: [
                                                                 if(status=="Open")...[
                                                                   Container(
                                                                     height: 32.0,
                                                                     width: 82.0,
                                                                     margin: const EdgeInsets.only(
                                                                         left: 30.0,
                                                                         right: 12.0,
                                                                         top: 12.0),
                                                                     decoration: BoxDecoration(
                                                                       color: const Color(0xff16A34A),
                                                                       //border: Border.all(color: const Color(0xff0E7490)),
                                                                       borderRadius:
                                                                       BorderRadius.circular(
                                                                         8.0,
                                                                       ),
                                                                     ),
                                                                     child: const Align(
                                                                       alignment: Alignment.center,
                                                                       child: Padding(
                                                                         padding: EdgeInsets.only(left: 12.0,right: 12.0,top: 6.0,bottom: 6.0),
                                                                         child:
                                                                         Text(
                                                                           "Open",
                                                                           style: TextStyle(
                                                                               color: Color(0xffFFFFFF),
                                                                               fontSize: 14.0,
                                                                               fontFamily: 'Inter',
                                                                               fontWeight:
                                                                               FontWeight.w500),
                                                                         ),
                                                                       ),
                                                                     ),
                                                                   ),
                                                                 ] else if(status=='On track')...[
                                                                   Container(
                                                                     height: 32.0,
                                                                     width: 82.0,
                                                                     margin: const EdgeInsets.only(
                                                                         left: 30.0,
                                                                         right: 12.0,
                                                                         top: 12.0),
                                                                     decoration: BoxDecoration(
                                                                       color: const Color(0xff16A34A),
                                                                       //border: Border.all(color: const Color(0xff0E7490)),
                                                                       borderRadius:
                                                                       BorderRadius.circular(
                                                                         8.0,
                                                                       ),
                                                                     ),
                                                                     child: const Align(
                                                                       alignment: Alignment.center,
                                                                       child: Padding(
                                                                         padding: EdgeInsets.only(left: 12.0,right: 12.0,top: 6.0,bottom: 6.0),
                                                                         child:
                                                                         Text(
                                                                           "On track",
                                                                           style: TextStyle(
                                                                               color: Color(0xffFFFFFF),
                                                                               fontSize: 14.0,
                                                                               fontFamily: 'Inter',
                                                                               fontWeight:
                                                                               FontWeight.w500),
                                                                         ),
                                                                       ),
                                                                     ),
                                                                   ),
                                                                 ] else if(status=='Live')...[
                                                                   Container(
                                                                     height: 32.0,
                                                                     width: 52.0,
                                                                     margin: const EdgeInsets.only(
                                                                         left: 30.0,
                                                                         right: 12.0,
                                                                         top: 12.0),
                                                                     decoration: BoxDecoration(
                                                                       color: const Color(0xff16A34A),
                                                                       //border: Border.all(color: const Color(0xff0E7490)),
                                                                       borderRadius:
                                                                       BorderRadius.circular(
                                                                         8.0,
                                                                       ),
                                                                     ),
                                                                     child: const Align(
                                                                       alignment: Alignment.center,
                                                                       child: Padding(
                                                                         padding: EdgeInsets.only(left: 12.0,right: 12.0,top: 6.0,bottom: 6.0),
                                                                         child:
                                                                         Text(
                                                                           "Live",
                                                                           style: TextStyle(
                                                                               color: Color(0xffFFFFFF),
                                                                               fontSize: 14.0,
                                                                               fontFamily: 'Inter',
                                                                               fontWeight:
                                                                               FontWeight.w500),
                                                                         ),
                                                                       ),
                                                                     ),
                                                                   ),
                                                                 ] else if(status=="Design sent for approval")...[
                                                                   Container(
                                                                     height: 32.0,
                                                                     width: 190.0,
                                                                     margin: const EdgeInsets.only(
                                                                         left: 20.0,
                                                                         right: 12.0,
                                                                         top: 12.0),
                                                                     decoration: BoxDecoration(
                                                                       color: const Color(0xff115E59),
                                                                       //border: Border.all(color: const Color(0xff0E7490)),
                                                                       borderRadius:
                                                                       BorderRadius.circular(
                                                                         8.0,
                                                                       ),
                                                                     ),
                                                                     child: const Align(
                                                                       alignment: Alignment.center,
                                                                       child: Padding(
                                                                         padding: EdgeInsets.only(left: 12.0,right: 12.0,top: 6.0,bottom: 6.0),
                                                                         child:
                                                                         Text(
                                                                           "Design sent for approval",
                                                                           style: TextStyle(
                                                                               color: Color(0xffFFFFFF),
                                                                               fontSize: 14.0,
                                                                               fontFamily: 'Inter',
                                                                               fontWeight:
                                                                               FontWeight.w500),
                                                                         ),
                                                                       ),
                                                                     ),
                                                                   ),
                                                                 ] else if(status=="New features request")...[
                                                                   Container(
                                                                     height: 32.0,
                                                                     width: 171.0,
                                                                     margin: const EdgeInsets.only(
                                                                         left: 30.0,
                                                                         right: 12.0,
                                                                         top: 12.0),
                                                                     decoration: BoxDecoration(
                                                                       color: const Color(0xffA21CAF),
                                                                       //border: Border.all(color: const Color(0xff0E7490)),
                                                                       borderRadius:
                                                                       BorderRadius.circular(
                                                                         8.0,
                                                                       ),
                                                                     ),
                                                                     child: const Align(
                                                                       alignment: Alignment.center,
                                                                       child: Padding(
                                                                         padding: EdgeInsets.only(left: 12.0,right: 12.0,top: 6.0,bottom: 6.0),
                                                                         child:
                                                                         Text(
                                                                           "New features request",
                                                                           style: TextStyle(
                                                                               color: Color(0xffFFFFFF),
                                                                               fontSize: 14.0,
                                                                               fontFamily: 'Inter',
                                                                               fontWeight:
                                                                               FontWeight.w500),
                                                                         ),
                                                                       ),
                                                                     ),
                                                                   ),
                                                                 ] else if(status=="Update request")...[
                                                                   Container(
                                                                     height: 32.0,
                                                                     width: 147.0,
                                                                     margin: const EdgeInsets.only(
                                                                         left: 30.0,
                                                                         right: 12.0,
                                                                         top: 12.0),
                                                                     decoration: BoxDecoration(
                                                                       color: const Color(0xff0E7490),
                                                                       //border: Border.all(color: const Color(0xff0E7490)),
                                                                       borderRadius:
                                                                       BorderRadius.circular(
                                                                         8.0,
                                                                       ),
                                                                     ),
                                                                     child: const Align(
                                                                       alignment: Alignment.center,
                                                                       child: Padding(
                                                                         padding: EdgeInsets.only(left: 12.0,right: 12.0,top: 6.0,bottom: 6.0),
                                                                         child:
                                                                         Text(
                                                                           "Update request",
                                                                           style: TextStyle(
                                                                               color: Color(0xffFFFFFF),
                                                                               fontSize: 14.0,
                                                                               fontFamily: 'Inter',
                                                                               fontWeight:
                                                                               FontWeight.w500),
                                                                         ),
                                                                       ),
                                                                     ),
                                                                   ),
                                                                 ] else if(status=="Sent for approval")...[
                                                                   Container(
                                                                     height: 32.0,
                                                                     width: 147.0,
                                                                     margin: const EdgeInsets.only(
                                                                         left: 30.0,
                                                                         right: 12.0,
                                                                         top: 12.0),
                                                                     decoration: BoxDecoration(
                                                                       color: const Color(0xff166534),
                                                                       //border: Border.all(color: const Color(0xff0E7490)),
                                                                       borderRadius:
                                                                       BorderRadius.circular(
                                                                         8.0,
                                                                       ),
                                                                     ),
                                                                     child: const Align(
                                                                       alignment: Alignment.center,
                                                                       child: Padding(
                                                                         padding: EdgeInsets.only(left: 12.0,right: 12.0,top: 6.0,bottom: 6.0),
                                                                         child:
                                                                         Text(
                                                                           "Sent for approval",
                                                                           style: TextStyle(
                                                                               color: Color(0xffFFFFFF),
                                                                               fontSize: 14.0,
                                                                               fontFamily: 'Inter',
                                                                               fontWeight:
                                                                               FontWeight.w500),
                                                                         ),
                                                                       ),
                                                                     ),
                                                                   ),
                                                                 ] else if(status=='Risk')...[
                                                                   Container(
                                                                     height: 32.0,
                                                                     width: 53.0,
                                                                     margin: const EdgeInsets.only(
                                                                         left: 30.0,
                                                                         right: 12.0,
                                                                         top: 12.0),
                                                                     decoration: BoxDecoration(
                                                                       color: const Color(0xffB91C1C),
                                                                       //border: Border.all(color: const Color(0xff0E7490)),
                                                                       borderRadius:
                                                                       BorderRadius.circular(
                                                                         8.0,
                                                                       ),
                                                                     ),
                                                                     child: const Align(
                                                                       alignment: Alignment.center,
                                                                       child: Padding(
                                                                         padding: EdgeInsets.only(left: 12.0,right: 12.0,top: 6.0,bottom: 6.0),
                                                                         child:
                                                                         Text(
                                                                           "Risk",
                                                                           style: TextStyle(
                                                                               color: Color(0xffFFFFFF),
                                                                               fontSize: 14.0,
                                                                               fontFamily: 'Inter',
                                                                               fontWeight:
                                                                               FontWeight.w500),
                                                                         ),
                                                                       ),
                                                                     ),
                                                                   ),
                                                                 ] else if(status=="Potential risk")...[
                                                                   Container(
                                                                     height: 32.0,
                                                                     width: 113.0,
                                                                     margin: const EdgeInsets.only(
                                                                         left: 30.0,
                                                                         right: 12.0,
                                                                         top: 12.0),
                                                                     decoration: BoxDecoration(
                                                                       color: const Color(0xff9A3412),
                                                                       //border: Border.all(color: const Color(0xff0E7490)),
                                                                       borderRadius:
                                                                       BorderRadius.circular(
                                                                         8.0,
                                                                       ),
                                                                     ),
                                                                     child: const Align(
                                                                       alignment: Alignment.center,
                                                                       child: Padding(
                                                                         padding: EdgeInsets.only(left: 12.0,right: 12.0,top: 6.0,bottom: 6.0),
                                                                         child:
                                                                         Text(
                                                                           "Potential risk",
                                                                           style: TextStyle(
                                                                               color: Color(0xffFFFFFF),
                                                                               fontSize: 14.0,
                                                                               fontFamily: 'Inter',
                                                                               fontWeight:
                                                                               FontWeight.w500),
                                                                         ),
                                                                       ),
                                                                     ),
                                                                   ),
                                                                 ] else...[
                                                                   Container(
                                                                     height: 32.0,
                                                                     width: 53.0,
                                                                     margin: const EdgeInsets.only(
                                                                         left: 30.0,
                                                                         right: 12.0,
                                                                         top: 12.0),
                                                                     decoration: BoxDecoration(
                                                                       color: const Color(0xffB91C1C),
                                                                       //border: Border.all(color: const Color(0xff0E7490)),
                                                                       borderRadius:
                                                                       BorderRadius.circular(
                                                                         8.0,
                                                                       ),
                                                                     ),
                                                                     child: const Align(
                                                                       alignment: Alignment.center,
                                                                       child: Padding(
                                                                         padding: EdgeInsets.only(left: 12.0,right: 12.0,top: 6.0,bottom: 6.0),
                                                                         child:
                                                                         Text(
                                                                           "Risk",
                                                                           style: TextStyle(
                                                                               color: Color(0xffFFFFFF),
                                                                               fontSize: 14.0,
                                                                               fontFamily: 'Inter',
                                                                               fontWeight:
                                                                               FontWeight.w500),
                                                                         ),
                                                                       ),
                                                                     ),
                                                                   ),
                                                                 ],

                                                                 Container(
                                                                   margin: const EdgeInsets.only(
                                                                       left: 16.0, top: 12.0),
                                                                   width: 110 ,
                                                                   height: 32,
                                                                   child: Stack(
                                                                     children: [
                                                                       Positioned(
                                                                         top: 0,
                                                                         child: ClipRRect(
                                                                           borderRadius: BorderRadius.circular(100),
                                                                           child: Image.network(
                                                                             'https://images.unsplash.com/photo-1529665253569-6d01c0eaf7b6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cHJvZmlsZXxlbnwwfHwwfHw%3D&w=1000&q=80',
                                                                             width: 32,
                                                                             height: 32,
                                                                             fit: BoxFit.cover,
                                                                           ),
                                                                         ),
                                                                       ),

                                                                       Positioned(
                                                                         left: 22,
                                                                         child: ClipRRect(
                                                                           borderRadius: BorderRadius.circular(100),
                                                                           child: Image.network(
                                                                             'https://media.istockphoto.com/photos/side-view-of-one-young-woman-picture-id1134378235?k=20&m=1134378235&s=612x612&w=0&h=0yIqc847atslcQvC3sdYE6bRByfjNTfOkyJc5e34kgU=',
                                                                             width: 32,
                                                                             height: 32,
                                                                             fit: BoxFit.cover,
                                                                           ),
                                                                         ),
                                                                       ),

                                                                       Positioned(
                                                                         left: 46.0,
                                                                         child: ClipRRect(
                                                                           borderRadius: BorderRadius.circular(100),
                                                                           child: Container(
                                                                             width: 32,
                                                                             height: 32,
                                                                             color: Color(0xff334155),
                                                                             child: Image.network(
                                                                               'https://media.istockphoto.com/photos/side-view-of-one-young-woman-picture-id1134378235?k=20&m=1134378235&s=612x612&w=0&h=0yIqc847atslcQvC3sdYE6bRByfjNTfOkyJc5e34kgU=',
                                                                               width: 32,
                                                                               height: 32,
                                                                               fit: BoxFit.cover,
                                                                             ),
                                                                           ),
                                                                         ),
                                                                       ),
                                                                        
                                                                        Positioned(
                                                                         left: 70.0,
                                                                         child: ClipRRect(
                                                                           borderRadius: BorderRadius.circular(100),
                                                                           child: Container(
                                                                             width: 32,
                                                                             height: 32,
                                                                             color: Color(0xff334155),
                                                                             child: Image.network(
                                                                               'https://media.istockphoto.com/photos/side-view-of-one-young-woman-picture-id1134378235?k=20&m=1134378235&s=612x612&w=0&h=0yIqc847atslcQvC3sdYE6bRByfjNTfOkyJc5e34kgU=',
                                                                               width: 32,
                                                                               height: 32,
                                                                               fit: BoxFit.cover,
                                                                             ),
                                                                           ),
                                                                         ),
                                                                       ),
                                                                     ],
                                                                   ),
                                                                 ),

                                                                 Stack(
                                                                   clipBehavior: Clip.none,
                                                                   children: [
                                                                     Container(
                                                                       margin: const EdgeInsets.only( left: 12.0,top:8.0),
                                                                       child: SvgPicture.asset(
                                                                         'images/list_ceramony.svg',width: 19.06,height: 17.01,
                                                                       ),
                                                                     ),
                                                                     Positioned(
                                                                       bottom: 10,
                                                                       left: 12,
                                                                       child:  Center(
                                                                         child: Container(
                                                                           margin: const EdgeInsets.only(
                                                                             top: 13.0,
                                                                             left: 8.0,
                                                                           ),
                                                                           height: 16.0,
                                                                           width: 16.0,
                                                                           decoration: const BoxDecoration(
                                                                               color: Colors.red,
                                                                               borderRadius:
                                                                               BorderRadius.all(Radius.circular(20))),
                                                                           child: const Align(
                                                                             alignment: Alignment.center,
                                                                             child:  Text(
                                                                               "2",
                                                                               style: TextStyle(
                                                                                   color: Color(0xffFFFFFF),
                                                                                   fontSize: 11.0,
                                                                                   fontFamily: 'Inter',
                                                                                   fontWeight:
                                                                                   FontWeight.w500),
                                                                             ),
                                                                           ),
                                                                         ),
                                                                       ),
                                                                     ),
                                                                   ],
                                                                 ),

                                                               ],
                                                           ),


                                                         ],
                                                      ),

                                                      GestureDetector(
                                                         onTap: () async {

                                                            await showMenu(
                                                                context: context,
                                                                color: ColorSelect.class_color,
                                                                position:  new RelativeRect.fromLTRB(500.0, 90.0, 500.0, 200.0),
                                                            items: [

                                                               PopupMenuItem(
                                                                  value: 2,
                                                                  child: GestureDetector(
                                                                     onTap: (){
                                                                       Navigator.pop(context);
                                                                       showDialog(
                                                                           context: context,
                                                                           builder: (context) {
                                                                             return StatefulBuilder(
                                                                               builder: (context, setState) => AlertDialog(
                                                                                 shape: RoundedRectangleBorder(
                                                                                   borderRadius: BorderRadius.circular(16),
                                                                                 ),
                                                                                 backgroundColor: const Color(0xff1E293B),
                                                                                 content: Form(
                                                                                   key: _formKey,
                                                                                   child: Container(
                                                                                     width: MediaQuery.of(context).size.width *
                                                                                         0.40,
                                                                                     height:
                                                                                     620.0, //MediaQuery.of(context).size.height * 0.85,
                                                                                     child: Column(
                                                                                       crossAxisAlignment:
                                                                                       CrossAxisAlignment.start,
                                                                                       children: [
                                                                                         Row(
                                                                                           mainAxisAlignment:
                                                                                           MainAxisAlignment.spaceBetween,
                                                                                           children: [
                                                                                             Container(
                                                                                                 margin: const EdgeInsets.only(
                                                                                                     top: 0.0, left: 10.0),
                                                                                                 child: const Text(
                                                                                                   'Edit Project',
                                                                                                   style: TextStyle(
                                                                                                       color:
                                                                                                       Color(0xffFFFFFF),
                                                                                                       fontSize: 18.0,
                                                                                                       fontFamily: 'Inter',
                                                                                                       fontWeight:
                                                                                                       FontWeight.w700),
                                                                                                 )),
                                                                                             GestureDetector(
                                                                                               onTap: (){
                                                                                                 //createProject();
                                                                                                 Navigator.of(context).pop();
                                                                                               },
                                                                                               child: Container(
                                                                                                 margin: const EdgeInsets.only(
                                                                                                     top: 0.0, right: 10.0),
                                                                                                 width: 30,
                                                                                                 height: 30,
                                                                                                 decoration: BoxDecoration(
                                                                                                   shape: BoxShape.circle,
                                                                                                   color:
                                                                                                   const Color(0xff1E293B),
                                                                                                   border: Border.all(
                                                                                                       color:  Color(0xff334155),
                                                                                                       width: 0.6),
                                                                                                 ),
                                                                                                 child: Padding(
                                                                                                   padding: const EdgeInsets.all(10.0),
                                                                                                   child: SvgPicture.asset(
                                                                                                     'images/cross.svg',
                                                                                                   ),
                                                                                                 ),
                                                                                               ),
                                                                                             )
                                                                                           ],
                                                                                         ),

                                                                                         Stack(
                                                                                           children: [
                                                                                             Container(
                                                                                               width: MediaQuery.of(context)
                                                                                                   .size
                                                                                                   .width *
                                                                                                   0.99,
                                                                                               margin: const EdgeInsets.only(
                                                                                                   top: 25.0,
                                                                                                   left: 10.0,
                                                                                                   right: 10.0),
                                                                                               height: 56.0,
                                                                                               decoration: BoxDecoration(
                                                                                                 color: const Color(0xff334155),
                                                                                                 //border: Border.all(color:  const Color(0xff1E293B)),
                                                                                                 borderRadius:
                                                                                                 BorderRadius.circular(
                                                                                                   8.0,
                                                                                                 ),
                                                                                                 boxShadow: const [
                                                                                                   BoxShadow(
                                                                                                     color: Color(0xff475569),
                                                                                                     offset: Offset(
                                                                                                       0.0,
                                                                                                       2.0,
                                                                                                     ),
                                                                                                     blurRadius: 0.0,
                                                                                                     spreadRadius: 0.0,
                                                                                                   ), //BoxShadow
                                                                                                 ],
                                                                                               ),

                                                                                             ),

                                                                                             Column(
                                                                                               crossAxisAlignment:
                                                                                               CrossAxisAlignment.start,
                                                                                               children: [
                                                                                                 Container(
                                                                                                     margin:
                                                                                                     const EdgeInsets.only(
                                                                                                         top: 30.0,
                                                                                                         left: 26.0),
                                                                                                     child: const Text(
                                                                                                       "Project title",
                                                                                                       style: TextStyle(
                                                                                                           fontSize: 13.0,
                                                                                                           color:
                                                                                                           Color(0xff64748B),
                                                                                                           fontFamily: 'Inter',
                                                                                                           fontWeight:
                                                                                                           FontWeight.w500),
                                                                                                     )),


                                                                                               ],
                                                                                             ),

                                                                                             TextFormField(
                                                                                               controller: _projecttitle,
                                                                                               autocorrect: false,
                                                                                               cursorColor:
                                                                                               const Color(0xffFFFFFF),
                                                                                               style: const TextStyle(
                                                                                                   color:
                                                                                                   Color(0xffFFFFFF)),
                                                                                               textAlignVertical:
                                                                                               TextAlignVertical
                                                                                                   .bottom,
                                                                                               keyboardType:
                                                                                               TextInputType.text,
                                                                                               decoration:
                                                                                               InputDecoration(
                                                                                                 //counterText: '',
                                                                                                 // errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                                                                                   contentPadding:
                                                                                                   const EdgeInsets.only(
                                                                                                     bottom: 16.0,
                                                                                                     top: 57.0,
                                                                                                     right: 10,
                                                                                                     left: 26.0,
                                                                                                   ),
                                                                                                   border: InputBorder
                                                                                                       .none,
                                                                                                   hintText: response.data!.title,
                                                                                                   hintStyle: const TextStyle(
                                                                                                       fontSize: 14.0,
                                                                                                       color: Color(
                                                                                                           0xffFFFFFF),
                                                                                                       fontFamily:
                                                                                                       'Inter',
                                                                                                       fontWeight:
                                                                                                       FontWeight
                                                                                                           .w500)),
                                                                                               autovalidateMode: _submitted
                                                                                                   ? AutovalidateMode.onUserInteraction
                                                                                                   : AutovalidateMode.disabled,
                                                                                               validator: (value) {
                                                                                                 //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                                                                                 if(value!.isEmpty){
                                                                                                   return 'Please enter';
                                                                                                 }
                                                                                                 return null;
                                                                                               },
                                                                                               //  onChanged: (text) => setState(() => name_ = text),
                                                                                             ),
                                                                                           ],
                                                                                         ),

                                                                                         Row(
                                                                                           mainAxisAlignment:
                                                                                           MainAxisAlignment.start,
                                                                                           children: [
                                                                                              Container(
                                                                                                   width:240.0,
                                                                                                   margin: const EdgeInsets.only(
                                                                                                       top: 20.0, left: 10.0),
                                                                                                   height: 56.0,
                                                                                                   decoration: BoxDecoration(
                                                                                                     color:
                                                                                                     const Color(0xff334155),
                                                                                                     //border: Border.all(color:  const Color(0xff1E293B)),
                                                                                                     borderRadius:
                                                                                                     BorderRadius.circular(
                                                                                                       8.0,
                                                                                                     ),
                                                                                                     boxShadow: const [
                                                                                                       BoxShadow(
                                                                                                         color:
                                                                                                         Color(0xff475569),
                                                                                                         offset: Offset(
                                                                                                           0.0,
                                                                                                           2.0,
                                                                                                         ),
                                                                                                         blurRadius: 0.0,
                                                                                                         spreadRadius: 0.0,
                                                                                                       ), //BoxShadow
                                                                                                     ],
                                                                                                   ),
                                                                                                   child: Column(
                                                                                                     crossAxisAlignment:
                                                                                                     CrossAxisAlignment.start,
                                                                                                     children: [
                                                                                                       Container(
                                                                                                           margin:
                                                                                                           const EdgeInsets
                                                                                                               .only(
                                                                                                               top: 6.0,
                                                                                                               left: 16.0),
                                                                                                           child: const Text(
                                                                                                             "AP",
                                                                                                             style: TextStyle(
                                                                                                                 fontSize: 13.0,
                                                                                                                 color: Color(
                                                                                                                     0xff64748B),
                                                                                                                 fontFamily:
                                                                                                                 'Inter',
                                                                                                                 fontWeight:
                                                                                                                 FontWeight
                                                                                                                     .w500),
                                                                                                           )),
                                                                                                       Container(
                                                                                                         margin: const EdgeInsets.only(
                                                                                                             top: 5.0,
                                                                                                             left: 0.0),
                                                                                                         height: 20.0,
                                                                                                         child: Container(
                                                                                                             margin:
                                                                                                             const EdgeInsets.only(
                                                                                                                 left: 15.0,
                                                                                                                 right: 20.0),
                                                                                                             // padding: const EdgeInsets.all(2.0),
                                                                                                             child: StatefulBuilder(
                                                                                                               builder: (BuildContext context,
                                                                                                                   StateSettersetState) {
                                                                                                                 return DropdownButtonHideUnderline(
                                                                                                                   child: DropdownButton(
                                                                                                                     dropdownColor:
                                                                                                                     ColorSelect.class_color,
                                                                                                                     value: _account,
                                                                                                                     underline:
                                                                                                                     Container(),
                                                                                                                     hint: const Text(
                                                                                                                       "Select Accountable Persons",
                                                                                                                       style: TextStyle(
                                                                                                                           fontSize: 14.0,
                                                                                                                           color: Color(0xffFFFFFF),
                                                                                                                           fontFamily: 'Inter',
                                                                                                                           fontWeight: FontWeight.w500),
                                                                                                                     ),
                                                                                                                     isExpanded: true,
                                                                                                                     icon: const Icon(                // Add this
                                                                                                                       Icons.arrow_drop_down,  // Add this
                                                                                                                       color: Color(0xff64748B),

                                                                                                                       // Add this
                                                                                                                     ),
                                                                                                                     items: accountableId.map((items) {
                                                                                                                       return DropdownMenuItem(
                                                                                                                         value: items['id'].toString(),
                                                                                                                         child: Text(
                                                                                                                           items['name'],
                                                                                                                           style: const TextStyle(
                                                                                                                               fontSize:
                                                                                                                               14.0,
                                                                                                                               color: Color(
                                                                                                                                   0xffFFFFFF),
                                                                                                                               fontFamily:
                                                                                                                               'Inter',
                                                                                                                               fontWeight:
                                                                                                                               FontWeight
                                                                                                                                   .w500),
                                                                                                                         ),
                                                                                                                       );
                                                                                                                     }).toList(),
                                                                                                                     onChanged: (
                                                                                                                         newValue) {
                                                                                                                       setState(() {
                                                                                                                         _account = newValue;
                                                                                                                         print("account:$_account");
                                                                                                                       });
                                                                                                                     },

                                                                                                                   ),
                                                                                                                 );
                                                                                                               },
                                                                                                             )),
                                                                                                       ),
                                                                                                     ],
                                                                                                   )),

                                                                                             const SizedBox(
                                                                                               width: 12.0,
                                                                                             ),
                                                                                              Container(
                                                                                                   width: 240,
                                                                                                   margin:
                                                                                                   const EdgeInsets.only(
                                                                                                       top: 20.0,
                                                                                                       right: 10.0),
                                                                                                   height: 56.0,
                                                                                                   decoration: BoxDecoration(
                                                                                                     color: const Color(
                                                                                                         0xff334155),
                                                                                                     //border: Border.all(color:  const Color(0xff1E293B)),
                                                                                                     borderRadius:
                                                                                                     BorderRadius.circular(
                                                                                                       8.0,
                                                                                                     ),
                                                                                                     boxShadow: const [
                                                                                                       BoxShadow(
                                                                                                         color:
                                                                                                         Color(0xff475569),
                                                                                                         offset: Offset(
                                                                                                           0.0,
                                                                                                           2.0,
                                                                                                         ),
                                                                                                         blurRadius: 0.0,
                                                                                                         spreadRadius: 0.0,
                                                                                                       ), //BoxShadow
                                                                                                     ],
                                                                                                   ),
                                                                                                   child: Column(
                                                                                                     crossAxisAlignment:
                                                                                                     CrossAxisAlignment
                                                                                                         .start,
                                                                                                     children: [
                                                                                                       Container(
                                                                                                           margin:
                                                                                                           const EdgeInsets
                                                                                                               .only(
                                                                                                               top: 6.0,
                                                                                                               left: 16.0),
                                                                                                           child: const Text(
                                                                                                             "Customer",
                                                                                                             style: TextStyle(
                                                                                                                 fontSize:
                                                                                                                 13.0,
                                                                                                                 color: Color(
                                                                                                                     0xff64748B),
                                                                                                                 fontFamily:
                                                                                                                 'Inter',
                                                                                                                 fontWeight:
                                                                                                                 FontWeight
                                                                                                                     .w500),
                                                                                                           )),
                                                                                                       Container(
                                                                                                           margin:
                                                                                                           const EdgeInsets
                                                                                                               .only(
                                                                                                               top: 5.0,
                                                                                                               right: 18.0,
                                                                                                               left: 15.0),
                                                                                                           height: 20.0,
                                                                                                           child: StatefulBuilder(
                                                                                                             builder: (BuildContext context,
                                                                                                                 StateSettersetState) {
                                                                                                               return DropdownButtonHideUnderline(
                                                                                                                 child: DropdownButton(
                                                                                                                   dropdownColor:
                                                                                                                   ColorSelect.class_color,
                                                                                                                   value: _custome,
                                                                                                                   underline:
                                                                                                                   Container(),
                                                                                                                   hint: const Text(
                                                                                                                     "Select Customer",
                                                                                                                     style: TextStyle(
                                                                                                                         fontSize: 14.0,
                                                                                                                         color: Color(0xffFFFFFF),
                                                                                                                         fontFamily: 'Inter',
                                                                                                                         fontWeight: FontWeight.w500),
                                                                                                                   ),
                                                                                                                   isExpanded: true,
                                                                                                                   icon: const Icon(                // Add this
                                                                                                                     Icons.arrow_drop_down,  // Add this
                                                                                                                     color: Color(0xff64748B),

                                                                                                                     // Add this
                                                                                                                   ),
                                                                                                                   items: customerName.map((items) {
                                                                                                                     return DropdownMenuItem(
                                                                                                                       value: items['id'].toString(),
                                                                                                                       child: Text(
                                                                                                                         items['name'],
                                                                                                                         style: const TextStyle(
                                                                                                                             fontSize:
                                                                                                                             14.0,
                                                                                                                             color: Color(
                                                                                                                                 0xffFFFFFF),
                                                                                                                             fontFamily:
                                                                                                                             'Inter',
                                                                                                                             fontWeight:
                                                                                                                             FontWeight
                                                                                                                                 .w500),
                                                                                                                       ),
                                                                                                                     );
                                                                                                                   }).toList(),
                                                                                                                   onChanged: (
                                                                                                                       newValue) {
                                                                                                                     setState(() {
                                                                                                                       _custome = newValue;
                                                                                                                       print("account:$_custome");
                                                                                                                     });
                                                                                                                   },

                                                                                                                 ),
                                                                                                               );
                                                                                                             },
                                                                                                           )),

                                                                                                     ],
                                                                                                   )),


                                                                                           ],
                                                                                         ),

                                                                                         Stack(
                                                                                           children: [
                                                                                             Container(
                                                                                                 width: MediaQuery.of(context)
                                                                                                     .size
                                                                                                     .width *
                                                                                                     0.99,
                                                                                                 margin: const EdgeInsets.only(
                                                                                                     top: 20.0,
                                                                                                     left: 10.0,
                                                                                                     right: 10.0),
                                                                                                 height: 56.0,
                                                                                                 decoration: BoxDecoration(
                                                                                                   color: const Color(0xff334155),
                                                                                                   //border: Border.all(color:  const Color(0xff1E293B)),
                                                                                                   borderRadius:
                                                                                                   BorderRadius.circular(
                                                                                                     8.0,
                                                                                                   ),
                                                                                                   boxShadow: const [
                                                                                                     BoxShadow(
                                                                                                       color: Color(0xff475569),
                                                                                                       offset: Offset(
                                                                                                         0.0,
                                                                                                         2.0,
                                                                                                       ),
                                                                                                       blurRadius: 0.0,
                                                                                                       spreadRadius: 0.0,
                                                                                                     ), //BoxShadow
                                                                                                   ],
                                                                                                 ),
                                                                                             ),

                                                                                             Column(
                                                                                       crossAxisAlignment:
                                                                                       CrossAxisAlignment.start,
                                                                                       children: [
                                                                                         Container(
                                                                                             margin:
                                                                                             const EdgeInsets.only(
                                                                                                 top: 30.0,
                                                                                                 left: 26.0),
                                                                                             child: const Text(
                                                                                               "CRM task ID",
                                                                                               style: TextStyle(
                                                                                                   fontSize: 13.0,
                                                                                                   color: Color(
                                                                                                       0xff64748B),
                                                                                                   fontFamily: 'Inter',
                                                                                                   fontWeight:
                                                                                                   FontWeight
                                                                                                       .w500),
                                                                                             )),

                                                                                       ],
                                                                                     ),

                                                                                             TextFormField(
                                                                                               controller: _crmtask,
                                                                                               cursorColor: const Color(
                                                                                                   0xffFFFFFF),
                                                                                               style: const TextStyle(
                                                                                                   color: Color(
                                                                                                       0xffFFFFFF)),
                                                                                               textAlignVertical:
                                                                                               TextAlignVertical
                                                                                                   .bottom,
                                                                                               keyboardType:
                                                                                               TextInputType.text,
                                                                                               decoration:
                                                                                               InputDecoration(
                                                                                                   errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                                                                                   contentPadding:
                                                                                                   const EdgeInsets
                                                                                                       .only(
                                                                                                     bottom: 16.0,
                                                                                                     top: 57.0,
                                                                                                     right: 16,
                                                                                                     left: 26.0,
                                                                                                   ),
                                                                                                   border:
                                                                                                   InputBorder
                                                                                                       .none,
                                                                                                   hintText: response.data!.crmTaskId,
                                                                                                   hintStyle: const TextStyle(
                                                                                                       fontSize:
                                                                                                       14.0,
                                                                                                       color: Color(
                                                                                                           0xffFFFFFF),
                                                                                                       fontFamily:
                                                                                                       'Inter',
                                                                                                       fontWeight:
                                                                                                       FontWeight
                                                                                                           .w500)),
                                                                                               autovalidateMode: _submitted
                                                                                                   ? AutovalidateMode.onUserInteraction
                                                                                                   : AutovalidateMode.disabled,

                                                                                               validator: (value) {
                                                                                                 //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                                                                                 if(value!.isEmpty){
                                                                                                   return 'Please enter';
                                                                                                 }
                                                                                                 return null;
                                                                                               },
                                                                                               //  onChanged: (text) => setState(() => name_ = text),
                                                                                             ),
                                                                                           ],
                                                                                         ),

                                                                                         Stack(
                                                                                           children: [
                                                                                             Container(
                                                                                                 width: MediaQuery.of(context)
                                                                                                     .size
                                                                                                     .width *
                                                                                                     0.99,
                                                                                                 margin: const EdgeInsets.only(
                                                                                                     top: 20.0,
                                                                                                     left: 10.0,
                                                                                                     right: 10.0),
                                                                                                 height: 56.0,
                                                                                                 decoration: BoxDecoration(
                                                                                                   color: const Color(0xff334155),
                                                                                                   //border: Border.all(color:  const Color(0xff1E293B)),
                                                                                                   borderRadius:
                                                                                                   BorderRadius.circular(
                                                                                                     8.0,
                                                                                                   ),
                                                                                                   boxShadow: const [
                                                                                                     BoxShadow(
                                                                                                       color: Color(0xff475569),
                                                                                                       offset: Offset(
                                                                                                         0.0,
                                                                                                         2.0,
                                                                                                       ),
                                                                                                       blurRadius: 0.0,
                                                                                                       spreadRadius: 0.0,
                                                                                                     ), //BoxShadow
                                                                                                   ],
                                                                                                 ),
                                                                                             ),

                                                                                             Column(
                                                                                       crossAxisAlignment:
                                                                                       CrossAxisAlignment.start,
                                                                                       children: [
                                                                                         Container(
                                                                                             margin:
                                                                                             const EdgeInsets.only(
                                                                                                 top: 30.0,
                                                                                                 left: 26.0),
                                                                                             child: const Text(
                                                                                               "Work Folder ID:",
                                                                                               style: TextStyle(
                                                                                                   fontSize: 13.0,
                                                                                                   color: Color(
                                                                                                       0xff64748B),
                                                                                                   fontFamily: 'Inter',
                                                                                                   fontWeight:
                                                                                                   FontWeight
                                                                                                       .w500),
                                                                                             )),



                                                                                       ],
                                                                                     ),

                                                                                             TextFormField(
                                                                                               controller: _warkfolderId,
                                                                                               cursorColor: const Color(
                                                                                                   0xffFFFFFF),
                                                                                               style: const TextStyle(
                                                                                                   color: Color(
                                                                                                       0xffFFFFFF)),
                                                                                               textAlignVertical:
                                                                                               TextAlignVertical
                                                                                                   .bottom,
                                                                                               keyboardType:
                                                                                               TextInputType.text,
                                                                                               decoration:
                                                                                               InputDecoration(
                                                                                                   errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                                                                                   contentPadding:
                                                                                                   const EdgeInsets
                                                                                                       .only(
                                                                                                     bottom: 16.0,
                                                                                                     top: 57.0,
                                                                                                     right: 10,
                                                                                                     left: 26.0,
                                                                                                   ),
                                                                                                   border:
                                                                                                   InputBorder
                                                                                                       .none,
                                                                                                   hintText: response.data!.workFolderId,
                                                                                                   hintStyle: const TextStyle(
                                                                                                       fontSize:
                                                                                                       14.0,
                                                                                                       color: Color(
                                                                                                           0xffFFFFFF),
                                                                                                       fontFamily:
                                                                                                       'Inter',
                                                                                                       fontWeight:
                                                                                                       FontWeight
                                                                                                           .w500)),
                                                                                               autovalidateMode: _submitted
                                                                                                   ? AutovalidateMode.onUserInteraction
                                                                                                   : AutovalidateMode.disabled,
                                                                                               validator: (value) {
                                                                                                 //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                                                                                 if(value!.isEmpty){
                                                                                                   return 'Please enter';
                                                                                                 }
                                                                                                 return null;
                                                                                               },
                                                                                               // onChanged: (text) => setState(() => name_ = text),
                                                                                             ),


                                                                                           ],
                                                                                         ),

                                                                                         Row(
                                                                                           mainAxisAlignment:
                                                                                           MainAxisAlignment.start,
                                                                                           children: [

                                                                                             Expanded(
                                                                                               flex: 4,
                                                                                               child: Stack(
                                                                                                 children: [
                                                                                                   Container(
                                                                                                       width: MediaQuery.of(context)
                                                                                                           .size
                                                                                                           .width *
                                                                                                           0.10,
                                                                                                       margin: const EdgeInsets.only(
                                                                                                           top: 20.0, left: 10.0),
                                                                                                       height: 56.0,
                                                                                                       decoration: BoxDecoration(
                                                                                                         color:
                                                                                                         const Color(0xff334155),
                                                                                                         //border: Border.all(color:  const Color(0xff1E293B)),
                                                                                                         borderRadius:
                                                                                                         BorderRadius.circular(
                                                                                                           8.0,
                                                                                                         ),
                                                                                                         boxShadow: const [
                                                                                                           BoxShadow(
                                                                                                             color:
                                                                                                             Color(0xff475569),
                                                                                                             offset: Offset(
                                                                                                               0.0,
                                                                                                               2.0,
                                                                                                             ),
                                                                                                             blurRadius: 0.0,
                                                                                                             spreadRadius: 0.0,
                                                                                                           ), //BoxShadow
                                                                                                         ],
                                                                                                       ),
                                                                                                   ),
                                                                                                      Column(
                                                                                       crossAxisAlignment:
                                                                                       CrossAxisAlignment
                                                                                           .start,
                                                                                       children: [
                                                                                         Container(
                                                                                               margin:
                                                                                               const EdgeInsets
                                                                                                   .only(
                                                                                                   top: 30.0,
                                                                                                   left: 26.0),
                                                                                               child: const Text(
                                                                                                 "Budget",
                                                                                                 style: TextStyle(
                                                                                                     fontSize: 13.0,
                                                                                                     color: Color(
                                                                                                         0xff64748B),
                                                                                                     fontFamily:
                                                                                                     'Inter',
                                                                                                     fontWeight:
                                                                                                     FontWeight
                                                                                                         .w500),
                                                                                               )),

                                                                                       ],
                                                                                     ),
                                                                                                   TextFormField(
                                                                                                     controller: _budget,
                                                                                                     cursorColor:
                                                                                                     const Color(
                                                                                                         0xffFFFFFF),
                                                                                                     style: const TextStyle(
                                                                                                         color: Color(
                                                                                                             0xffFFFFFF)),
                                                                                                     textAlignVertical:
                                                                                                     TextAlignVertical
                                                                                                         .bottom,
                                                                                                     keyboardType:
                                                                                                     TextInputType
                                                                                                         .text,
                                                                                                     decoration:
                                                                                                     InputDecoration(
                                                                                                         errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                                                                                         contentPadding:
                                                                                                         const EdgeInsets
                                                                                                             .only(
                                                                                                           bottom:
                                                                                                           16.0,
                                                                                                           top: 57.0,
                                                                                                           right: 10,
                                                                                                           left: 26.0,
                                                                                                         ),
                                                                                                         border:
                                                                                                         InputBorder
                                                                                                             .none,
                                                                                                         hintText: response.data!.budget.toString(),
                                                                                                         hintStyle: const TextStyle(
                                                                                                             fontSize:
                                                                                                             14.0,
                                                                                                             color: Color(
                                                                                                                 0xffFFFFFF),
                                                                                                             fontFamily:
                                                                                                             'Inter',
                                                                                                             fontWeight:
                                                                                                             FontWeight
                                                                                                                 .w500)),
                                                                                                     autovalidateMode: _submitted
                                                                                                         ? AutovalidateMode.onUserInteraction
                                                                                                         : AutovalidateMode.disabled,
                                                                                                     validator: (value) {
                                                                                                       //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                                                                                       if(value!.isEmpty){
                                                                                                         return 'Please enter';
                                                                                                       }
                                                                                                       return null;
                                                                                                     },
                                                                                                     // onChanged: (text) => setState(() => name_ = text),
                                                                                                   ),
                                                                                                 ],
                                                                                               ),
                                                                                             ),


                                                                                             const SizedBox(
                                                                                               width: 16.0,
                                                                                             ),

                                                                                             Expanded(
                                                                                               flex: 2,
                                                                                               child:Container(
                                                                                                 width: MediaQuery.of(context)
                                                                                                     .size
                                                                                                     .width *
                                                                                                     0.08,
                                                                                                 margin: const EdgeInsets.only(
                                                                                                     top: 13.0),
                                                                                                 height: 56.0,
                                                                                                 decoration: BoxDecoration(
                                                                                                   color:
                                                                                                   const Color(0xff334155),
                                                                                                   //border: Border.all(color:  const Color(0xff1E293B)),
                                                                                                   borderRadius:
                                                                                                   BorderRadius.circular(
                                                                                                     8.0,
                                                                                                   ),
                                                                                                 ),
                                                                                                 child: Container(
                                                                                                     margin:
                                                                                                     const EdgeInsets.only(
                                                                                                         left: 13.0,
                                                                                                         right: 18.0),
                                                                                                     // padding: const EdgeInsets.all(2.0),
                                                                                                     child: StatefulBuilder(
                                                                                                       builder: (BuildContext context,
                                                                                                           StateSettersetState) {
                                                                                                         return DropdownButtonHideUnderline(
                                                                                                           child: DropdownButton(
                                                                                                             dropdownColor:
                                                                                                             ColorSelect.class_color,
                                                                                                             value: _curren,
                                                                                                             underline:
                                                                                                             Container(),
                                                                                                             hint: const Text(
                                                                                                               "€",
                                                                                                               style: TextStyle(
                                                                                                                   fontSize: 14.0,
                                                                                                                   color: Color(0xffFFFFFF),
                                                                                                                   fontFamily: 'Inter',
                                                                                                                   fontWeight: FontWeight.w500),
                                                                                                             ),
                                                                                                             isExpanded: true,
                                                                                                             icon: const Icon(                // Add this
                                                                                                               Icons.arrow_drop_down,  // Add this
                                                                                                               color: Color(0xff64748B),

                                                                                                               // Add this
                                                                                                             ),
                                                                                                             items:currencyName.map((items) {
                                                                                                               return DropdownMenuItem(
                                                                                                                 value: items['id'].toString(),
                                                                                                                 child: Text(
                                                                                                                   items['currency']['symbol'],
                                                                                                                   style: const TextStyle(
                                                                                                                       fontSize: 14.0,
                                                                                                                       color: Color(0xffFFFFFF),
                                                                                                                       fontFamily: 'Inter', fontWeight: FontWeight.w400),
                                                                                                                 ),
                                                                                                               );
                                                                                                             }).toList(),
                                                                                                             onChanged: (
                                                                                                                 newValue) {
                                                                                                               setState(() {
                                                                                                                 _curren = newValue;
                                                                                                               });
                                                                                                             },

                                                                                                           ),
                                                                                                         );
                                                                                                       },
                                                                                                     )),

                                                                                               ),
                                                                                             ),


                                                                                             const SizedBox(
                                                                                               width: 18.0,
                                                                                             ),

                                                                                            Expanded(
                                                                                              flex: 7,
                                                                                              child: Stack(
                                                                                                children: [
                                                                                                  Container(
                                                                                                      width: 235,
                                                                                                      margin:
                                                                                                      const EdgeInsets.only(
                                                                                                          top: 20.0,
                                                                                                          right: 10.0),
                                                                                                      height: 56.0,
                                                                                                      decoration: BoxDecoration(
                                                                                                        color: const Color(
                                                                                                            0xff334155),
                                                                                                        //border: Border.all(color:  const Color(0xff1E293B)),
                                                                                                        borderRadius:
                                                                                                        BorderRadius.circular(
                                                                                                          8.0,
                                                                                                        ),
                                                                                                        boxShadow: const [
                                                                                                          BoxShadow(
                                                                                                            color:
                                                                                                            Color(0xff475569),
                                                                                                            offset: Offset(
                                                                                                              0.0,
                                                                                                              2.0,
                                                                                                            ),
                                                                                                            blurRadius: 0.0,
                                                                                                            spreadRadius: 0.0,
                                                                                                          ), //BoxShadow
                                                                                                        ],
                                                                                                      ),
                                                                                                  ),

                                                                                                 Column(
                                                                                   crossAxisAlignment:
                                                                                   CrossAxisAlignment
                                                                                       .start,
                                                                                   children: [
                                                                                     Container(
                                                                                         margin:
                                                                                         const EdgeInsets
                                                                                               .only(
                                                                                               top: 30.0,
                                                                                               left: 26.0),
                                                                                         child: const Text(
                                                                                           "Estimated hours",
                                                                                           style: TextStyle(
                                                                                                 fontSize:
                                                                                                 13.0,
                                                                                                 color: Color(
                                                                                                     0xff64748B),
                                                                                                 fontFamily:
                                                                                                 'Inter',
                                                                                                 fontWeight:
                                                                                                 FontWeight
                                                                                                     .w500),
                                                                                         )),
                                                                                   
                                                                                   ],
                                                                                 ),

                                                                                                  TextFormField(
                                                                                                    controller: _estimatehours,
                                                                                                    cursorColor:
                                                                                                    const Color(
                                                                                                        0xffFFFFFF),
                                                                                                    style: const TextStyle(
                                                                                                        color: Color(
                                                                                                            0xffFFFFFF)),
                                                                                                    textAlignVertical:
                                                                                                    TextAlignVertical
                                                                                                        .bottom,
                                                                                                    keyboardType:
                                                                                                    TextInputType
                                                                                                        .text,
                                                                                                    decoration:
                                                                                                    InputDecoration(
                                                                                                        errorStyle: TextStyle(fontSize: 14, height: 0.20),
                                                                                                        contentPadding:
                                                                                                        const EdgeInsets
                                                                                                            .only(
                                                                                                          bottom:
                                                                                                          16.0,
                                                                                                          top: 57.0,
                                                                                                          right: 10,
                                                                                                          left:
                                                                                                          26.0,
                                                                                                        ),
                                                                                                        border:
                                                                                                        InputBorder
                                                                                                            .none,
                                                                                                        hintText: response.data!.estimationHours,
                                                                                                        hintStyle: const TextStyle(
                                                                                                            fontSize:
                                                                                                            14.0,
                                                                                                            color: Color(
                                                                                                                0xffFFFFFF),
                                                                                                            fontFamily:
                                                                                                            'Inter',
                                                                                                            fontWeight:
                                                                                                            FontWeight.w500)),
                                                                                                    autovalidateMode: _submitted
                                                                                                        ? AutovalidateMode.onUserInteraction
                                                                                                        : AutovalidateMode.disabled,
                                                                                                    validator: (value) {
                                                                                                      //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                                                                                      if(value!.isEmpty){
                                                                                                        return 'Please enter';
                                                                                                      }
                                                                                                      return null;
                                                                                                    },
                                                                                                    // onChanged: (text) => setState(() => name_ = text),
                                                                                                  ),
                                                                                                ],
                                                                                              ),
                                                                                            ),



                                                                                           ],
                                                                                         ),

                                                                                         Row(
                                                                                           mainAxisAlignment:
                                                                                           MainAxisAlignment.start,
                                                                                           children: [
                                                                                             Container(
                                                                                                 width:
                                                                                                    240,
                                                                                                 margin: const EdgeInsets.only(
                                                                                                     top: 20.0, left: 10.0),
                                                                                                 height: 56.0,
                                                                                                 decoration: BoxDecoration(
                                                                                                   color:
                                                                                                   const Color(0xff334155),
                                                                                                   //border: Border.all(color:  const Color(0xff1E293B)),
                                                                                                   borderRadius:
                                                                                                   BorderRadius.circular(
                                                                                                     8.0,
                                                                                                   ),
                                                                                                 ),
                                                                                                 child: Container(
                                                                                                     margin:
                                                                                                     const EdgeInsets.only(
                                                                                                         left: 16.0,
                                                                                                         right: 20.0),
                                                                                                     // padding: const EdgeInsets.all(2.0),
                                                                                                     child: StatefulBuilder(
                                                                                                       builder: (BuildContext context,
                                                                                                           StateSettersetState) {
                                                                                                         return DropdownButtonHideUnderline(
                                                                                                           child: DropdownButton(
                                                                                                             dropdownColor:
                                                                                                             ColorSelect.class_color,
                                                                                                             value: _status,
                                                                                                             underline:
                                                                                                             Container(),
                                                                                                             hint: const Text(
                                                                                                               "Select Status",
                                                                                                               style: TextStyle(
                                                                                                                   fontSize: 14.0,
                                                                                                                   color: Color(0xffFFFFFF),
                                                                                                                   fontFamily: 'Inter',
                                                                                                                   fontWeight: FontWeight.w500),
                                                                                                             ),
                                                                                                             isExpanded: true,
                                                                                                             icon: const Icon(                // Add this
                                                                                                               Icons.arrow_drop_down,  // Add this
                                                                                                               color: Color(0xff64748B),

                                                                                                               // Add this
                                                                                                             ),
                                                                                                             items: statusList.map((items) {
                                                                                                               return DropdownMenuItem(
                                                                                                                 value: items['id'].toString(),
                                                                                                                 child: Text(
                                                                                                                   items['title'],
                                                                                                                   style: const TextStyle(
                                                                                                                       fontSize:
                                                                                                                       14.0,
                                                                                                                       color: Color(
                                                                                                                           0xffFFFFFF),
                                                                                                                       fontFamily:
                                                                                                                       'Inter',
                                                                                                                       fontWeight:
                                                                                                                       FontWeight
                                                                                                                           .w500),
                                                                                                                 ),
                                                                                                               );
                                                                                                             }).toList(),
                                                                                                             onChanged: (
                                                                                                                 newValue) {
                                                                                                               setState(() {
                                                                                                                 _status = newValue;
                                                                                                               });
                                                                                                             },

                                                                                                           ),
                                                                                                         );
                                                                                                       },
                                                                                                     )),
                                                                                               ),

                                                                                             const SizedBox(
                                                                                               width: 12.0,
                                                                                             ),

                                                                                              Container(
                                                                                                   width:
                                                                                                   240.0,
                                                                                                   margin:
                                                                                                   const EdgeInsets.only(
                                                                                                       top: 20.0,
                                                                                                       right: 10.0),
                                                                                                   height: 56.0,
                                                                                                   decoration: BoxDecoration(
                                                                                                     color: const Color(
                                                                                                         0xff334155),
                                                                                                     //border: Border.all(color:  const Color(0xff1E293B)),
                                                                                                     borderRadius:
                                                                                                     BorderRadius.circular(
                                                                                                       8.0,
                                                                                                     ),
                                                                                                     boxShadow: const [
                                                                                                       BoxShadow(
                                                                                                         color:
                                                                                                         Color(0xff475569),
                                                                                                         offset: Offset(
                                                                                                           0.0,
                                                                                                           2.0,
                                                                                                         ),
                                                                                                         blurRadius: 0.0,
                                                                                                         spreadRadius: 0.0,
                                                                                                       ), //BoxShadow
                                                                                                     ],
                                                                                                   ),
                                                                                                   child: Row(
                                                                                                     mainAxisAlignment:
                                                                                                     MainAxisAlignment
                                                                                                         .start,
                                                                                                     // crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                     children: [
                                                                                                       GestureDetector(
                                                                                                         onTap: (){
                                                                                                           _selectDate(setState);
                                                                                                         },

                                                                                                         child: Container(

                                                                                                           margin:
                                                                                                           const EdgeInsets
                                                                                                               .only(
                                                                                                               left: 13.0),
                                                                                                           height: 22.0,
                                                                                                           width: 20.0,
                                                                                                           child: Image.asset(
                                                                                                               'images/date.png'),
                                                                                                         ),
                                                                                                       ),
                                                                                                       Column(
                                                                                                         crossAxisAlignment:
                                                                                                         CrossAxisAlignment
                                                                                                             .start,
                                                                                                         children: [
                                                                                                           Container(
                                                                                                               margin: const EdgeInsets
                                                                                                                   .only(
                                                                                                                   top: 10.0,
                                                                                                                   left: 20.0),
                                                                                                               child:
                                                                                                               const Text(
                                                                                                                 "Delivery Date",
                                                                                                                 style: TextStyle(
                                                                                                                     fontSize:
                                                                                                                     13.0,
                                                                                                                     color: Color(
                                                                                                                         0xff64748B),
                                                                                                                     fontFamily:
                                                                                                                     'Inter',
                                                                                                                     fontWeight:
                                                                                                                     FontWeight
                                                                                                                         .w500),
                                                                                                               )),
                                                                                                           GestureDetector(
                                                                                                             onTap: () async {
                                                                                                               _selectDate(setState);
                                                                                                             },
                                                                                                             child: Container(
                                                                                                                 margin: const EdgeInsets
                                                                                                                     .only(
                                                                                                                     top: 3.0,
                                                                                                                     left:
                                                                                                                     20.0),
                                                                                                                 child: Text(
                                                                                                                   '${selectedDate.day} / ${selectedDate.month} / ${selectedDate.year}',
                                                                                                                   style: const TextStyle(
                                                                                                                       fontSize:
                                                                                                                       14.0,
                                                                                                                       color: Color(
                                                                                                                           0xffFFFFFF),
                                                                                                                       fontFamily:
                                                                                                                       'Inter',
                                                                                                                       fontWeight:
                                                                                                                       FontWeight.w500),
                                                                                                                 )),
                                                                                                           ),
                                                                                                         ],
                                                                                                       ),
                                                                                                       const Spacer(),
                                                                                                       Container(
                                                                                                         margin:
                                                                                                         const EdgeInsets
                                                                                                             .only(
                                                                                                             top: 5.0,
                                                                                                             right: 10.0),
                                                                                                         height: 20.0,
                                                                                                         child: Padding(
                                                                                                             padding:
                                                                                                             const EdgeInsets
                                                                                                                 .all(4.0),
                                                                                                             child: SvgPicture
                                                                                                                 .asset(
                                                                                                                 'images/cross.svg')),
                                                                                                       ),
                                                                                                     ],
                                                                                                   )),

                                                                                           ],
                                                                                         ),

                                                                                         Expanded(
                                                                                           child: Row(
                                                                                             mainAxisAlignment:
                                                                                             MainAxisAlignment.end,
                                                                                             children: [
                                                                                               GestureDetector(
                                                                                                 onTap: (){
                                                                                                   Navigator.of(context).pop();
                                                                                                 },

                                                                                                 child: Container(
                                                                                                   width:
                                                                                                   97, //MediaQuery.of(context).size.width * 0.22,
                                                                                                   margin: const EdgeInsets.only(
                                                                                                       top: 15.0, bottom: 0.0),
                                                                                                   height: 40.0,
                                                                                                   decoration: BoxDecoration(
                                                                                                     color:
                                                                                                     const Color(0xff334155),
                                                                                                     //border: Border.all(color:  const Color(0xff1E293B)),
                                                                                                     borderRadius:
                                                                                                     BorderRadius.circular(
                                                                                                       40.0,
                                                                                                     ),
                                                                                                   ),

                                                                                                   child: const Align(
                                                                                                     alignment: Alignment.center,
                                                                                                     child: Text(
                                                                                                       "Cancel",
                                                                                                       style: TextStyle(
                                                                                                           fontSize: 14.0,
                                                                                                           color:
                                                                                                           ColorSelect.white_color,
                                                                                                           fontFamily: 'Inter',
                                                                                                           fontWeight:
                                                                                                           FontWeight.w700),
                                                                                                     ),
                                                                                                   ),
                                                                                                 ),
                                                                                               ),

                                                                                               const SizedBox(
                                                                                                 width: 16,
                                                                                               ),

                                                                                               GestureDetector(
                                                                                                 onTap: (){
                                                                                                   print("Hello i am a create project");
                                                                                                   final isValid = _formKey.currentState!.validate();
                                                                                                   setState(() => _submitted = true);
                                                                                                   if (!isValid) {

                                                                                                     return;
                                                                                                   }
                                                                                                   editProject();
                                                                                                   Navigator.push(
                                                                                                       context,
                                                                                                       MaterialPageRoute(builder: (context) =>
                                                                                                           MyHomePage(onSubmit: (String value) {  }, adOnSubmit: (String value) {  },)));
                                                                                                   // widget.onSubmit(_name);
                                                                                                   _formKey.currentState!.save();

                                                                                                 },
                                                                                                 child: Container(
                                                                                                   width: 97.0, //MediaQuery.of(context).size.width * 0.22,
                                                                                                   margin: const EdgeInsets.only(
                                                                                                     top: 15.0,bottom: 0.0,right: 10.0,),
                                                                                                   height: 40.0,
                                                                                                   decoration: BoxDecoration(
                                                                                                     color:
                                                                                                     const Color(0xff7DD3FC),
                                                                                                     //border: Border.all(color:  const Color(0xff1E293B)),
                                                                                                     borderRadius:
                                                                                                     BorderRadius.circular(
                                                                                                       40.0,
                                                                                                     ),
                                                                                                   ),
                                                                                                   child: const Align(
                                                                                                     alignment: Alignment.center,
                                                                                                     child: Text(
                                                                                                       "Edit",
                                                                                                       style: TextStyle(
                                                                                                           fontSize: 14.0,
                                                                                                           color:
                                                                                                           ColorSelect.black_color,
                                                                                                           fontFamily: 'Inter',
                                                                                                           fontWeight:
                                                                                                           FontWeight.w700),
                                                                                                     ),
                                                                                                   ),
                                                                                                 ),
                                                                                               ),



                                                                                             ],
                                                                                           ),
                                                                                         ),

                                                                                       ],
                                                                                     ),
                                                                                   ),
                                                                                 ),
                                                                               ),
                                                                             );
                                                                           });
                                                                     },
                                                                     child: Container(
                                                                       height: 20,
                                                                       width: 50,
                                                                       child: const Text("Edit", style: TextStyle(
                                                                           fontSize: 14,
                                                                           fontWeight:
                                                                           FontWeight.w500,
                                                                           fontFamily: 'Inter',
                                                                           color: ColorSelect.white_color),),
                                                                     ),
                                                                  ),
                                                               ),

                                                               PopupMenuItem(
                                                            value: 1,
                                                            child: GestureDetector(
                                                            onTap: (){
                                                            Navigator.pop(context);

                                                            showDialog(
                                                                context: context,
                                                                builder: (context) {
                                                                  return StatefulBuilder(
                                                                    builder: (context, setState) => AlertDialog(
                                                                      shape: RoundedRectangleBorder(
                                                                        borderRadius: BorderRadius.circular(28.0),
                                                                      ),
                                                                      backgroundColor:  ColorSelect.peoplelistbackgroundcolor,
                                                                      content: Container(
                                                                        height: 110.0,
                                                                        child:Column(
                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                          children: [
                                                                            Container(
                                                                              margin: const EdgeInsets.only(right: 20.0),
                                                                              child: const Text("Do you want to delete this project",style: TextStyle(
                                                                                  fontSize: 20,
                                                                                  fontWeight:
                                                                                  FontWeight.w700,
                                                                                  fontFamily: 'Inter',
                                                                                  color: ColorSelect.white_color),),
                                                                            ),

                                                                            Container(
                                                                              margin: EdgeInsets.only(top: 15.0),
                                                                              child: const Text("Once deleted,you will not find this person in project list ",style: TextStyle(
                                                                                  fontSize: 14,
                                                                                  fontWeight:
                                                                                  FontWeight.w400,
                                                                                  fontFamily: 'Inter',
                                                                                  color: ColorSelect.delete),),
                                                                            ),

                                                                            Expanded(
                                                                              child: Container(
                                                                                margin: const EdgeInsets.only(top: 30.0),
                                                                                child: Row(
                                                                                  children:  [
                                                                                    Spacer(),

                                                                                    GestureDetector(
                                                                                      onTap: (){
                                                                                        Navigator.pop(context);
                                                                                      },
                                                                                      child: Container(
                                                                                        margin: const EdgeInsets.only(right: 35.0),
                                                                                        child: const Text("Cancel",style: TextStyle(
                                                                                            fontSize: 14,
                                                                                            fontWeight:
                                                                                            FontWeight.w700,
                                                                                            fontFamily: 'Inter',
                                                                                            color: ColorSelect.delete_text),),
                                                                                      ),
                                                                                    ),

                                                                                    GestureDetector(
                                                                                      onTap: (){
                                                                                        Navigator.pop(context);
                                                                                      },
                                                                                      child: const Text("Delete",style: TextStyle(
                                                                                          fontSize: 14,
                                                                                          fontWeight:
                                                                                          FontWeight.w700,
                                                                                          fontFamily: 'Inter',
                                                                                          color: ColorSelect.delete_text),),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ),
                                                                            )
                                                                          ],
                                                                        ),
                                                                        //MediaQueryx.of(context).size.height * 0.85,
                                                                      ),
                                                                    ),
                                                                  );
                                                                });

                                                            },
                                                            child: const Text("Delete", style: TextStyle(
                                                            fontSize: 14,
                                                            fontWeight:
                                                            FontWeight.w500,
                                                            fontFamily: 'Inter',
                                                            color: ColorSelect.white_color),),
                                                            ),
                                                            ),
                                                            ],
                                                            elevation: 8.0,
                                                            ).then((value) {
                                                            if (value != null) print(value);
                                                            });

                                                         },
                                                         child: Container(
                                                            margin: const EdgeInsets.only(right: 10.0),
                                                            height: 30.0,
                                                            width: 30.0,
                                                            decoration: BoxDecoration(
                                                                border: Border.all(
                                                                   color: const Color(0xff334155),
                                                                ),
                                                                borderRadius: const BorderRadius.all(Radius.circular(40))
                                                            ),
                                                            child: Padding(
                                                               padding: const EdgeInsets.all(8.0),
                                                               child: SvgPicture.asset(
                                                                  "images/edit.svg",
                                                               ),
                                                            ),
                                                         ),
                                                      )
                                                   ],
                                                ),

                                                SizedBox(
                                                    height:30.0,
                                                    width:MediaQuery.of(context).size.height * 100.0,
                                                    child: const Divider(
                                                       color: Color(0xff94A3B8),
                                                       thickness: 0.2,
                                                    )),

                                                Row(
                                                   mainAxisAlignment: MainAxisAlignment.start,
                                                   children: [
                                                      SizedBox(
                                                            height: 32.0,
                                                            child: Padding(
                                                               padding: const EdgeInsets.only(left: 25.0),
                                                              child: ListView.builder(
                                                                 shrinkWrap: true,
                                                                 scrollDirection: Axis.horizontal,
                                                                 itemCount: 3,//response.data!.tags!.length,
                                                                 itemBuilder: (BuildContext context, int index) {
                                                                   // Tags tag=response.data!.tags![index];
                                                                    //var tagName=tag.name;

                                                                    return Container(
                                                                       height: 32.0,
                                                                       margin: const EdgeInsets.only(left: 5.0, top: 5.0),
                                                                       decoration: BoxDecoration(
                                                                          color: const Color(0xff334155),
                                                                          borderRadius: BorderRadius.circular(
                                                                             8.0,
                                                                          ),
                                                                       ),
                                                                       child:  const Align(
                                                                          alignment: Alignment.center,
                                                                          child: Padding(
                                                                             padding: EdgeInsets.all(5.0),
                                                                             child: Text(
                                                                                'Design',
                                                                                style: TextStyle(
                                                                                    color: ColorSelect.white_color,
                                                                                    fontSize: 11.0,
                                                                                    fontFamily: 'Inter',
                                                                                    fontWeight:
                                                                                    FontWeight.w500),
                                                                             ),
                                                                          ),
                                                                       ),
                                                                    );
                                                                 },
                                                              ),
                                                            ),
                                                         ),
                                                     
                                                      GestureDetector(
                                                        onTap: () async{
                                                          await showMenu(

                                                              context: context,
                                                              color: ColorSelect.class_color,
                                                              position:  new RelativeRect.fromLTRB(160.0, 170.0, 160.0, 100.0),
                                                          items: [

                                                          PopupMenuItem(
                                                          value: 1,
                                                          child: GestureDetector(
                                                          onTap: (){
                                                          Navigator.pop(context);
                                                          },
                                                          child: Container(
                                                          //height: 100,
                                                          width: 200,
                                                          child: Column(
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                             /* Container(
                                                                height: 32.0,
                                                                decoration: const BoxDecoration(
                                                                  color: Color(0xff1E293B),
                                                                  //border: Border.all(color:  const Color(0xff1E293B)),
                                                                ),
                                                                child: TextFormField(
                                                                  //autocorrect: false,
                                                                  // obscureText: !_showPassword,
                                                                  //controller: passwordController,
                                                                  cursorColor:
                                                                  const Color(0xffFFFFFF),
                                                                  style: const TextStyle(
                                                                      color:
                                                                      Color(0xffFFFFFF)),
                                                                  textAlignVertical:
                                                                  TextAlignVertical
                                                                      .bottom,
                                                                  keyboardType:
                                                                  TextInputType.none,
                                                                  decoration:
                                                                  const InputDecoration(
                                                                      contentPadding:
                                                                      EdgeInsets.only(
                                                                        bottom: 18.0,
                                                                        top: 10.0,
                                                                        right: 10,
                                                                        left: 15.0,
                                                                      ),

                                                                      border: InputBorder.none,
                                                                      hintText: 'Search',
                                                                      hintStyle: TextStyle(
                                                                          fontSize: 14.0,
                                                                          color: Color(
                                                                              0xffFFFFFF),
                                                                          fontFamily:
                                                                          'Inter',
                                                                          fontWeight:
                                                                          FontWeight
                                                                              .w500)),
                                                                  *//* autovalidateMode: _submitted
                                                                        ? AutovalidateMode.onUserInteraction
                                                                        : AutovalidateMode.disabled,
                                                                    validator: (value) {
                                                                      //  RegExp regex=RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                                                      if(value!.isEmpty){
                                                                        return 'Please enter Password';
                                                                      } else if(value.length < 5){
                                                                        return 'Minimum length 5';
                                                                      }
                                                                      return null;
                                                                    },
                                                                    onChanged: (text) => setState(() => _name = text),*//*

                                                                ),
                                                              ),*/

                                                              ListView.builder(
                                                                shrinkWrap: true,
                                                                scrollDirection: Axis.vertical,
                                                                itemCount: response.data!.tags!.length,
                                                                itemBuilder: (BuildContext context, int index) {
                                                                  Tags tag=response.data!.tags![index];
                                                                  var tagName=tag.name;
                                                                  return Text(
                                                                    '$tagName',
                                                                    style: const TextStyle(
                                                                        color: ColorSelect.white_color,
                                                                        fontSize: 11.0,
                                                                        fontFamily: 'Inter',
                                                                        fontWeight:
                                                                        FontWeight.w500),
                                                                  );
                                                                },
                                                              ),


                                                            ],
                                                          ),



                                                          ),
                                                          ),
                                                          ),

                                                          ],
                                                          elevation: 8.0,
                                                          ).then((value) {
                                                          if (value != null) print(value);
                                                          });
                                                        },
                                                        child: Container(
                                                            width: 35.0,
                                                            height:35.0,
                                                            margin: const EdgeInsets.only(
                                                                left: 15.0,),
                                                            decoration: const BoxDecoration(
                                                               color: Color(0xff334155),
                                                               shape: BoxShape.circle,
                                                            ),
                                                            child: Container(
                                                               child:Padding(
                                                                   padding: const EdgeInsets.all(10.0),
                                                                   child: SvgPicture.asset('images/tag_new.svg')),
                                                            )
                                                           //SvgPicture.asset('images/list.svg'),
                                                        ),
                                                      ),

                                                     Spacer(),
                                                     
                                                     Container(
                                                       child: const Text(
                                                         'Work folder',
                                                         style: TextStyle(
                                                             color: ColorSelect.cermany_color,
                                                             fontSize: 14.0,
                                                             fontFamily: 'Inter',
                                                             fontWeight:
                                                             FontWeight.w400),
                                                       ),
                                                     ),

                                                     Container(
                                                       margin: const EdgeInsets.only( left: 10.0,right: 35.0),
                                                       child: SvgPicture.asset(
                                                         'images/cermony.svg',
                                                       ),
                                                     ),

                                                     Container(
                                                       child: const Text(
                                                         'CRM',
                                                         style: TextStyle(
                                                             color: ColorSelect.cermany_color,
                                                             fontSize: 14.0,
                                                             fontFamily: 'Inter',
                                                             fontWeight:
                                                             FontWeight.w400),
                                                       ),
                                                     ),

                                                     Container(
                                                       margin: const EdgeInsets.only(left: 10.0,right: 16.0),
                                                       child: SvgPicture.asset(
                                                         'images/cermony.svg',
                                                       ),
                                                     ),
                                                   ],
                                                ),

                                                Container(
                                                   width: MediaQuery.of(context).size.width * 0.99,
                                                   margin: const EdgeInsets.only(left: 15.0, top: 16.0),
                                                   height:MediaQuery.of(context).size.height * 0.14,
                                                   decoration: BoxDecoration(
                                                      color: const Color(0xff1E293B),
                                                      border: Border.all(color:  const Color(0xff424D5F),width: 0.5),
                                                      borderRadius: BorderRadius.circular(
                                                         8.0,
                                                      ),
                                                   ),
                                                   child: TextFormField(
                                                     controller: _description,
                                                      cursorColor: const Color(0xffFFFFFF),
                                                      style: const TextStyle(color: Color(0xffFFFFFF)),
                                                      textAlignVertical: TextAlignVertical.bottom,
                                                      keyboardType: TextInputType.text,
                                                      decoration:  InputDecoration(

                                                          contentPadding: const EdgeInsets.only(
                                                             bottom: 13.0,
                                                             top: 14.0,
                                                             right: 10,
                                                             left: 14.0,
                                                          ),

                                                          border: InputBorder.none,
                                                          hintText: response!.data!.description,
                                                          hintStyle: const TextStyle(
                                                              fontSize: 14.0,
                                                              color: Color(0xffFFFFFF),
                                                              fontFamily: 'Inter',
                                                              fontWeight: FontWeight.w500)),

                                                      onChanged: (value) {
                                                        addDescriptionProject();
                                                      },
                                                   ),
                                                ),

                                               /* Container(
                                                   margin: const EdgeInsets.only(left: 30.0, top: 20.0),
                                                   child:  const Text(
                                                      "Potential roadblocks",
                                                      style: TextStyle(color: Color(0xffFFFFFF), fontSize: 16.0,
                                                          fontFamily: 'Inter', fontWeight: FontWeight.w500),
                                                   ),
                                                ),

                                                Container(
                                                   width: MediaQuery.of(context).size.width * 0.99,
                                                   margin: const EdgeInsets.only(left: 30.0, top: 12.0),
                                                   height: 40.0,
                                                   decoration: BoxDecoration(
                                                      color: const Color(0xff334155),
                                                      // border: Border.all(color: const Color(0xff1E293B)),
                                                      borderRadius: BorderRadius.circular(
                                                         12.0,
                                                      ),
                                                   ),

                                                   child: Row(
                                                      children: [
                                                         Container(
                                                            margin:  const EdgeInsets.only(
                                                                left: 15.0,
                                                                top: 0.0),
                                                            child: const Text(
                                                               "Occurrence",
                                                               style: TextStyle(
                                                                   color: Color(0xff94A3B8),
                                                                   fontSize: 14.0,
                                                                   fontFamily: 'Inter',
                                                                   fontWeight:
                                                                   FontWeight.w500),
                                                            ),
                                                         ),

                                                         const Spacer(),

                                                         Container(
                                                            margin:  const EdgeInsets.only(
                                                                right: 40.0,
                                                                top: 0.0),
                                                            child: const Text(
                                                               "Responsible",
                                                               style: TextStyle(
                                                                   color: Color(0xff94A3B8),
                                                                   fontSize: 14.0,
                                                                   fontFamily: 'Inter',
                                                                   fontWeight:
                                                                   FontWeight.w500),
                                                            ),
                                                         ),

                                                         Container(
                                                            margin:  const EdgeInsets.only(
                                                                left: 15.0,
                                                                right: 30.0),
                                                            child: const Text(
                                                               "Date created",
                                                               style: TextStyle(
                                                                   color: Color(0xff94A3B8),
                                                                   fontSize: 14.0,
                                                                   fontFamily: 'Inter',
                                                                   fontWeight:
                                                                   FontWeight.w500),
                                                            ),
                                                         ),
                                                      ],
                                                   ),
                                                ),

                                                Expanded(
                                                   flex: 1,
                                                   child: Padding(
                                                      padding: const EdgeInsets.only(top:3.0),
                                                      child: ListView.builder(
                                                         shrinkWrap: true,
                                                         scrollDirection: Axis.vertical,
                                                         itemCount: 3,
                                                         itemBuilder: (BuildContext context, int index) {

                                                            return Row(
                                                               children: [
                                                                  Container(
                                                                     margin: const EdgeInsets.only(left: 45.0,top: 8.0),
                                                                     height: 12.0,
                                                                     width: 12.0,
                                                                     decoration: const BoxDecoration(
                                                                         color: Color(0xffEF4444),
                                                                         borderRadius: BorderRadius.all(Radius.circular(20))
                                                                     ),

                                                                  ),

                                                                  Container(
                                                                     margin: const EdgeInsets.only(left: 16.0, top: 8.0),
                                                                     child:  const Text(
                                                                        "Technology not define yet",
                                                                        style: TextStyle(color: Color(0xffE2E8F0), fontSize: 14.0,
                                                                            fontFamily: 'Inter', fontWeight: FontWeight.w500),
                                                                     ),
                                                                  ),

                                                                  const Spacer(),

                                                                  Container(
                                                                     height:28.0,
                                                                     width:28.0,
                                                                     margin:  const EdgeInsets.only(
                                                                         right: 98.0,
                                                                         top: 8.0),
                                                                     decoration: BoxDecoration(
                                                                        color: const Color(0xff334155),
                                                                        border: Border.all(color:  const Color(0xff0F172A),width: 3.0),
                                                                        borderRadius: BorderRadius.circular(
                                                                           30.0,
                                                                        ),
                                                                     ),
                                                                     child:  const Align(
                                                                        alignment:Alignment.center,
                                                                        child: Text(
                                                                           "RC",
                                                                           style: TextStyle(
                                                                               color: Color(0xffFFFFFF),
                                                                               fontSize: 10.0,
                                                                               fontFamily: 'Inter',
                                                                               fontWeight:
                                                                               FontWeight.w500),
                                                                        ),
                                                                     ),
                                                                  ),

                                                                  Container(
                                                                     margin:  const EdgeInsets.only(
                                                                         top: 8.0,
                                                                         right: 50.0),
                                                                     child: const Text(
                                                                        "13 Jul",
                                                                        style: TextStyle(
                                                                            color: Color(0xff94A3B8),
                                                                            fontSize: 14.0,
                                                                            fontFamily: 'Inter',
                                                                            fontWeight:
                                                                            FontWeight.w500),
                                                                     ),
                                                                  ),
                                                               ],
                                                            );
                                                         },
                                                      ),
                                                   ),
                                                ),
*/
                                               SizedBox(height: 152,),

                                                SizedBox(
                                                    width:MediaQuery.of(context).size.height * 100.0,
                                                    child: const Divider(
                                                       color: Color(0xff94A3B8),
                                                       thickness: 0.2,
                                                    )),
                                             ],
                                          ),
                                       ),

                                       SizedBox(
                                           height: MediaQuery.of(context).size.height * 0.16,
                                           child: const VerticalDivider(
                                              color: Color(0xff94A3B8),
                                              thickness: 0.2,
                                           )),

                                       Expanded(
                                          flex:1,
                                          child:  Column(
                                             mainAxisAlignment: MainAxisAlignment.start,
                                             crossAxisAlignment: CrossAxisAlignment.start,
                                             mainAxisSize: MainAxisSize.min,
                                             children: [
                                                Row(
                                                   mainAxisAlignment: MainAxisAlignment.start,
                                                   children: [
                                                      Column(
                                                         children: [
                                                            Row(
                                                               children: [
                                                                  Column(
                                                                     crossAxisAlignment: CrossAxisAlignment.start,
                                                                     children: [
                                                                        Container(
                                                                           margin: const EdgeInsets.only(left: 20.0, top: 40.0),
                                                                           child:  const Text(
                                                                              "Start date",
                                                                              style: TextStyle(color: Color(0xff94A3B8), fontSize: 11.0,
                                                                                  fontFamily: 'Inter', fontWeight: FontWeight.w400),
                                                                           ),
                                                                        ),

                                                                        InkWell(
                                                                           onTap: (){
                                                                              _selectDate(setState);
                                                                           },
                                                                          child: Container(
                                                                             margin:  const EdgeInsets.only(left: 20.0, top: 6.0),
                                                                             child:   Text(
                                                                                "20 Dec 2022",
                                                                                style: const TextStyle(color: Color(0xffFFFFFF), fontSize: 14.0,
                                                                                    fontFamily: 'Inter', fontWeight: FontWeight.w400),
                                                                             ),
                                                                          ),
                                                                        ),
                                                                     ],
                                                                  ),

                                                                  Column(
                                                                     crossAxisAlignment: CrossAxisAlignment.start,
                                                                     children: [
                                                                        Container(
                                                                           margin: const EdgeInsets.only(left: 20.0, top: 40.0),
                                                                           child:  const Text(
                                                                              "Reminder date",
                                                                              style: TextStyle(color: Color(0xff94A3B8), fontSize: 11.0,
                                                                                  fontFamily: 'Inter', fontWeight: FontWeight.w400),
                                                                           ),
                                                                        ),

                                                                        InkWell(
                                                                           onTap: (){
                                                                              _selectDate(setState);
                                                                           },
                                                                          child: Container(
                                                                             margin: const EdgeInsets.only(left: 20.0, top: 6.0),
                                                                             child:   Text(
                                                                                "20 Dec 2022",
                                                                                style: const TextStyle(color: Color(0xffFFFFFF), fontSize: 14.0,
                                                                                    fontFamily: 'Inter', fontWeight: FontWeight.w400),
                                                                             ),
                                                                          ),
                                                                        ),
                                                                     ],
                                                                  ),

                                                                  Column(
                                                                     crossAxisAlignment: CrossAxisAlignment.start,
                                                                     children: [
                                                                        Container(
                                                                           margin: const EdgeInsets.only(left: 20.0, top: 40.0),
                                                                           child:  const Text(
                                                                              "Delivery date",
                                                                              style: TextStyle(color: Color(0xff94A3B8), fontSize: 11.0,
                                                                                  fontFamily: 'Inter', fontWeight: FontWeight.w400),
                                                                           ),
                                                                        ),

                                                                        InkWell(
                                                                           onTap: (){
                                                                              _selectDate(setState);
                                                                           },

                                                                          child: Container(
                                                                             margin: const EdgeInsets.only(left: 20.0, top: 6.0),
                                                                             child:   Text(
                                                                                "28 Dec 2022",
                                                                                style: const TextStyle(color: Color(0xffFFFFFF), fontSize: 14.0,
                                                                                    fontFamily: 'Inter', fontWeight: FontWeight.w400),
                                                                             ),
                                                                          ),
                                                                        ),
                                                                     ],
                                                                  ),

                                                                  Column(
                                                                     crossAxisAlignment: CrossAxisAlignment.start,
                                                                     children: [
                                                                        Container(
                                                                           margin: const EdgeInsets.only(left: 20.0, top: 40.0),
                                                                           child:  const Text(
                                                                              "Deadline date",
                                                                              style: TextStyle(color: Color(0xff94A3B8), fontSize: 11.0,
                                                                                  fontFamily: 'Inter', fontWeight: FontWeight.w400),
                                                                           ),
                                                                        ),

                                                                        InkWell(
                                                                           onTap: (){
                                                                              _selectDate(setState);
                                                                           },

                                                                          child: Container(
                                                                             margin: const EdgeInsets.only(left: 20.0, top: 6.0),
                                                                             child:   Text(
                                                                                "20 Dec 2022",
                                                                                style: const TextStyle(color: Color(0xffFFFFFF), fontSize: 14.0,
                                                                                    fontFamily: 'Inter', fontWeight: FontWeight.w400),
                                                                             ),
                                                                          ),
                                                                        ),
                                                                     ],
                                                                  ),

                                                                  Column(
                                                                     crossAxisAlignment: CrossAxisAlignment.start,
                                                                     children: [
                                                                        Container(
                                                                           margin: const EdgeInsets.only(left: 20.0, top: 40.0),
                                                                           child:  const Text(
                                                                              "Working days",
                                                                              style: TextStyle(color: Color(0xff94A3B8), fontSize: 11.0,
                                                                                  fontFamily: 'Inter', fontWeight: FontWeight.w400),
                                                                           ),
                                                                        ),

                                                                       Container(
                                                                         margin: const EdgeInsets.only(left: 20.0, top: 2.0),
                                                                         child:  const Text(
                                                                           "12",
                                                                           style: TextStyle(color: Color(0xffFFFFFF), fontSize: 14.0,
                                                                               fontFamily: 'Inter', fontWeight: FontWeight.w400),
                                                                         ),
                                                                       ),

                                                                      /*  InkWell(
                                                                           onTap: (){},

                                                                          child: Container(
                                                                            height: 18.0,
                                                                            margin: const EdgeInsets.only(left: 20.0, top: 6.0),
                                                                             child:    DropdownButtonHideUnderline(
                                                                               child: DropdownButton(
                                                                                 dropdownColor:
                                                                                 ColorSelect.class_color,
                                                                                 // Initial Value
                                                                                 value: dropdownvalue,
                                                                                 hint:  Text(
                                                                                   response!.data!.workingDays.toString(),
                                                                                   style: const TextStyle(
                                                                                       fontSize: 14.0,
                                                                                       color: Color(0xffFFFFFF),
                                                                                       fontFamily: 'Inter',
                                                                                       fontWeight:
                                                                                       FontWeight.w500),
                                                                                 ),

                                                                                 // Down Arrow Icon
                                                                                 icon: Visibility (visible:false, child: Icon(Icons.arrow_downward)),

                                                                                 // Array list of items
                                                                                 items: items.map((String items) {
                                                                                   return DropdownMenuItem(
                                                                                     value: items,
                                                                                     child: Text(items,style: const TextStyle(
                                                                                         fontSize: 14.0,
                                                                                         color:
                                                                                         Color(0xffFFFFFF),
                                                                                         fontFamily: 'Inter',
                                                                                         fontWeight:
                                                                                         FontWeight.w400),),
                                                                                   );
                                                                                 }).toList(),
                                                                                 // After selecting the desired option,it will
                                                                                 // change button value to selected value
                                                                                 onChanged: (String? newValue) {
                                                                                   setState(() {
                                                                                     dropdownvalue = newValue!;
                                                                                   });
                                                                                 },
                                                                               ),
                                                                             ),
                                                                          ),
                                                                        ),*/
                                                                     ],
                                                                  ),

                                                                  // const Spacer(),

                                                                 GestureDetector(
                                                                   onTap: (){
                                                                     Navigator.of(context).pop();
                                                                   },
                                                                   child: Container(
                                                                     margin: const EdgeInsets.only(top: 16.0,left:40.0),
                                                                     height: 28.0,
                                                                     width: 28.0,
                                                                     decoration: BoxDecoration(
                                                                         border: Border.all(
                                                                             color:  Color(0xff334155),width: 0.6
                                                                         ),
                                                                         borderRadius: const BorderRadius.all(Radius.circular(40))
                                                                     ),
                                                                     child: Padding(
                                                                       padding: const EdgeInsets.all(8.0),
                                                                       child: SvgPicture.asset(
                                                                         "images/cross.svg",
                                                                       ),
                                                                     ),
                                                                   ),
                                                                 ),
                                                               ],
                                                            ),
                                                         ],
                                                      ),
                                                   ],
                                                ),

                                                SizedBox(
                                                    height: 74.0,//MediaQuery.of(context).size.height * 0.10,
                                                    width: MediaQuery.of(context).size.width * 100.0,
                                                    child: const Divider(
                                                       color: Color(0xff94A3B8),
                                                       thickness: 0.2,
                                                    )),

                                                Column(
                                                   mainAxisAlignment: MainAxisAlignment.start,
                                                   children: [
                                                      Container(
                                                         // margin: const EdgeInsets.only(left: 20.0, top: 40.0),
                                                         height:MediaQuery.of(context).size.height * 0.39,
                                                         width:  MediaQuery.of(context).size.width * 0.99,
                                                         decoration: const BoxDecoration(
                                                            color: Color(0xff263143),
                                                            //border: Border.all(color: const Color(0xff0E7490)),
                                                         ),
                                                      ),
                                                   ],
                                                ),

                                                Expanded(
                                                   child: SizedBox(
                                                      //  height: 25.0,
                                                       width: MediaQuery.of(context).size.width * 90.0,
                                                       child: const Divider(
                                                          color: Color(0xff94A3B8),
                                                          thickness: 0.2,
                                                       )),
                                                ),

                                             ],
                                          ),
                                       ),

                                    ],
                                 ),
                              ),

                             /* Row(
                                 children: [

                                    Container(
                                       margin: const EdgeInsets.only(left: 30.0, top: 0.0),
                                       child:  const Text(
                                          "Timeline",
                                          style: TextStyle(color: Color(0xffFFFFFF), fontSize: 16.0,
                                              fontFamily: 'Inter', fontWeight: FontWeight.w700),
                                       ),
                                    ),

                                    const Spacer(),

                                    Row(
                                       children: [
                                          Container(
                                             margin: const EdgeInsets.only(right: 8.0, top: 0.0),
                                             child: SvgPicture.asset('images/plus.svg',color: const Color(0xff93C5FD),width: 10.0,height: 10.0,),
                                          ),

                                          Container(
                                             margin: const EdgeInsets.only(right: 45.0, top: 0.0),
                                             child:  const Text(
                                                "Request resources",
                                                style: TextStyle(color: Color(0xff93C5FD), fontSize: 12.0,
                                                    fontFamily: 'Inter', fontWeight: FontWeight.w700),
                                             ),
                                          ),
                                       ],
                                    ),

                                    Row(
                                       children: [
                                          Container(
                                             margin: const EdgeInsets.only(right: 8.0, top: 0.0),
                                             child: SvgPicture.asset('images/plus.svg',color: const Color(0xff93C5FD),width: 10.0,height: 10.0,),
                                          ),

                                          Container(
                                             margin: const EdgeInsets.only(right: 80.0, top: 0.0),
                                             child:  const Text(
                                                "New phase",
                                                style: TextStyle(color: Color(0xff93C5FD), fontSize: 12.0,
                                                    fontFamily: 'Inter', fontWeight: FontWeight.w700),
                                             ),
                                          ),


                                       ],
                                    ),
                                 ],
                              ),

                              Container(
                                 width: MediaQuery.of(context).size.width * 0.99,
                                 margin: const EdgeInsets.only(left: 30.0, top: 12.0,right: 30.0),
                                 height: 40,//MediaQuery.of(context).size.height * 0.07,
                                 decoration: BoxDecoration(
                                    color: const Color(0xff334155),
                                    // border: Border.all(color: const Color(0xff1E293B)),
                                    borderRadius: BorderRadius.circular(
                                       12.0,
                                    ),
                                 ),

                                 child: Row(
                                    children: [
                                       Container(
                                          margin:  const EdgeInsets.only(
                                              left: 15.0,
                                              top: 0.0),
                                          child: const Text(
                                             "Phase",
                                             style: TextStyle(
                                                 color: Color(0xff94A3B8),
                                                 fontSize: 14.0,
                                                 fontFamily: 'Inter',
                                                 fontWeight:
                                                 FontWeight.w500),
                                          ),
                                       ),

                                       const Spacer(),

                                       Container(
                                          margin:  const EdgeInsets.only(
                                              right: 40.0,
                                              top: 0.0),
                                          child: const Text(
                                             "From",
                                             style: TextStyle(
                                                 color: Color(0xff94A3B8),
                                                 fontSize: 14.0,
                                                 fontFamily: 'Inter',
                                                 fontWeight:
                                                 FontWeight.w500),
                                          ),
                                       ),

                                       Container(
                                          margin:  const EdgeInsets.only(
                                              left: 15.0,
                                              right: 50.0),
                                          child: const Text(
                                             "Till",
                                             style: TextStyle(
                                                 color: Color(0xff94A3B8),
                                                 fontSize: 14.0,
                                                 fontFamily: 'Inter',
                                                 fontWeight:
                                                 FontWeight.w500),
                                          ),
                                       ),
                                    ],
                                 ),
                              ),

                              Expanded(
                                 flex: 1,
                                 child: ListView.builder(
                                    shrinkWrap: true,
                                    scrollDirection: Axis.vertical,
                                    itemCount: response.data!.phase!.length,
                                    itemBuilder: (BuildContext context, int index) {
                                       Phase phase =  response.data!.phase![index];
                                       var title=phase.title;
                                       var  phaseType=phase.phaseType;
                                       String name = title!.substring(0,2);
                                       var date=phase.startDate;
                                       var endDate=phase.endDate;


                                       var inputDate = DateTime.parse(date!);
                                       var outputFormat = DateFormat('d MMM');
                                       var _date = outputFormat.format(inputDate);

                                       var _reminderdate = DateTime.parse(endDate!);
                                       var _remind = DateFormat('d MMM');
                                       var _endDate = _remind.format(_reminderdate);


                                       return Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                             Row(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [

                                                   Container(
                                                      height:25.0,
                                                      width:25.0,
                                                      margin:  const EdgeInsets.only(
                                                          left: 45.0,
                                                          top: 10.0),
                                                      decoration: BoxDecoration(
                                                         color: const Color(0xff334155),
                                                         borderRadius: BorderRadius.circular(
                                                            30.0,
                                                         ),
                                                      ),
                                                      child:   Align(
                                                         alignment:Alignment.center,
                                                         child: Text(
                                                            "$name",
                                                            style: const TextStyle(
                                                                color: Color(0xffFFFFFF),
                                                                fontSize: 10.0,
                                                                fontFamily: 'Inter',
                                                                fontWeight:
                                                                FontWeight.w500),
                                                         ),
                                                      ),
                                                   ),

                                                   Container(
                                                      margin: const EdgeInsets.only(left: 16.0, top: 12.0),
                                                      child:   Text(
                                                         "$phaseType", style: const TextStyle(color: Color(0xffE2E8F0), fontSize: 14.0,
                                                          fontFamily: 'Inter', fontWeight: FontWeight.w500),
                                                      ),
                                                   ),

                                                   const Spacer(),

                                                   Container(
                                                      margin:  const EdgeInsets.only(
                                                          top: 12.0,
                                                          right: 42.0),
                                                      child:  Text(
                                                         "$_date",
                                                         style: const TextStyle(
                                                             color: Color(0xff94A3B8),
                                                             fontSize: 14.0,
                                                             fontFamily: 'Inter',
                                                             fontWeight:
                                                             FontWeight.w500),
                                                      ),
                                                   ),

                                                   Container(
                                                      margin:  const EdgeInsets.only(
                                                          top: 12.0,
                                                          right: 52.0),
                                                      child:  Text(
                                                         "$_endDate",
                                                         style: const TextStyle(
                                                             color: Color(0xff94A3B8),
                                                             fontSize: 14.0,
                                                             fontFamily: 'Inter',
                                                             fontWeight:
                                                             FontWeight.w500),
                                                      ),
                                                   ),

                                                ],
                                             ),

                                             Container(
                                                 margin:  const EdgeInsets.only(
                                                     left: 30.0, right: 30.0,bottom: 0.0),
                                                 //  height: 74.0,//MediaQuery.of(context).size.height * 0.10,
                                                 width: MediaQuery.of(context).size.width * 100.0,
                                                 child: const Divider(
                                                    color: Color(0xff94A3B8),
                                                    thickness: 0.1,
                                                 )),
                                          ],
                                       );
                                    },
                                 ),
                              ),*/
                           ],
                        ),
                      ),
                   ),
                ),
             );
          });
   }









