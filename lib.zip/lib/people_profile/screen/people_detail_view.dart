// ignore_for_file: depend_on_referenced_packages
import 'dart:typed_data';
import 'package:autocomplete_textfield/autocomplete_textfield.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:zeus/utility/colors.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'package:image_picker_web/image_picker_web.dart';
import 'dart:convert';
import 'package:http_parser/http_parser.dart';
import '../../DemoContainer.dart';
import '../../navigation/department_model/department_model/department_responce.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../navigation/tag_model/tag_user.dart';
import '../../navigation/tag_model/tagresponse.dart';
import '../../navigator_tabs/idle/data/project_detail_data/ProjectDetailData.dart';
import '../../navigator_tabs/people_idle/model/model_class.dart';
import '../../utility/app_url.dart';
import '../../utility/constant.dart';

class ProfileDetail extends StatefulWidget {
  PeopleData list;

  ProfileDetail({
    Key? key,
    required this.list,
  });

  @override
  State<ProfileDetail> createState() => _ProfileDetailState(list);
}

class _ProfileDetailState extends State<ProfileDetail> {
  _ProfileDetailState(this.list);
   PeopleData list;

  AutoCompleteTextField? searchTextField;
  GlobalKey<AutoCompleteTextFieldState<Datum>> key = new GlobalKey();
  static List<Datum> users = <Datum>[];
  List _department = [];
  List _timeline = [];
  Future? _getTag;
  //var listdata=list.resource!.city;
  List _currencyName = [];
  List<int>? _selectedFile;
  Image? image;
  Uint8List? webImage;
  List<String> abc = ['Laravel'];
  bool imageavail = false;
  bool? _isSelected;
  bool loading = true;


  void getUsers() async {
    var response = await http.get(
      Uri.parse(AppUrl.tags_search),
      headers: {
        "Accept": "application/json",
        "Authorization": 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiYTZjMTM0Yjc0MGQ4MDVjZGI0NmY0MzZjYmMzMmIzMGRhYzg3NjNlNDk0MDAzNjc2Y2RmYTBiZWRlYmYyYjdmNGQwYWJlZTc4ZDcxNjI1MzEiLCJpYXQiOjE2NjM5NDM3MTMuNjc0NjU0LCJuYmYiOjE2NjM5NDM3MTMuNjc0NjU2LCJleHAiOjE2OTU0Nzk3MTMuNjcxNTAzLCJzdWIiOiIxIiwic2NvcGVzIjpbXX0.yOto3EvRI6AKKyl9ArQ7g9H3p1fmll_Ke_leVt7rOUOs9AM6UXA-Uu7-w8T5gdEJbtbmMnFDyE4axH9--_CwE2BEV6oSh_H9KXRSTO-7mVAAap0PSHknaiZnkmcqjSc1vWRPeTr_zQwY47-MLmboLWeKjgGOIfashPZi94KYjXdb3y61VfpcsLngYuu8z92bJWbm3qSyrtc4EhupDTem0d_zuLhypteplS9lWAbD0komTs9t5-VsYWw0x0PN12kyZmgfNYHDmW5YjcuO8cSg4xxj2Y1ZkojqnqOVYf0a_pC6jINRMUcetDOHfvulHC51loxsjsLofxYhc7jH6oZClNGOVFiAf4SR3sCb5ppiGGHXs4ThXDrpunG0JgmzlKlpZSSeK-RjYcw2pAInUWCDIGpE5qwa6xarMihNUNRnI0IdYALPVcvh-mwaVAG2JE4blP8h1aYmM46AcaegnoolKfOUXMYAh4nlduw0J4vscK0gvwBiUeSUK4llRaGFCX0jSXuf235vwHcxG5zigX9Ulb3IRlXA7JTusCgrJ7JCXFGpnD2a2Qu3Z0QMRcz1PfVBLPJN03KUi5aijCp5NwEjYmIIFev_ZatlMKhy1iLMeMPAfbQ9kRroQszXtAiSi9lpScoTkmy2zATcf4c3-nk5xi0BpDBb7f7tBPCmmGMbqTo'
      },
    );
    if (response.statusCode == 200) {
      print("sucess");
      var user = userFromJson(response.body);

      users = user.data!;
      // print('Users: ${users.length}');
      setState(() {
        loading = false;
      });
    } else {
      print("Error getting users.");
      // print(response.body);
    }
  }

  Future<void> getUpdatePeople() async {
    var request = http.MultipartRequest(
        'POST', Uri.parse('http://zeusapitst.crebos.online/api/v1/resource/update'));
    request.headers.addAll({
      "Content-Type": "application/json",
      "Authorization":
          'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiNzliY2M1NzFjNWFlNzMzNzkxMGY2ZWU0ZjU1YzBhYzA0ZDljNjdkNzhjZmJhZTNmYTAyOWFkOWIyZDY4NGIwOGZiMTFlMzIzNTM2YjFiNDQiLCJpYXQiOjE2NjIzMTY1MzIuNzczOTQ3LCJuYmYiOjE2NjIzMTY1MzIuNzczOTUxLCJleHAiOjE2OTM4NTI1MzIuNjU0NTE0LCJzdWIiOiIxMSIsInNjb3BlcyI6W119.1U8cAr8-DcLT3ZoqknGd3qSyjJZJiu89wxIgb8vsafP6z8rOOGkg7C9ZF3oDbZX4dwEeRlH9pCy_CKsUIL0_zizJHhbbDbn_IUXdhvJXizmBV2GE-W4XAzsExF-81_k02AY7nZ9y2u0ITzRKw-WyJe1zjvmQz5XJ9LEoz767o00u274XFzByGf42Xpd4S_RyRujJ9vGgqC72aIcgjQWr1KW2cJP7FRKlSAyml4NXfZqdjr8OT8ldgHHbBqBfVkGKZN3jpunLCl90VczGiQ-VewFcvdC264DI0uelBYHEW99oJeLmxTiBK5pl2pUAx-lULDdB-A68OvB0jsCOPtbbk0fjBSib0dMw9ckaZ7d69ug7976gIlJ_PYoL0_VehpYHtNVagaImGI7LWgE0RbJIg85SUshNZOi7NIdD3-VU1FFTVsnQfL9Pby8YNac9OeIbAY8n9s8AUFT8iVJKM1QRhqSvZIRx_5Gwdu1GELkoOo33cvwZEt0cpIloQvg8twk0KSvLw1XfEGmqJue1dGPk8NE1v_wtNwspptsUgqPejlFvXK-trJU9HBYpeNKXaBXSpdwWPnSLxzGF2m_isGeZtREwoYBCtQ2VNaKzFsdQHwRUguzQ84Td04VJKpi3j3lgT4TYoV24T5O47Dt1sNXfdTDsLPPWRn0bvR33B084WJc'
    });
    request.fields['name'] = _name.text.toString();
    request.fields['nickname'] = _nickName.text.toString();
    request.fields['email'] = _emailAddress.text.toString();
    request.fields['phone_number'] = _phoneNumber.text.toString();
    request.fields['password'] = 'Nirmaljeet@123';
    request.fields['bio'] = _bio.text.toString();
    request.fields['designation'] = _designation.text.toString();
    request.fields['department_id'] = _depat!;
    request.fields['associate'] = _association.text.toString();
    request.fields['salary'] = _salary.text.toString();
    request.fields['salary_currency'] = _salaryCurrency.text.toString();
    request.fields['availibilty_day'] = _availableDay.text.toString();
    request.fields['availibilty_time'] = _availableTime.text.toString();
    request.fields['country'] = _country.text.toString();
    request.fields['city'] = _enterCity.text.toString();
    request.fields['time_zone'] = _time!;
    // request.fields['skills'] =abc;

    if(!imageavail) {

    }else{
      _selectedFile = webImage;
      request.files.add(await http.MultipartFile.fromBytes(
          'image', _selectedFile!,
          contentType: MediaType('application', 'octet-stream'),
          filename: "file_up"));
    }

    for (int i = 0; i < list.resource!.skills!.length; i++) {
      request.fields['skills[$i]'] = '${list.resource!.skills![i]}';
    }


    var response = await request.send();
    var responseString = await response.stream.bytesToString();
    if (response.statusCode == 200) {
      final decodedMap = json.decode(responseString);

      print(decodedMap);

      final stringRes = JsonEncoder.withIndent('').convert(decodedMap);
      print(stringRes);
      print("yes");
    } else {
      print(responseString);
      print("failed");
    }
  }

  final TextEditingController _name = TextEditingController();
  final TextEditingController _nickName = TextEditingController();
  final TextEditingController _password = TextEditingController();
  final TextEditingController _bio = TextEditingController();
  final TextEditingController _designation = TextEditingController();
  final TextEditingController _association = TextEditingController();
  final TextEditingController _salary = TextEditingController();
  final TextEditingController _salaryCurrency = TextEditingController();
  final TextEditingController _availableDay = TextEditingController();
  final TextEditingController _availableTime = TextEditingController();
  final TextEditingController _search = TextEditingController();
  final TextEditingController _country = TextEditingController();
  final TextEditingController _enterCity = TextEditingController();
  final TextEditingController _phoneNumber = TextEditingController();
  final TextEditingController _emailAddress = TextEditingController();

  //Future? _getTag;
  String? _depat, _account, _custome, _curren, _status, _time, _tag;

  var name;
  int selectedIndex = 0;
  String dropdownvalue = 'Item 1';
  DateTime selectedDate = DateTime.now();
  var selectedItem = '';


  //Edit people popup
  void showAddPeople(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return StatefulBuilder(
            builder: (context, setState) => AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              contentPadding: EdgeInsets.zero,
              backgroundColor: const Color(0xff1E293B),
              content: SizedBox(
                width: MediaQuery.of(context).size.width * 0.99,
                height: MediaQuery.of(context).size.height * 0.99,
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        //mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Container(
                                height:
                                    MediaQuery.of(context).size.height * 0.11,
                                width: MediaQuery.of(context).size.width * 0.94,
                                decoration: const BoxDecoration(
                                  color: Color(0xff283345),
                                  //border: Border.all(color: const Color(0xff0E7490)),
                                  borderRadius: BorderRadius.only(
                                    topRight: Radius.circular(16.0),
                                    topLeft: Radius.circular(16.0),
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0x26000000),
                                      offset: Offset(
                                        0.0,
                                        1.0,
                                      ),
                                      blurRadius: 0.0,
                                      spreadRadius: 0.0,
                                    ), //BoxShadow
                                  ],
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: const EdgeInsets.only(
                                          left: 30.0, top: 10.0, bottom: 10.0),
                                      child: const Text(
                                        "Edit people",
                                        style: TextStyle(
                                            color: Color(0xffFFFFFF),
                                            fontSize: 18.0,
                                            fontFamily: 'Inter',
                                            fontWeight: FontWeight.w700),
                                      ),
                                    ),
                                    Expanded(
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Container(
                                            width:
                                                97.0, //MediaQuery.of(context).size.width * 0.22,
                                            margin: const EdgeInsets.only(
                                                top: 10.0, bottom: 10.0),
                                            height: 40.0,
                                            decoration: BoxDecoration(
                                              color: const Color(0xff334155),
                                              //border: Border.all(color:  const Color(0xff1E293B)),
                                              borderRadius:
                                                  BorderRadius.circular(
                                                40.0,
                                              ),
                                            ),
                                            child: GestureDetector(
                                              onTap: () {
                                                Navigator.of(context).pop();
                                              },
                                              child: const Align(
                                                alignment: Alignment.center,
                                                child: Text(
                                                  "Cancel",
                                                  style: TextStyle(
                                                      fontSize: 14.0,
                                                      color: Color(0xffFFFFFF),
                                                      fontFamily: 'Inter',
                                                      fontWeight:
                                                          FontWeight.w700),
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(
                                            width: 16,
                                          ),
                                          InkWell(
                                            onTap: () {
                                              getUpdatePeople();
                                              Navigator.pushNamed(
                                                  context, "/home");

                                              /* Navigator.push(
                                                   context,
                                                   MaterialPageRoute(builder: (context) =>
                                                       PeopleIdle()));*/
                                            },
                                            child: Container(
                                              width:
                                                  97, //MediaQuery.of(context).size.width * 0.22,
                                              margin: const EdgeInsets.only(
                                                  top: 10.0,
                                                  right: 20.0,
                                                  bottom: 10.0),
                                              height: 40.0,
                                              decoration: BoxDecoration(
                                                color: const Color(0xff7DD3FC),
                                                //border: Border.all(color:  const Color(0xff1E293B)),
                                                borderRadius:
                                                    BorderRadius.circular(
                                                  40.0,
                                                ),
                                              ),

                                              child: const Align(
                                                alignment: Alignment.center,
                                                child: Text(
                                                  "Save",
                                                  style: TextStyle(
                                                      fontSize: 14.0,
                                                      color: Color(0xff000000),
                                                      fontFamily: 'Inter',
                                                      fontWeight:
                                                          FontWeight.w700),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                )),
                          ),
                        ],
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 1,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                        width: 134.0,
                                        height: 134.0,
                                        margin: const EdgeInsets.only(
                                            left: 27.0, top: 28.0),
                                        decoration: BoxDecoration(
                                          color: const Color(0xff334155),
                                          borderRadius: BorderRadius.circular(
                                            110.0,
                                          ),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(110.0),
                                          child: imageavail
                                              ? Image.memory(
                                                  webImage!,
                                                  fit: BoxFit.fill,
                                                )
                                              : Image.network(
                                                    list.image!,
                                                    fit: BoxFit.fill,
                                                  ) ,
                                        )),
                                    InkWell(
                                      onTap: () async {
                                        final image = await ImagePickerWeb
                                            .getImageAsBytes();
                                        setState(() {
                                          webImage = image!;
                                          imageavail = true;
                                        });
                                      },
                                      child: Container(
                                        height: 35.0,
                                        width:
                                            MediaQuery.of(context).size.width *
                                                0.11,
                                        margin: const EdgeInsets.only(
                                            left: 48.0, top: 20.0),
                                        decoration: BoxDecoration(
                                          color: const Color(0xff334155),
                                          //border: Border.all(color: const Color(0xff0E7490)),
                                          borderRadius: BorderRadius.circular(
                                            40.0,
                                          ),
                                        ),
                                        child: Row(
                                          children: [
                                            Container(
                                              margin: const EdgeInsets.only(
                                                  left: 16.0),
                                              child: SvgPicture.asset(
                                                  'images/camera_pic.svg'),
                                            ),
                                            Container(
                                              margin: const EdgeInsets.only(
                                                  left: 11.0),
                                              child: const Text(
                                                "Upload new",
                                                style: TextStyle(
                                                    color: Color(0xffFFFFFF),
                                                    fontSize: 14.0,
                                                    fontFamily: 'Inter',
                                                    fontWeight:
                                                        FontWeight.w700),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Container(
                                  margin: const EdgeInsets.only(
                                      left: 30.0, top: 20.0),
                                  child: const Text(
                                    "About you",
                                    style: TextStyle(
                                        color: Color(0xffFFFFFF),
                                        fontSize: 18.0,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w700),
                                  ),
                                ),
                                const SizedBox(
                                  height: 8.0,
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.99,
                                  margin: const EdgeInsets.only(
                                      left: 30.0, right: 25.0),
                                  height: 56.0,
                                  decoration: BoxDecoration(
                                    color: const Color(0xff334155),
                                    //border: Border.all(color:  const Color(0xff1E293B)),
                                    borderRadius: BorderRadius.circular(
                                      8.0,
                                    ),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Color(0xff475569),
                                        offset: Offset(
                                          0.0,
                                          2.0,
                                        ),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                          margin: const EdgeInsets.only(
                                              top: 6.0, left: 16.0),
                                          child: const Text(
                                            "Name",
                                            style: TextStyle(
                                                fontSize: 11.0,
                                                color: Color(0xff64748B),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          )),
                                      Container(
                                        margin: const EdgeInsets.only(
                                            top: 5.0, left: 0.0),
                                        height: 20.0,
                                        child: TextFormField(
                                          controller: _name,
                                          cursorColor: const Color(0xffFFFFFF),
                                          style: const TextStyle(
                                              color: Color(0xffFFFFFF)),
                                          textAlignVertical:
                                              TextAlignVertical.bottom,
                                          keyboardType: TextInputType.text,
                                          decoration: InputDecoration(
                                              contentPadding:
                                                  const EdgeInsets.only(
                                                bottom: 16.0,
                                                top: 0.0,
                                                right: 10,
                                                left: 15.0,
                                              ),
                                              border: InputBorder.none,
                                              hintText: list.name.toString(),
                                              hintStyle: const TextStyle(
                                                  fontSize: 14.0,
                                                  color: Color(0xffFFFFFF),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w400)),
                                          onChanged: (value) {
                                            //filterSearchResults(value);
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.99,
                                  margin: const EdgeInsets.only(
                                      left: 30.0, top: 16.0, right: 25.0),
                                  height: 56.0,
                                  decoration: BoxDecoration(
                                    color: const Color(0xff334155),
                                    //border: Border.all(color:  const Color(0xff1E293B)),
                                    borderRadius: BorderRadius.circular(
                                      8.0,
                                    ),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Color(0xff475569),
                                        offset: Offset(
                                          0.0,
                                          2.0,
                                        ),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        height:16.0,
                                          margin: const EdgeInsets.only(
                                              top: 6.0, left: 16.0),
                                          child: const Text(
                                            "Nickname",
                                            style: TextStyle(
                                                fontSize: 11.0,
                                                color: Color(0xff64748B),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          )),
                                      Container(
                                        margin: const EdgeInsets.only(
                                            top: 5.0, left: 0.0),
                                        height: 20.0,
                                        child: TextFormField(
                                          controller: _nickName,
                                          cursorColor: const Color(0xffFFFFFF),
                                          style: const TextStyle(
                                              color: Color(0xffFFFFFF)),
                                          textAlignVertical:
                                              TextAlignVertical.bottom,
                                          keyboardType: TextInputType.text,
                                          decoration: InputDecoration(
                                              contentPadding:
                                                  const EdgeInsets.only(
                                                bottom: 16.0,
                                                top: 0.0,
                                                right: 10,
                                                left: 15.0,
                                              ),
                                              border: InputBorder.none,
                                              hintText: list!
                                                  .resource!.nickname!
                                                  .toString(),
                                              hintStyle: const TextStyle(
                                                  fontSize: 14.0,
                                                  color: Color(0xffFFFFFF),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w400)),
                                          onChanged: (value) {
                                            //filterSearchResults(value);
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.99,
                                  margin: const EdgeInsets.only(
                                      left: 30.0, top: 16.0, right: 25.0),
                                  height: 110.0,
                                  decoration: const BoxDecoration(
                                    color: Color(0xff334155),
                                    //border: Border.all(color:  const Color(0xff1E293B)),
                                    borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(8.0),
                                      topLeft: Radius.circular(8.0),
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0xff475569),
                                        offset: Offset(
                                          0.0,
                                          2.0,
                                        ),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                          margin: const EdgeInsets.only(
                                              top: 6.0, left: 16.0),
                                          child: const Text(
                                            "Your bio",
                                            style: TextStyle(
                                                fontSize: 11.0,
                                                color: Color(0xff64748B),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          )),
                                      Container(
                                        margin: const EdgeInsets.only(
                                            top: 5.0, left: 0.0),
                                        height: 20.0,
                                        child: TextFormField(
                                          controller: _bio,
                                          cursorColor: const Color(0xffFFFFFF),
                                          style: const TextStyle(
                                              color: Color(0xffFFFFFF)),
                                          textAlignVertical:
                                              TextAlignVertical.bottom,
                                          keyboardType: TextInputType.text,
                                          decoration: InputDecoration(
                                              contentPadding:
                                                  const EdgeInsets.only(
                                                bottom: 16.0,
                                                top: 0.0,
                                                right: 10,
                                                left: 15.0,
                                              ),
                                              border: InputBorder.none,
                                              hintText: list!.resource!.bio
                                                  .toString(),
                                              hintStyle: const TextStyle(
                                                  fontSize: 14.0,
                                                  color: Color(0xffFFFFFF),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w400)),
                                          onChanged: (value) {
                                            //filterSearchResults(value);
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),

                                Row(
                                  children: [
                                    Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.12,
                                      margin: const EdgeInsets.only(
                                          left: 30.0, top: 16.0),
                                      height: 56.0,
                                      decoration: BoxDecoration(
                                        color: const Color(0xff334155),
                                        //border: Border.all(color:  const Color(0xff1E293B)),
                                        borderRadius: BorderRadius.circular(
                                          8.0,
                                        ),
                                        boxShadow: const [
                                          BoxShadow(
                                            color: Color(0xff475569),
                                            offset: Offset(
                                              0.0,
                                              2.0,
                                            ),
                                            blurRadius: 0.0,
                                            spreadRadius: 0.0,
                                          ), //BoxShadow
                                        ],
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                              margin: const EdgeInsets.only(
                                                  top: 6.0, left: 16.0),
                                              child: const Text(
                                                "Designation",
                                                style: TextStyle(
                                                    fontSize: 11.0,
                                                    color: Color(0xff64748B),
                                                    fontFamily: 'Inter',
                                                    fontWeight:
                                                        FontWeight.w500),
                                              )),
                                          Container(
                                            margin: const EdgeInsets.only(
                                                top: 5.0, left: 0.0),
                                            height: 20.0,
                                            child: TextFormField(
                                              controller: _designation,
                                              cursorColor:
                                                  const Color(0xffFFFFFF),
                                              style: const TextStyle(
                                                  color: Color(0xffFFFFFF)),
                                              textAlignVertical:
                                                  TextAlignVertical.bottom,
                                              keyboardType: TextInputType.text,
                                              decoration: InputDecoration(
                                                  contentPadding:
                                                      const EdgeInsets.only(
                                                    bottom: 16.0,
                                                    top: 0.0,
                                                    right: 10,
                                                    left: 15.0,
                                                  ),
                                                  border: InputBorder.none,
                                                  hintText: list!
                                                      .resource!.designation!
                                                      .toString(),
                                                  hintStyle: const TextStyle(
                                                      fontSize: 14.0,
                                                      color: Color(0xffFFFFFF),
                                                      fontFamily: 'Inter',
                                                      fontWeight:
                                                          FontWeight.w500)),
                                              onChanged: (value) {
                                                //filterSearchResults(value);
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 8.0,
                                    ),
                                    Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.13,
                                      margin: const EdgeInsets.only(top: 16.0),
                                      height: 56.0,
                                      decoration: BoxDecoration(
                                        color: const Color(0xff334155),
                                        //border: Border.all(color:  const Color(0xff1E293B)),
                                        borderRadius: BorderRadius.circular(
                                          8.0,
                                        ),
                                      ),
                                      child:Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(

                                      margin:
                                      const EdgeInsets
                                          .only(
                                          top: 6.0,
                                          left: 16.0),
                                                child: const Text(
                                                  "Department",
                                                  style: TextStyle(
                                                      fontSize:
                                                      13.0,
                                                      color: Color(
                                                          0xff64748B),
                                                      fontFamily:
                                                      'Inter',
                                                      fontWeight:
                                                      FontWeight
                                                          .w500),
                                                )),

                                            Container(
                                              margin: const EdgeInsets.only(
                                                  left: 16.0,right: 16.0 ),
                                              height: 20.0,
                                                child:  Container(

                                                    child: StatefulBuilder(
                                                      builder: (BuildContext context,
                                                          StateSettersetState) {
                                                        return DropdownButtonHideUnderline(
                                                          child: DropdownButton(
                                                            dropdownColor:
                                                            ColorSelect.class_color,
                                                            value: _depat,
                                                            underline: Container(),
                                                            hint: Text(
                                                              list!.resource!.department!
                                                                  .name
                                                                  .toString(),
                                                              style: const TextStyle(
                                                                  fontSize: 14.0,
                                                                  color:
                                                                  Color(0xffFFFFFF),
                                                                  fontFamily: 'Inter',
                                                                  fontWeight:
                                                                  FontWeight.w500),
                                                            ),
                                                            isExpanded: true,
                                                            icon: SvgPicture.asset(
                                                              "images/drop_arrow.svg",
                                                              color:
                                                              const Color(0xff64748B),
                                                              width: 8.0,
                                                              height: 5.0,
                                                            ),
                                                            items:
                                                            _department.map((items) {
                                                              return DropdownMenuItem(
                                                                value: items['id']
                                                                    .toString(),
                                                                child: Text(
                                                                  items['name'],
                                                                  style: const TextStyle(
                                                                      fontSize: 14.0,
                                                                      color: Color(
                                                                          0xffFFFFFF),
                                                                      fontFamily: 'Inter',
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w400),
                                                                ),
                                                              );
                                                            }).toList(),
                                                            onChanged: (newValue) {
                                                              setState(() {
                                                                _depat = newValue;
                                                              });
                                                            },

                                                            /* selectedItemBuilder:
                                                                            (BuildContext
                                                                        context) {
                                                                          return _department.map(
                                                                                  (
                                                                                  value) {
                                                                                return Container(
                                                                                  margin: const EdgeInsets
                                                                                      .only(
                                                                                      top:
                                                                                      15.0),
                                                                                  child: Text(
                                                                                      _depat!,
                                                                                      style: const TextStyle(
                                                                                          color: Color(
                                                                                              0xffFFFFFF),
                                                                                          fontFamily:
                                                                                          'Inter',
                                                                                          fontWeight: FontWeight
                                                                                              .w400,
                                                                                          fontSize:
                                                                                          14.0)),
                                                                                );
                                                                              }).toList();
                                                                        },*/
                                                          ),
                                                        );
                                                      },
                                                    )),
                                            ),

                                          ],
                                      ),


                                    ),
                                  ],
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.99,
                                  margin: const EdgeInsets.only(
                                      left: 30.0, top: 16.0, right: 26.0),
                                  height: 56.0,
                                  decoration: BoxDecoration(
                                    color: const Color(0xff334155),
                                    //border: Border.all(color:  const Color(0xff1E293B)),
                                    borderRadius: BorderRadius.circular(
                                      8.0,
                                    ),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Color(0xff475569),
                                        offset: Offset(
                                          0.0,
                                          2.0,
                                        ),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                          margin: const EdgeInsets.only(
                                              top: 6.0, left: 16.0),
                                          child: const Text(
                                            "Associate with",
                                            style: TextStyle(
                                                fontSize: 11.0,
                                                color: Color(0xff64748B),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          )),
                                      Container(
                                        margin: const EdgeInsets.only(
                                            top: 5.0, left: 0.0),
                                        height: 20.0,
                                        child: TextFormField(
                                          controller: _association,
                                          cursorColor: const Color(0xffFFFFFF),
                                          style: const TextStyle(
                                              color: Color(0xffFFFFFF)),
                                          textAlignVertical:
                                              TextAlignVertical.bottom,
                                          keyboardType: TextInputType.text,
                                          decoration: InputDecoration(
                                              contentPadding:
                                                  const EdgeInsets.only(
                                                bottom: 16.0,
                                                top: 0.0,
                                                right: 10,
                                                left: 15.0,
                                              ),
                                              border: InputBorder.none,
                                              hintText: list!.name.toString(),
                                              hintStyle: const TextStyle(
                                                  fontSize: 14.0,
                                                  color: Color(0xffFFFFFF),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w500)),
                                          onChanged: (value) {
                                            //filterSearchResults(value);
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  margin: const EdgeInsets.only(
                                      left: 30.0, top: 16.0),
                                  child: const Text(
                                    "Salary",
                                    style: TextStyle(
                                        color: Color(0xffFFFFFF),
                                        fontSize: 18.0,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w700),
                                  ),
                                ),
                                Row(
                                  children: [
                                    Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.07,
                                      margin: const EdgeInsets.only(
                                          left: 30.0, top: 16.0, bottom: 16.0),
                                      height: 56.0,
                                      decoration: BoxDecoration(
                                        color: const Color(0xff334155),
                                        //border: Border.all(color:  const Color(0xff1E293B)),
                                        borderRadius: BorderRadius.circular(
                                          8.0,
                                        ),
                                      ),
                                      child: Container(
                                          margin: const EdgeInsets.only(
                                              left: 13.0, right: 18.0),
                                          // padding: const EdgeInsets.all(2.0),
                                          child: StatefulBuilder(
                                            builder: (BuildContext context,
                                                StateSettersetState) {
                                              return DropdownButtonHideUnderline(
                                                child: DropdownButton(
                                                  dropdownColor:
                                                      ColorSelect.class_color,
                                                  value: _curren,
                                                  underline: Container(),
                                                  hint: const Text(
                                                    "€",
                                                    style: TextStyle(
                                                        fontSize: 14.0,
                                                        color:
                                                            Color(0xffFFFFFF),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                            FontWeight.w500),
                                                  ),
                                                  isExpanded: true,
                                                  icon: SvgPicture.asset(
                                                    "images/drop_arrow.svg",
                                                    color:
                                                        const Color(0xff64748B),
                                                    width: 8.0,
                                                    height: 5.0,
                                                  ),
                                                  items: _currencyName
                                                      .map((items) {
                                                    return DropdownMenuItem(
                                                      value: items['id']
                                                          .toString(),
                                                      child: Text(
                                                        items['currency']
                                                            ['symbol'],
                                                        style: const TextStyle(
                                                            fontSize: 14.0,
                                                            color: Color(
                                                                0xffFFFFFF),
                                                            fontFamily: 'Inter',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w400),
                                                      ),
                                                    );
                                                  }).toList(),
                                                  onChanged: (newValue) {
                                                    setState(() {
                                                      _curren = newValue;
                                                    });
                                                  },
                                                ),
                                              );
                                            },
                                          )),
                                    ),
                                    const SizedBox(
                                      width: 8.0,
                                    ),
                                    Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.10,
                                      margin: const EdgeInsets.only(
                                          top: 16.0, bottom: 16.0),
                                      height: 56.0,
                                      decoration: BoxDecoration(
                                        color: const Color(0xff334155),
                                        //border: Border.all(color:  const Color(0xff1E293B)),
                                        borderRadius: BorderRadius.circular(
                                          8.0,
                                        ),
                                        boxShadow: const [
                                          BoxShadow(
                                            color: Color(0xff475569),
                                            offset: Offset(
                                              0.0,
                                              2.0,
                                            ),
                                            blurRadius: 0.0,
                                            spreadRadius: 0.0,
                                          ), //BoxShadow
                                        ],
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                              margin: const EdgeInsets.only(
                                                  top: 6.0, left: 16.0),
                                              child: const Text(
                                                "Monthly Salary",
                                                style: TextStyle(
                                                    fontSize: 11.0,
                                                    color: Color(0xff64748B),
                                                    fontFamily: 'Inter',
                                                    fontWeight:
                                                        FontWeight.w500),
                                              )),
                                          Container(
                                            margin: const EdgeInsets.only(
                                                top: 5.0, left: 0.0),
                                            height: 20.0,
                                            child: TextFormField(
                                              controller: _salary,
                                              cursorColor:
                                                  const Color(0xffFFFFFF),
                                              style: const TextStyle(
                                                  color: Color(0xffFFFFFF)),
                                              textAlignVertical:
                                                  TextAlignVertical.bottom,
                                              keyboardType: TextInputType.text,
                                              decoration: InputDecoration(
                                                  contentPadding:
                                                      const EdgeInsets.only(
                                                    bottom: 16.0,
                                                    top: 0.0,
                                                    right: 10,
                                                    left: 15.0,
                                                  ),
                                                  border: InputBorder.none,
                                                  hintText: list!
                                                      .resource!.salary!
                                                      .toString(),
                                                  hintStyle: const TextStyle(
                                                      fontSize: 14.0,
                                                      color: Color(0xffFFFFFF),
                                                      fontFamily: 'Inter',
                                                      fontWeight:
                                                          FontWeight.w500)),
                                              onChanged: (value) {
                                                //filterSearchResults(value);
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),

                          Container(
                              height: MediaQuery.of(context).size.height * 0.99,
                              child: const VerticalDivider(
                                color: Color(0xff94A3B8),
                                thickness: 0.2,
                              )),
                          Expanded(
                            flex: 1,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: const EdgeInsets.only(
                                      left: 30.0, top: 27.0),
                                  child: const Text(
                                    "Availabilty",
                                    style: TextStyle(
                                        color: Color(0xffFFFFFF),
                                        fontSize: 18.0,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w700),
                                  ),
                                ),
                                const SizedBox(
                                  height: 8.0,
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.26,
                                  margin: const EdgeInsets.only(left: 30.0),
                                  height: 56.0,
                                  decoration: BoxDecoration(
                                    color: const Color(0xff334155),
                                    //border: Border.all(color:  const Color(0xff1E293B)),
                                    borderRadius: BorderRadius.circular(
                                      8.0,
                                    ),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Color(0xff475569),
                                        offset: Offset(
                                          0.0,
                                          2.0,
                                        ),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                          margin: const EdgeInsets.only(
                                              top: 6.0, left: 16.0),
                                          child: const Text(
                                            "Select days",
                                            style: TextStyle(
                                                fontSize: 11.0,
                                                color: Color(0xff64748B),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          )),
                                      Container(
                                        margin: const EdgeInsets.only(
                                            top: 5.0, left: 0.0),
                                        height: 20.0,
                                        child: TextFormField(
                                          controller: _availableDay,
                                          cursorColor: const Color(0xffFFFFFF),
                                          style: const TextStyle(
                                              color: Color(0xffFFFFFF)),
                                          textAlignVertical:
                                              TextAlignVertical.bottom,
                                          keyboardType: TextInputType.text,
                                          decoration: InputDecoration(
                                              contentPadding:
                                                  const EdgeInsets.only(
                                                bottom: 16.0,
                                                top: 0.0,
                                                right: 10,
                                                left: 15.0,
                                              ),
                                              border: InputBorder.none,
                                              hintText: list!
                                                  .resource!.availibiltyDay!
                                                  .toString(),
                                              hintStyle: const TextStyle(
                                                  fontSize: 14.0,
                                                  color: Color(0xffFFFFFF),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w500)),
                                          onChanged: (value) {
                                            //filterSearchResults(value);
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.26,
                                  margin: const EdgeInsets.only(
                                      left: 30.0, top: 16.0),
                                  height: 56.0,
                                  decoration: BoxDecoration(
                                    color: const Color(0xff334155),
                                    //border: Border.all(color:  const Color(0xff1E293B)),
                                    borderRadius: BorderRadius.circular(
                                      8.0,
                                    ),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Color(0xff475569),
                                        offset: Offset(
                                          0.0,
                                          2.0,
                                        ),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                          margin: const EdgeInsets.only(
                                              top: 6.0, left: 16.0),
                                          child: const Text(
                                            "Select time",
                                            style: TextStyle(
                                                fontSize: 11.0,
                                                color: Color(0xff64748B),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          )),
                                      Container(
                                        margin: const EdgeInsets.only(
                                            top: 5.0, left: 0.0),
                                        height: 20.0,
                                        child: TextFormField(
                                          controller: _availableTime,
                                          cursorColor: const Color(0xffFFFFFF),
                                          style: const TextStyle(
                                              color: Color(0xffFFFFFF)),
                                          textAlignVertical:
                                              TextAlignVertical.bottom,
                                          keyboardType: TextInputType.text,
                                          decoration: InputDecoration(
                                              contentPadding:
                                                  const EdgeInsets.only(
                                                bottom: 16.0,
                                                top: 0.0,
                                                right: 10,
                                                left: 15.0,
                                              ),
                                              border: InputBorder.none,
                                              hintText: list!
                                                  .resource!.availibiltyTime
                                                  .toString(),
                                              hintStyle: const TextStyle(
                                                  fontSize: 14.0,
                                                  color: Color(0xffFFFFFF),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w500)),
                                          onChanged: (value) {
                                            //filterSearchResults(value);
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(
                                  height: 25.0,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      margin: const EdgeInsets.only(
                                          left: 30.0, top: 27.0),
                                      child: const Text(
                                        "Skills",
                                        style: TextStyle(
                                            color: Color(0xffFFFFFF),
                                            fontSize: 14.0,
                                            fontFamily: 'Inter',
                                            fontWeight: FontWeight.w700),
                                      ),
                                    ),
                                    Container(
                                        width: 40.0,
                                        height: 40.0,
                                        margin: const EdgeInsets.only(
                                            right: 20.0, top: 25.0),
                                        decoration: const BoxDecoration(
                                          color: Color(0xff334155),
                                          shape: BoxShape.circle,
                                        ),
                                        child: Container(
                                          child: Padding(
                                              padding:
                                                  const EdgeInsets.all(12.0),
                                              child: SvgPicture.asset(
                                                  'images/tag_new.svg')),
                                        )
                                        //SvgPicture.asset('images/list.svg'),
                                        ),
                                  ],
                                ),
                                Container(
                                  padding: EdgeInsets.only(left: 5, right: 5),
                                  width:
                                      MediaQuery.of(context).size.width * 0.26,
                                  margin: const EdgeInsets.only(
                                      left: 30.0, top: 16.0),
                                  height: 50.0,
                                  decoration: BoxDecoration(
                                    color: const Color(0xff334155),
                                    //border: Border.all(color:  const Color(0xff1E293B)),
                                    borderRadius: BorderRadius.circular(
                                      42.0,
                                    ),

                                  ),
                                  child: Column(
                                    children: [
                                      loading
                                          ? CircularProgressIndicator()
                                          : searchTextField =
                                              AutoCompleteTextField<Datum>(
                                              // controller: input_controller,
                                              //   suggestions: input_list,
                                              clearOnSubmit: false,
                                              key: key,

                                              decoration: InputDecoration(
                                                  contentPadding: EdgeInsets.only(top: 16.0),
                                                prefixIcon: Padding(
                                                  padding: EdgeInsets.only(top: 4.0),
                                                    child: Icon(Icons.search,color: Color(0xff64748B),)),
                                                hintText: 'Search', hintStyle: TextStyle(fontSize: 14.0, color: Color(0xff64748B),fontFamily: 'Inter', fontWeight: FontWeight.w400),
                                                border: InputBorder.none,
                                              ),

                                              suggestions: users,
                                              keyboardType: TextInputType.text,

                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 14.0),

                                              itemFilter: (item, query) {
                                                return item!.title!
                                                    .toLowerCase()
                                                    .startsWith(
                                                        query.toLowerCase());
                                              },
                                              itemSorter: (a, b) {
                                                return a.title!
                                                    .compareTo(b!.title!);
                                              },
                                              itemSubmitted: (item) {
                                                setState(() {
                                                  searchTextField!
                                                      .textField!
                                                      .controller!
                                                      .text = item!.title!;
                                                });
                                              },
                                              itemBuilder: (context, item) {
                                                // ui for the autocompelete row
                                                return row(item);
                                              },
                                            )
                                    ],
                                  ),
                                ),

                                /*  SizedBox(
                                  height: 100,
                                  child: ListView.builder(
                                      itemBuilder: (context,index){
                                        return Text(_addtag[index]['title']);},
                                      padding: const EdgeInsets.all(12.0),
                                      itemCount: _addtag.length
                                    ),
                                ),
*/

                                /* SizedBox(
                                  height: 55.0,
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 25.0, top: 20.0),
                                    child: FutureBuilder(
                                        future: _getTag,
                                        builder: (context, snapshot) {
                                          if (snapshot.connectionState ==
                                              ConnectionState.waiting) {
                                            return const Center(
                                                child: CircularProgressIndicator());
                                          } else {
                                            return Consumer<TagDetail?>(
                                                builder: (context, data, _) {
                                                 // listdata= data!.tagResponse!.data!.length;
                                                  return ListView.builder(
                                                    scrollDirection:
                                                    Axis.horizontal,
                                                    itemCount: data!.tagResponse!.data!.length,
                                                    itemBuilder: (context, index) {
                                                      TagData tag = data!.tagResponse!.data![index];
                                                      var _tag = tag.name;
                                                      return Container(
                                                        margin: const EdgeInsets.only(
                                                            left: 6.0),
                                                        child: InputChip(
                                                          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
                                                          deleteIcon: const Icon(Icons.close,color: Colors.white,size: 20,),
                                                          backgroundColor:
                                                          const Color(0xff334155),
                                                          visualDensity: VisualDensity.compact,
                                                          materialTapTargetSize:
                                                          MaterialTapTargetSize.shrinkWrap,
                                                          label: Text(_tag!,
                                                            style: TextStyle(color: Colors.white),
                                                          ),
                                                          selected: _isSelected!,
                                                          onSelected:
                                                              (bool selected) {
                                                            setState(() {
                                                              _isSelected =
                                                                  selected;
                                                            });
                                                          },
                                                          onDeleted: () {
                                                            setState(() {
                                                             // listdata.removeAt(index);
                                                            });
                                                          },
                                                        ),
                                                      );
                                                    },
                                                  );
                                                });
                                          }
                                        }),
                                  ),
                                ),*/

                                SizedBox(
                                  height: 55,
                                  child: Padding(
                                    padding: EdgeInsets.only(left: 28.0),
                                    child: ListView.builder(

                                      scrollDirection: Axis.horizontal,
                                      itemCount:list.resource!.skills!.length,
                                      itemBuilder: (context, index) {
                                        Skills _skills =
                                            list.resource!.skills![index];
                                        var tag = _skills.title;
                                        return Container(
                                          height: 32.0,
                                          margin:
                                              const EdgeInsets.only(left: 12.0),
                                          child: InputChip(
                                            shape: const RoundedRectangleBorder(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(8))),
                                            deleteIcon: const Icon(
                                              Icons.close,
                                              color: Colors.white,
                                              size: 20,
                                            ),
                                            backgroundColor:
                                                const Color(0xff334155),
                                            visualDensity: VisualDensity.compact,
                                            materialTapTargetSize:
                                                MaterialTapTargetSize.shrinkWrap,
                                            label: Text(
                                              tag!,
                                              style:
                                                  TextStyle(color: Colors.white),
                                            ),
                                            selected: _isSelected!,
                                            onSelected: (bool selected) {
                                              setState(() {
                                                _isSelected = selected;
                                              });
                                            },
                                            onDeleted: () {
                                              setState(() {
                                                list.resource!.skills!.removeAt(index);
                                              });
                                            },
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),

                          Container(
                              height: MediaQuery.of(context).size.height * 0.99,
                              child: const VerticalDivider(
                                color: Color(0xff94A3B8),
                                thickness: 0.2,
                              )),
                          Expanded(
                            flex: 1,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: const EdgeInsets.only(
                                      left: 30.0, top: 27.0),
                                  child: const Text(
                                    "Contact info",
                                    style: TextStyle(
                                        color: Color(0xffFFFFFF),
                                        fontSize: 18.0,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w700),
                                  ),
                                ),
                                const SizedBox(
                                  height: 8.0,
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.26,
                                  margin: const EdgeInsets.only(left: 30.0),
                                  height: 56.0,
                                  decoration: BoxDecoration(
                                    color: const Color(0xff334155),
                                    //border: Border.all(color:  const Color(0xff1E293B)),
                                    borderRadius: BorderRadius.circular(
                                      8.0,
                                    ),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Color(0xff475569),
                                        offset: Offset(
                                          0.0,
                                          2.0,
                                        ),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                          margin: const EdgeInsets.only(
                                              top: 6.0, left: 16.0),
                                          child: const Text(
                                            "Country",
                                            style: TextStyle(
                                                fontSize: 11.0,
                                                color: Color(0xff64748B),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          )),
                                      Container(
                                        margin: const EdgeInsets.only(
                                            top: 5.0, left: 0.0),
                                        height: 20.0,
                                        child: TextFormField(
                                          controller: _country,
                                          cursorColor: const Color(0xffFFFFFF),
                                          style: const TextStyle(
                                              color: Color(0xffFFFFFF)),
                                          textAlignVertical:
                                              TextAlignVertical.bottom,
                                          keyboardType: TextInputType.text,
                                          decoration: InputDecoration(
                                              contentPadding:
                                                  const EdgeInsets.only(
                                                bottom: 16.0,
                                                top: 0.0,
                                                right: 10,
                                                left: 15.0,
                                              ),
                                              border: InputBorder.none,
                                              hintText: list.resource!.country!
                                                  .toString(),
                                              hintStyle: const TextStyle(
                                                  fontSize: 14.0,
                                                  color: Color(0xffFFFFFF),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w500)),
                                          onChanged: (value) {
                                            //filterSearchResults(value);
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.26,
                                  margin: const EdgeInsets.only(
                                      left: 30.0, top: 16.0),
                                  height: 56.0,
                                  decoration: BoxDecoration(
                                    color: const Color(0xff334155),
                                    //border: Border.all(color:  const Color(0xff1E293B)),
                                    borderRadius: BorderRadius.circular(
                                      8.0,
                                    ),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Color(0xff475569),
                                        offset: Offset(
                                          0.0,
                                          2.0,
                                        ),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                          margin: const EdgeInsets.only(
                                              top: 6.0, left: 16.0),
                                          child: const Text(
                                            "City",
                                            style: TextStyle(
                                                fontSize: 11.0,
                                                color: Color(0xff64748B),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          )),
                                      Container(
                                        margin: const EdgeInsets.only(
                                            top: 5.0, left: 0.0),
                                        height: 20.0,
                                        child: TextFormField(
                                          controller: _enterCity,
                                          cursorColor: const Color(0xffFFFFFF),
                                          style: const TextStyle(
                                              color: Color(0xffFFFFFF)),
                                          textAlignVertical:
                                              TextAlignVertical.bottom,
                                          keyboardType: TextInputType.text,
                                          decoration: InputDecoration(
                                              contentPadding:
                                                  const EdgeInsets.only(
                                                bottom: 16.0,
                                                top: 0.0,
                                                right: 10,
                                                left: 15.0,
                                              ),
                                              border: InputBorder.none,
                                              hintText: list!.resource!.city!
                                                  .toString(),
                                              hintStyle: const TextStyle(
                                                  fontSize: 14.0,
                                                  color: Color(0xffFFFFFF),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w500)),
                                          onChanged: (value) {
                                            //filterSearchResults(value);
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.26,
                                  margin: const EdgeInsets.only(
                                      left: 30.0, top: 16.0),
                                  height: 56.0,
                                  decoration: BoxDecoration(
                                    color: const Color(0xff334155),
                                    //border: Border.all(color:  const Color(0xff1E293B)),
                                    borderRadius: BorderRadius.circular(
                                      8.0,
                                    ),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Color(0xff475569),
                                        offset: Offset(
                                          0.0,
                                          2.0,
                                        ),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                          margin: const EdgeInsets.only(
                                              top: 6.0, left: 16.0),
                                          child: const Text(
                                            "Phone number",
                                            style: TextStyle(
                                                fontSize: 11.0,
                                                color: Color(0xff64748B),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          )),
                                      Container(
                                        margin: const EdgeInsets.only(
                                            top: 5.0, left: 0.0),
                                        height: 20.0,
                                        child: TextFormField(
                                          controller: _phoneNumber,
                                          cursorColor: const Color(0xffFFFFFF),
                                          style: const TextStyle(
                                              color: Color(0xffFFFFFF)),
                                          textAlignVertical:
                                              TextAlignVertical.bottom,
                                          keyboardType: TextInputType.text,
                                          decoration: InputDecoration(
                                              contentPadding:
                                                  const EdgeInsets.only(
                                                bottom: 16.0,
                                                top: 0.0,
                                                right: 10,
                                                left: 15.0,
                                              ),
                                              border: InputBorder.none,
                                              hintText:
                                                  list.phoneNumber!.toString(),
                                              hintStyle: const TextStyle(
                                                  fontSize: 14.0,
                                                  color: Color(0xffFFFFFF),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w500)),
                                          onChanged: (value) {
                                            //filterSearchResults(value);
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.26,
                                  margin: const EdgeInsets.only(
                                      left: 30.0, top: 16.0),
                                  height: 56.0,
                                  decoration: BoxDecoration(
                                    color: const Color(0xff334155),
                                    //border: Border.all(color:  const Color(0xff1E293B)),
                                    borderRadius: BorderRadius.circular(
                                      8.0,
                                    ),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: Color(0xff475569),
                                        offset: Offset(
                                          0.0,
                                          2.0,
                                        ),
                                        blurRadius: 0.0,
                                        spreadRadius: 0.0,
                                      ), //BoxShadow
                                    ],
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                          margin: const EdgeInsets.only(
                                              top: 6.0, left: 16.0),
                                          child: const Text(
                                            "Email address",
                                            style: TextStyle(
                                                fontSize: 11.0,
                                                color: Color(0xff64748B),
                                                fontFamily: 'Inter',
                                                fontWeight: FontWeight.w500),
                                          )),
                                      Container(
                                        margin: const EdgeInsets.only(
                                            top: 5.0, left: 0.0),
                                        height: 20.0,
                                        child: TextFormField(
                                          controller: _emailAddress,
                                          cursorColor: const Color(0xffFFFFFF),
                                          style: const TextStyle(
                                              color: Color(0xffFFFFFF)),
                                          textAlignVertical:
                                              TextAlignVertical.bottom,
                                          keyboardType: TextInputType.text,
                                          decoration: InputDecoration(
                                              contentPadding:
                                                  const EdgeInsets.only(
                                                bottom: 16.0,
                                                top: 0.0,
                                                right: 10,
                                                left: 15.0,
                                              ),
                                              border: InputBorder.none,
                                              hintText: list!.email!.toString(),
                                              hintStyle: const TextStyle(
                                                  fontSize: 14.0,
                                                  color: Color(0xffFFFFFF),
                                                  fontFamily: 'Inter',
                                                  fontWeight: FontWeight.w500)),
                                          onChanged: (value) {
                                            //filterSearchResults(value);
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  width:
                                      MediaQuery.of(context).size.width * 0.26,
                                  margin: const EdgeInsets.only(
                                      top: 20.0, left: 30.0),
                                  height: 56.0,
                                  decoration: BoxDecoration(
                                    color: const Color(0xff334155),
                                    //border: Border.all(color:  const Color(0xff1E293B)),
                                    borderRadius: BorderRadius.circular(
                                      8.0,
                                    ),
                                  ),
                                  child: Container(
                                      margin: const EdgeInsets.only(
                                          left: 16.0, right: 20.0),
                                      // padding: const EdgeInsets.all(2.0),
                                      child: StatefulBuilder(
                                        builder: (BuildContext context,
                                            StateSettersetState) {
                                          return DropdownButtonHideUnderline(
                                            child: DropdownButton(
                                              dropdownColor:
                                                  ColorSelect.class_color,
                                              value: _time,
                                              underline: Container(),
                                              hint: Text(
                                                list!.resource!.timeZone!
                                                    .diffFromGtm
                                                    .toString(),
                                                style: const TextStyle(
                                                    fontSize: 14.0,
                                                    color: Color(0xffFFFFFF),
                                                    fontFamily: 'Inter',
                                                    fontWeight:
                                                        FontWeight.w500),
                                              ),
                                              isExpanded: true,
                                              icon: SvgPicture.asset(
                                                "images/drop_arrow.svg",
                                                color: const Color(0xff64748B),
                                                width: 8.0,
                                                height: 5.0,
                                              ),
                                              items: _timeline.map((items) {
                                                return DropdownMenuItem(
                                                  value: items['id'].toString(),
                                                  child: Text(
                                                    items['diff_from_gtm'],
                                                    style: const TextStyle(
                                                        fontSize: 14.0,
                                                        color:
                                                            Color(0xffFFFFFF),
                                                        fontFamily: 'Inter',
                                                        fontWeight:
                                                            FontWeight.w400),
                                                  ),
                                                );
                                              }).toList(),
                                              onChanged: (newValue) {
                                                setState(() {
                                                  _time = newValue;
                                                  print("account:$_time");
                                                });
                                              },
                                            ),
                                          );
                                        },
                                      )),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        });
  }


  //PopupMenu pop edit and delete
  void showMemberMenu() async {
    await showMenu(
      context: context,
      color: Color(0xff0F172A),
      position: const RelativeRect.fromLTRB(200, 90, 50, 100),
      items: [
        PopupMenuItem(
          value: 1,
          child: InkWell(
           // hoverColor: Colors.red,
            onTap: () {
              setState(() {

               // Color(0xffffffff);
              });
              Colors.red;
              Navigator.pop(context);
              showAddPeople(context);
            },
            child: Container(
               width: 30,
              child: const Text(
                "Edit",
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    fontFamily: 'Inter',
                    color: ColorSelect.white_color),
              ),
            ),
          ),
        ),
        PopupMenuItem(
          value: 2,
          child: InkWell(
            onTap: () {
              Navigator.pop(context);
              showAlertDialog(context);
            },
            child: Text(
              "Delete",
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  fontFamily: 'Inter',
                  color: ColorSelect.white_color),
            ),
          ),
        ),
      ],
      elevation: 8.0,
    ).then((value) {
      if (value != null) print(value);
    });
  }


  //Delete popup
  showAlertDialog(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return StatefulBuilder(
            builder: (context, setState) => AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(28.0),
              ),
              backgroundColor: ColorSelect.peoplelistbackgroundcolor,
              content: Container(
                height: 110.0,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(right: 20.0),
                      child: const Text(
                        "Do you want to delete @InTheGoatWay?",
                        style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'Inter',
                            color: ColorSelect.white_color),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 15.0),
                      child: Text(
                        "Once deleted,you will not find this person in people list anymore",
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                            fontFamily: 'Inter',
                            color: ColorSelect.delete),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        margin: const EdgeInsets.only(top: 30.0),
                        child: Row(
                          children: [
                            Spacer(),
                            InkWell(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: Container(
                                margin: const EdgeInsets.only(right: 35.0),
                                child: Text(
                                  "Cancel",
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                      fontFamily: 'Inter',
                                      color: ColorSelect.delete_text),
                                ),
                              ),
                            ),
                            InkWell(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: Text(
                                "Delete",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'Inter',
                                    color: ColorSelect.red_color),
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  ],
                ),
                //MediaQueryx.of(context).size.height * 0.85,
              ),
            ),
          );
        });
  }


  Future<void> _selectDate(setState) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        firstDate: DateTime(2000),
        lastDate: DateTime.now());
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  var items = [
    'Item 1',
    'Item 2',
    'Item 3',
    'Item 4',
    'Item 5',
  ];

  Future? getProject() {
    return Provider.of<TagDetail>(context, listen: false).getTagData();
  }

  Future? getList;
  Future getListData1(){
    return Provider.of<ProjectDetail>(context, listen: false).changeProfile();
  }

  @override
  void didChangeDependencies() {
    print('hello people profile');
    getList=getListData1();
    super.didChangeDependencies();
  }

  void change() async {
    var prefs = await SharedPreferences.getInstance();
    prefs.setString('val', 'r');
  }

  @override
  void initState() {
    _getTag = getProject();
    change();
    _isSelected = false;
    getUsers();
    getDepartment();
    getCurrency();
    getTimeline();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var avail_time=list.resource!.availibiltyTime;
    var avail_dat=list.resource!.availibiltyDay;
    var timezome=list.resource!.timeZone!.name;
    var timeoffset=list.resource!.timeZone!.offset;
    var country=list.resource!.country;
    var city=list.resource!.city;
    var salary=list.resource!.salary;
    final arguments = (ModalRoute.of(context)?.settings.arguments ??
        <String, dynamic>{}) as Map;
    name = arguments;
    print('jsonData');
    print(list);
    final mediaQueryData = MediaQuery.of(context);

    return MediaQuery(
      data: mediaQueryData.copyWith(textScaleFactor: 1.0),
      child: Scaffold(
     /* appBar: AppBar(title:Text("title")),*/
        backgroundColor: ColorSelect.class_color,
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              // mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                  child: Container(
                    width: MediaQuery.of(context).size.width * 0.89,
                    height: MediaQuery.of(context).size.height * 0.40,
                    margin: const EdgeInsets.only(
                        left: 59.0, right: 32.0, bottom: 0.0, top: 35.0),
                    decoration: BoxDecoration(
                      color: const Color(0xff1E293B),
                      border: Border.all(
                          color: ColorSelect.peoplelistbackgroundcolor),
                      borderRadius: BorderRadius.circular(
                        12.0,
                      ),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          height: 40.0,
                          margin: const EdgeInsets.only(left: 16.0, top: 16.0),
                          decoration: BoxDecoration(
                            color: ColorSelect.box_decoration,
                            //border: Border.all(color: const Color(0xff0E7490)),
                            borderRadius: BorderRadius.circular(
                              55.0,
                            ),
                          ),
                          child: const Align(
                            alignment: Alignment.center,
                            child: Padding(
                              padding: EdgeInsets.only(left: 10.0,right: 10.0,top: 10.0,bottom: 10.0),
                              child: Text(
                                "OCCUPIED",
                                style: TextStyle(
                                    color: ColorSelect.boxtext_color,
                                    fontSize: 14.0,
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                          ),
                        ),

                        Column(
                          children: [

                            Container(
                                width: 134.0,
                                height: 134.0,
                                margin:
                                    const EdgeInsets.only(left: 16.0, top: 20.0),
                                decoration: BoxDecoration(
                                  //color: const Color(0xff334155),
                                  borderRadius: BorderRadius.circular(
                                    40.0,
                                  ),
                                ),
                                child:  CircleAvatar(
                                  radius: 110,
                                  backgroundImage: NetworkImage(
                                      list.image!),
                                )),

                            Container(
                              margin:
                                  const EdgeInsets.only(left: 16.0, top: 10.0),
                              child: Text(
                                list!.name.toString(),
                                style: const TextStyle(
                                    color: ColorSelect.white_color,
                                    fontSize: 22.0,
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w700),
                              ),
                            ),
                            //  "$name\n$designation,$associate",

                            Row(
                              children: [
                                Container(
                                  margin: const EdgeInsets.only(
                                    top: 10.0,
                                    right: 0.0,
                                  ),
                                  child: Text(
                                    list.resource!.designation.toString(),
                                    style: const TextStyle(
                                        color: ColorSelect.profile_color,
                                        fontSize: 14.0,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w400),
                                  ),
                                ),
                                Container(
                                  margin: const EdgeInsets.only(
                                    top: 13.0,
                                    left: 8.0,
                                  ),
                                  height: 6.0,
                                  width: 6.0,
                                  decoration: const BoxDecoration(
                                      color: Color(0xff64748B),
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(20))),
                                ),
                                Container(
                                  margin: const EdgeInsets.only(
                                    top: 10.0,
                                    left: 8.0,
                                    right: 0.0,
                                  ),
                                  child: Text(
                                    list.resource!.department!.name.toString(),
                                    style: const TextStyle(
                                        color: ColorSelect.profile_color,
                                        fontSize: 14.0,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w400),
                                  ),
                                ),
                                Container(
                                  margin: const EdgeInsets.only(
                                    top: 13.0,
                                    left: 8.0,
                                  ),
                                  height: 6.0,
                                  width: 6.0,
                                  decoration: const BoxDecoration(
                                      color: Color(0xff64748B),
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(20))),
                                ),
                                Container(
                                  margin: const EdgeInsets.only(
                                    top: 10.0,
                                    left: 8.0,
                                    right: 0.0,
                                  ),
                                  child: Text(
                                    "Associated with: ",
                                    style: const TextStyle(
                                        color: ColorSelect.profile_color,
                                        fontSize: 14.0,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w400),
                                  ),
                                ),
                                Container(
                                  margin: const EdgeInsets.only(
                                    top: 10.0,
                                    left: 8.0,
                                    right: 0.0,
                                  ),
                                  child: Text(
                                    list.resource!.associate.toString(),
                                    style: const TextStyle(
                                        color: ColorSelect.profile_color,
                                        fontSize: 14.0,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w400),
                                  ),
                                ),
                              ],
                            ),

                            Row(
                              children: [
                                Container(
                                  width: 20.0,
                                  height: 18.0,
                                  margin: const EdgeInsets.only(
                                    top: 10.0,
                                    left: 16.0,
                                    right: 0.0,
                                  ),
                                  child: SvgPicture.asset(
                                    "images/location_icon.svg",
                                  ),
                                ),
                                Container(
                                  margin:
                                      const EdgeInsets.only(left: 0.0, top: 10.0),
                                  child: const Text(
                                    "Blidorp, The Netherlands . 8:12 am EDT",
                                    style: TextStyle(
                                        color: ColorSelect.profile_color,
                                        fontSize: 14.0,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w400),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),

                        InkWell(

                          onTap: () async {
                            print('object');

                            showMemberMenu();
                          },
                          child: Container(

                            margin: const EdgeInsets.only(right: 12.0, top: 16.0),
                            height: 30.0,
                            width: 30.0,
                            decoration: BoxDecoration(
                                border: Border.all(
                                  color: ColorSelect.box_decoration,
                                ),
                                borderRadius:
                                    const BorderRadius.all(Radius.circular(40))),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: SvgPicture.asset(
                                "images/edit.svg",
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  margin: const EdgeInsets.only(left: 175.0, top: 0.0),
                  child: const Text(
                    "About me",
                    style: TextStyle(
                        color: ColorSelect.text_color,
                        fontSize: 18.0,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w500),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(left: 134.0, top: 40.0),
                      child: Text(
                        "Youri",
                        style: TextStyle(
                            color: ColorSelect.white_color,
                            fontSize: 16.0,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w600),
                      ),
                    ),
                    Container(
                      width: 700.0,
                      margin: const EdgeInsets.only(
                        left: 134.0,top: 8.0,
                      ),
                      child: Text(
                        "Currently,i lead the team to maintain the internal style guide & implementation new device patterns\nin docs ,Sheets,slide",
                        style: TextStyle(
                            color: ColorSelect.text_color,
                            fontSize: 16.0,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w400),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  margin: const EdgeInsets.only(left: 175.0, top: 20.0),
                  child: const Text(
                    "Availability",
                    style: TextStyle(
                        color: ColorSelect.text_color,
                        fontSize: 18.0,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w500),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(left: 120.0, top: 40.0),
                      child: Text(
                        "Mon - Fri | 10:00 AM - 7:00 PM | $timezome$timeoffset/$city",
                        style: const TextStyle(
                            color: ColorSelect.white_color,
                            fontSize: 16.0,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w600),
                      ),
                    ),
                    Container(
                      width: 700.0,
                      margin: const EdgeInsets.only(
                        top: 8.0,
                        left: 120.0,
                      ),
                      child: Text(
                        "$salary hours/week",
                        style: const TextStyle(
                            color: ColorSelect.text_color,
                            fontSize: 16.0,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w400),
                      ),
                    ),
                  ],
                ),
              ],
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [

                Container(
                  margin: const EdgeInsets.only(left: 175.0, top: 40.0),
                  child: const Text(
                    "Skills",
                    style: TextStyle(
                        color: ColorSelect.text_color,
                        fontSize: 18.0,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w500),
                  ),
                ),

                SizedBox(
                  height: 65,
                  child: Container(
                    margin: const EdgeInsets.only(left: 160.0, top: 30.0),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 0.0),
                      child: ListView.builder(
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemCount: list.resource!.skills!.length,
                        itemBuilder: (BuildContext context, int index) {
                          //PeopleData _peopleListSkills = data.peopleList!.data![index];
                          Skills _skills = list.resource!.skills![index];
                          var skill = _skills.title;
                          // postion=index;
                          return Container(
                            height: 32.0,
                            margin: const EdgeInsets.only(left: 5.0, top: 5.0),
                            decoration: BoxDecoration(
                              color: const Color(0xff334155),
                              borderRadius: BorderRadius.circular(
                                8.0,
                              ),
                            ),
                            child: Align(
                              alignment: Alignment.center,
                              child: Padding(
                                padding: EdgeInsets.only(left: 12.0,right: 12.0,top: 6.0,bottom: 6.0),
                                child: Text(
                                  '$skill',
                                  style: const TextStyle(
                                      color: ColorSelect.white_color,
                                      fontSize: 14.0,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w400),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<String?> getTimeline() async {
    String? value;
    var token='Bearer '+storage.read("token");
    if (value == null) {
      var response = await http.get(
        Uri.parse("http://zeusapitst.crebos.online/api/v1/time-zone/list"),
        headers: {
          "Accept": "application/json",
          "Authorization":token,
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body.toString());
        List<dynamic> mdata = map["data"];
        setState(() {
          _timeline = mdata;
        });
        //var res = response.body;
        //  print('helloDepartment' + res);
        //  DepartmentResponce peopleList = DepartmentResponce.fromJson(json.decode(res));
        // return peopleList;

        // final stringRes = JsonEncoder.withIndent('').convert(res);
        //  print(stringRes);
      } else {
        print("failed to much");
      }
      return value;
    }
  }

  Future<String?> getCurrency() async {
    String? value;
    var token='Bearer '+storage.read("token");
    if (value == null) {
      var response = await http.get(
        Uri.parse("http://zeusapitst.crebos.online/api/v1/currencies"),
        headers: {
          "Accept": "application/json",
          "Authorization":token,        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body.toString());
        List<dynamic> mdata = map["data"];
        setState(() {
          _currencyName = mdata;
        });
      } else {
        print("failed to much");
      }
      return value;
    }
  }

  Future<String?> getDepartment() async {
    String? value;
    var token='Bearer '+storage.read("token");
    if (value == null) {
      var response = await http.get(
        Uri.parse("http://zeusapitst.crebos.online/api/v1/departments"),
        headers: {
          "Accept": "application/json",
          "Authorization":token,
        },
      );
      if (response.statusCode == 200) {
        Map<String, dynamic> map = jsonDecode(response.body.toString());
        List<dynamic> mdata = map["data"];
        setState(() {
          _department = mdata;
        });
      } else {
        print("failed to much");
      }
      return value;
    }
  }
}
